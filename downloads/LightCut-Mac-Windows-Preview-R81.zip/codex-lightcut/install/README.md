# R8 安装与恢复

本页供 Codex 执行，用户只需提供视频与创作选择。安装与检查不打开、关闭或激活剪映，不播放媒体，不创建草稿，不修改系统 PATH、系统 Python 或代理。

## R7.1 失败后的继续安装

R7.2 修复 Windows 启动器的嵌套日志写入冲突，并明确从当前 PowerShell 的内置目录加载模块，避免继承另一个 PowerShell 版本的模块时找不到 Get-FileHash。模块搜索路径只作用于当前进程及子进程，启动器结束时恢复；不改系统设置。日志追加操作逐次关闭文件句柄。

旧包保留，新包解压到新程序目录；这次 **继续使用 R7.1 失败尝试的 LIGHTCUT_DATA_HOME**，保留 uv、托管 Python 及失败日志，不另建空数据目录重新下载。先校验新包，再带原 -WithAsr 和已验证 -EngineFrom 参数继续；恢复之前已确认的本机剪映路径如 JY14_APP_BUNDLE 仅限子进程。安装成功后再运行相同命令检查复用，并运行下面的回传检查。check_install.py 包含 Windows 启动器回归，用实际 Windows PowerShell 执行；Mac 会明确跳过该项。此前失败尝试不能记为完整热复用通过。

首次使用新机器仍按下方首次流程执行。

R8 升级保留已有数据目录，首次接入成功后保存引擎来源；后续升级自动定位并再次校验，见 [引擎来源与交付](ENGINE-DELIVERY.md)。Windows R7.2 安装与资源补齐已经通过，普通使用不重复执行历史验收。

## 入口

Mac：`bash <插件根>/install-mac.command [--with-asr] [--engine-from <已验证的本机引擎>]`。

Windows x64：`powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File <插件根>/install-windows.ps1 [-WithAsr] [-EngineFrom <已验证的本机引擎>]`。Bypass 只作用于本次进程，不修改系统执行策略；组策略仍可能禁止脚本，不能绕过机器管理员的策略。也提供 `install-windows.cmd` 启动器。

入口不要求已有 Python。固定版本 uv 在用户私有目录下载并核对 SHA-256；uv 准备固定 Python 3.12.12，不注册全局命令或 Windows Python 注册表。随后创建独立虚拟环境、按摘要安装 fontTools，并安装固定摘要的 FFmpeg/ffprobe。

没有传 `with-asr` 就不下载大模型。有本地转写需求时才加该参数，安装固定依赖及 `Systran/faster-whisper-small` 的固定提交。模型约 484 MB，CPU/int8 是通用备用路线，不承诺与现有 GPU 转写同速；Windows CPU 速度待实测。模型文件下载后校验并加载，后续转写也核对模型文件。ASR 模型不是剪映美颜所需的模型。

## 存储和继续运行

- Mac 默认数据根：`~/Library/Application Support/CodexLightCut`。
- Windows 默认数据根：`%LOCALAPPDATA%\CodexLightCut`。
- 开发隔离使用 `LIGHTCUT_DATA_HOME`；实际用户升级保持原数据根，避免丢失默认偏好。
- `environment/runtime.json` 记录实际虚拟环境 Python、私有媒体工具、可选模型。执行 `scripts/lightcut.py` 时自动带入这些依赖，不需要改 PATH。
- 虚拟环境 Python 不能解析符号链接后再调用，否则会丢失环境。使用记录中的原始绝对路径。
- `environment/install-state.json` 是最新状态；`environment/attempts/<本次编号>` 保留历史及日志。

重新运行同一个安装入口：正确媒体文件和模型不重新下载；未完成模型/工具下载按 Range 续传，服务不支持 Range 则从头重取该文件。摘要不符的文件保留并隔离，不启用；绝不删除整个缓存。基础依赖已就绪时，即使可选模型失败，已有基础命令仍可使用。并发安装由系统锁协调，进程退出后锁自动释放。

## 原生引擎与效果

当前包不捆绑受限原生引擎或剪映资产。`engine-from` 由 Agent 从先前已通过测试的程序目录/本任务记录获取，不让普通用户查路径。引擎按对应平台文件摘要校验，复制中断可继续，只补缺失文件；已有不同内容拒绝覆盖。没有可信来源的新机器会返回 `native-engine-missing`，由开发端解决授权交付或独立实现。

`environment_ready=true` 表示基础工具准备完成，`native_ready=true` 才代表本次默认风格的剪映运行时与资源检查通过。默认风格检查失败不等于用户选择的所有基础剪辑都不可用；选定效果后仍按对应设置检查。安装器只读检查原生效果，不主动下载一整套尚未选择的美颜/滤镜。

## Windows 回传（由 Codex 操作）

1. 首次验收时解压当前包到新目录，保留旧版本。可先用现有 Python 校验 `PACKAGE_SHA256.json`；确认源文件未变后运行对应安装入口。`LIGHTCUT_DATA_HOME` 设为新的测试数据目录，不覆盖真实创作偏好。
2. 首次带 `-WithAsr`，并由 Agent 传入上一轮已验证 Windows 引擎。失败时不要删目录、改哈希或制作参考草稿。修复网络后运行原命令即可继续。
3. 再运行相同命令检查复用。使用 `environment/runtime.json` 中的 Python 执行 `install/check_install.py --out <新结果目录>`。
4. 回传结果目录中的 `LightCut-R81-Install-Results.zip`。检查器校验随包文件、执行安装回归、媒体编码探测、模型加载及原生 setup。结果包只有脱敏 JSON/日志，不含用户视频、模型、官方效果或引擎字节。

本轮不需要用户提供新视频或改动现有草稿。Windows shell、首次依赖安装、模型加载须以实机结果为准；Mac 模拟测试不能替代它们。

## 依赖来源

- [uv 与托管 Python](https://docs.astral.sh/uv/guides/install-python/)；uv 下载固定 0.12.18 发行包，Python 为其维护的 python-build-standalone 分发。
- [ffmpeg-static 发布项目](https://github.com/eugeneware/ffmpeg-static)：固定 b6.1.1 发布资产，逐平台实际编译版本以 `-version` 日志为准（本轮 Mac arm64 为 6.0），不是 FFmpeg 官方直接发布的二进制。对应 LICENSE 与构建 README 随下载保存。
- [faster-whisper](https://github.com/SYSTRAN/faster-whisper) 和 [模型来源](https://huggingface.co/Systran/faster-whisper-small)。

完整 URL、大小与摘要见 `dependencies.json`，Python 包及传递依赖摘要见两个 requirements 文件。包中只包含代码与依赖描述，不重分发这些二进制。本版本用于私人验证，不替代受限引擎公开分发所需的处理。
