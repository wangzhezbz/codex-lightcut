"""Experimental Windows new-draft bridge; no GUI actions or Mac resource reuse.

A successful offline test is not Windows installation/render acceptance.
"""
from pathlib import Path
import importlib
import os
import subprocess
import sys
import time
from .platforms import host, background_priority, process_pids
from .project import compile_plan, validate
from .storage import load, save, sha, manifest, require, asset_path

ROOT = Path(__file__).resolve().parents[2]
BACKEND = ROOT / 'upstream/jianying-headless-windows'
PIN = 'ae51f85357c1ce92a4ed665aacb1bb02c527da615f7cc984714d08dded99ed3b'


def verify_sources():
    pinfile = BACKEND/'STUDIO_SOURCE_LOCK.json'
    require(sha(pinfile) == PIN, 'Windows source manifest changed; review before updating pins')
    lock = load(pinfile)
    for relative, expected in lock['files'].items():
        p = BACKEND/relative
        require(p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(BACKEND.resolve()),
                'Windows backend source missing or escaped: ' + relative)
        require(sha(p) == expected, 'Windows backend source changed: ' + relative)
    return lock


def _imports():
    require(host() == 'windows', 'Experimental Windows backend must run on Windows')
    verify_sources()
    for relative in ('bridge','engine','tools'):
        sys.path.insert(0,str(BACKEND/relative))
    for name in ('jy14_headless','headless_runtime','platform_support','windows_codec','windows_platform'):
        loaded=sys.modules.get(name)
        if loaded:
            require(Path(loaded.__file__).resolve().is_relative_to(BACKEND.resolve()),
                    'Another engine is loaded; use a separate worker process')


def engine():
    _imports()
    return importlib.import_module('jy14_headless')


def doctor():
    _imports()
    # This collector never loads a DLL unless its separate explicit probe is requested.
    r=importlib.import_module('runtime_report_windows').collect(False)
    r.update(adapter='windows-experimental',native_ui_acceptance='not-tested-on-user-windows',ui_actions=0)
    return r


def check_supported(project):
    validate(project,verify_assets=False)
    style=project['style']
    missing=[]
    for key in ('beauty','filter','adjustment'):
        if style.get(key,{}).get('enabled'):missing.append(key)
    if style.get('subtitle_shadow'):missing.append('subtitle_shadow')
    if style.get('native_profile'):missing.append('native_profile')
    for t in project['tracks']:
        for s in t['segments']:
            missing.extend(k for k in ('mask','transition_out','text_effect') if k in s)
    require(not missing,'Windows resources/effects not adapted: '+', '.join(sorted(set(missing)))+
            '. Requested effects were not silently removed; use an explicitly separate basic compatibility sample.')


def prepare_home_cover(project, project_dir, output, native, record, j):
    # Make the leading image the homepage cover, as on our Mac adapter.
    first=project['tracks'][0]['segments'][0];asset=project['assets'][first['asset']]
    if asset['kind']=='image':
        thumb=output/'draft-cover.jpg'
        subprocess.run(['ffmpeg','-nostdin','-v','error','-n','-i',str(asset_path(project_dir,asset['path'])),
                        '-frames:v','1','-vf','scale=320:-2',str(thumb)],check=True,capture_output=True,timeout=30,
                       creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        for rel in ('draft_cover.jpg',f"Timelines/{record['timeline_id']}/draft_cover.jpg"):
            with (native/'draft'/rel).open('wb') as f:f.write(thumb.read_bytes());f.flush();os.fsync(f.fileno())
        # This record belongs to the native engine: retain its platform-specific
        # manifest keys. Studio's portable slash keys are a different contract.
        record['files']=j.files_manifest(native/'draft');save(native/'build.json',record,replace=True)
        j.verify_build(native)


def build(project_dir,output,profile_path=None,audio_report_path=None):
    if profile_path is not None and load(profile_path).get('schema') == 'lightcut-windows-style-profile/v1':
        from . import windows_style_backend
        return windows_style_backend.build(project_dir, output, profile_path, audio_report_path)
    started=time.perf_counter();project_dir=Path(project_dir).resolve();output=Path(output).resolve()
    project=load(project_dir/'project.json');check_supported(project)
    require(profile_path is None,'A Mac native profile cannot be used by the Windows adapter')
    plan=compile_plan(project,project_dir)
    from .quality import inspect
    audio=load(audio_report_path) if audio_report_path else None
    quality=inspect(project,project_dir,audio_report=audio)
    require(not quality['errors'],'Quality checks failed: '+str(quality['errors']))
    j=engine();background_priority();j.nd.validate_runtime();j.nd.fresh_directory(output)
    save(output/'project.json',project);save(output/'native-plan.json',plan);save(output/'quality-before-build.json',quality)
    if audio:save(output/'audio-audit.json',audio)
    native=output/'native-build';j.build(output/'native-plan.json',native)
    record=j.verify_build(native)
    prepare_home_cover(project, project_dir, output, native, record, j)
    result={k:record[k] for k in ('name','target','draft_id','timeline_id','runtime_profile')}
    result.update(schema='jianying-studio-windows-build/v1',status='built-offline',
                  project_sha256=sha(output/'project.json'),plan_sha256=sha(output/'native-plan.json'),
                  native_record_sha256=sha(native/'build.json'),quality_sha256=sha(output/'quality-before-build.json'),
                  source_manifest_sha256=PIN,seconds=time.perf_counter()-started,ui_actions=0,
                  acceptance={'structure':'verified','visual':'not-checked','windows':'pending-real-machine-acceptance'},
                  effects='basic-only-no-Mac-profile-imported')
    save(output/'build.json',result);verify(output);return result


def verify(output):
    output=Path(output).resolve(strict=True);record=load(output/'build.json')
    if record.get('schema') == 'lightcut-windows-integrated-build/v1':
        from . import windows_style_backend
        return windows_style_backend.verify(output)
    require(record['schema']=='jianying-studio-windows-build/v1','Not a Windows studio build')
    require(record['source_manifest_sha256']==PIN,'Windows source provenance changed')
    for rel,key in [('project.json','project_sha256'),('native-plan.json','plan_sha256'),
                    ('native-build/build.json','native_record_sha256'),('quality-before-build.json','quality_sha256')]:
        require(sha(output/rel)==record[key],'Frozen Windows build changed: '+rel)
    project=load(output/'project.json');check_supported(project)
    from .audio_quality import project_digest
    quality=load(output/'quality-before-build.json')
    require(not quality['errors'] and quality['project_sha256']==project_digest(project),'Stale/failed quality gate')
    j=engine();native=j.verify_build(output/'native-build')
    from .ending import verify_native
    timeline = j.nd.helper()._decrypt_metadata_in_memory(output/'native-build/draft/draft_content.json')
    verify_native(project, timeline)
    require(load(output/'native-plan.json')==load(output/'native-build/plan.json'),'Native plan differs from intended plan')
    for k in ('name','target','draft_id','timeline_id','runtime_profile'):
        require(record[k]==native[k],'Native identity differs: '+k)
    return record


def verify_live(output):
    if load(Path(output)/'build.json').get('schema') == 'lightcut-windows-integrated-build/v1':
        from . import windows_style_backend
        return windows_style_backend.verify_live(output)
    r=verify(output);j=engine();live=j.verify_live(Path(output)/'native-build')
    native=load(Path(output)/'native-build/build.json')
    require(j.files_manifest(Path(r['target']))==native['files'],'Registered Windows bytes differ')
    return dict(live,acceptance=r['acceptance'])


def publish(output,audit,wait_seconds=0):
    if load(Path(output)/'build.json').get('schema') == 'lightcut-windows-integrated-build/v1':
        from . import windows_style_backend
        return windows_style_backend.publish(output,audit,wait_seconds)
    require(type(wait_seconds) is int and 0<=wait_seconds<=86400,'Invalid wait timeout')
    verify(output);started=time.monotonic()
    while process_pids():
        if time.monotonic()-started>=wait_seconds:
            return {'status':'waiting-for-editor-to-close','live_files_written':False,'build':str(output)}
        time.sleep(min(2,max(0,wait_seconds-(time.monotonic()-started))))
    # Native publisher independently rechecks enumeration and installation under its lock.
    j=engine();result=j.publish(Path(output)/'native-build',Path(audit));verify_live(output)
    return dict(result,acceptance={'structure':'verified','visual':'not-checked','windows':'pending-real-machine-acceptance'})
