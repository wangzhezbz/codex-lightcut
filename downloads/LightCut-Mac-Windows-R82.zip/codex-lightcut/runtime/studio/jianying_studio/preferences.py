"""Versioned creative choices for the conversational plugin. No editor or network IO.

Revisions are append-only and exclusively created: stale confirmations/updates
cannot overwrite newer choices. Defaults and per-video sessions are separate.
"""
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import uuid

from .storage import load, require, save, sha
from .project import fields, number, style_check
from .onboarding import DEFAULT_STYLE

SCHEMA = 'lightcut-preferences/v1'
GROUPS = ('cover', 'effects', 'music', 'editing')
STYLES = (
    ('bold-3d', '立体吸睛', '大标题、立体元素、鲜明配色'),
    ('minimal', '极简专业', '干净背景、清楚排版，适合知识教程'),
    ('portrait', '人物焦点', '以本人为主体，搭配重点标题'),
    ('editorial', '杂志质感', '摄影感、克制配色、有层次的排版'),
    ('illustration', '趣味插画', '用插画和主题物件表达内容'),
)


def home_dir():
    if os.environ.get('LIGHTCUT_DATA_HOME'):
        return Path(os.environ['LIGHTCUT_DATA_HOME']).expanduser().resolve()
    if sys.platform == 'win32':
        return Path(os.environ.get('LOCALAPPDATA', str(Path.home() / 'AppData/Local'))) / 'CodexLightCut'
    return Path.home() / 'Library/Application Support/CodexLightCut' if sys.platform == 'darwin' else Path.home() / '.local/share/codex-lightcut'


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False,
                                     separators=(',', ':')).encode()).hexdigest()


def recommendations():
    # Music is never chosen from the developer's private files. Raw voice gain is preserved.
    effects = load(DEFAULT_STYLE)
    # A disclosed first-use recommendation, never a rewrite of stored choices.
    if sys.platform == 'win32': effects['subtitle_shadow'] = False
    return {'cover': {'mode': 'generate', 'style': 'bold-3d', 'title': '', 'title_policy': 'agent',
                      'instructions': '', 'style_instructions': '', 'size': None, 'asset': None},
            'effects': effects,
            'music': {'mode': 'none', 'asset': None, 'gain_db': 0, 'start_frame': 1, 'remember_asset': False},
            'editing': {'pace': 'natural', 'aspect': 'source', 'speech_gain_db': None, 'end_fade_ms': 300,
                        'captions': {'enabled': True, 'size': 15, 'x': 0, 'y': -0.551507430997877,
                                     'color': '#FFFFFF', 'font': None}}}


def catalog():
    return {'schema': SCHEMA, 'groups': list(GROUPS),
            'cover_sources': ['image', 'generate', 'frame', 'none'],
            'cover_styles': [dict(id=i, name=n, description=d) for i, n, d in STYLES],
            'effect_choices': ['use-preset', 'original', 'modify-parts'],
            'effects_description': '预设包含高清增强 12%、明暗色彩微调、肤质和脸型修饰；三项可分别关闭或修改。',
            'platform_notice': ('Windows 首次推荐不含尚未适配的字幕阴影；已保存的阴影选择保留并明确提示。'
                                if sys.platform == 'win32' else '沿用 Mac 已适配效果；资源准备与最终画面分别验证。'),
            'music_choices': ['file', 'none'], 'music_library': 'not-bundled',
            'music_notice': '可使用用户提供或已授权曲目；尚未内置可分发音乐库，不编造推荐曲目。试听必须由用户主动播放。',
            'recommended': recommendations(), 'recommendations_are_confirmations': False, 'ui_actions': 0}


def asset(path):
    p = Path(path).expanduser().resolve(strict=True)
    require(p.is_file(), '素材不是文件')
    return {'path': str(p), 'sha256': sha(p)}


def check_asset(value, *, verify=False):
    fields(value, {'path', 'sha256'}, '素材')
    require(set(value) == {'path', 'sha256'} and isinstance(value['path'], str) and value['path'], '素材路径缺失')
    require(isinstance(value['sha256'], str) and re.fullmatch('[a-f0-9]{64}', value['sha256']), '素材摘要无效')
    if verify:
        require(asset(value['path']) == value, '素材已移动或内容变化，请重新选择并确认')


def validate_group(group, value, *, complete=False):
    require(group in GROUPS, '未知偏好分组')
    require(isinstance(value, dict), '偏好分组必须是对象')
    if group == 'cover':
        fields(value, {'mode', 'style', 'title', 'title_policy', 'instructions', 'style_instructions', 'size', 'asset'}, '封面')
        from .cover_size import validate_size
        validate_size(value.get('size'))
        require(value.get('mode') in ('image', 'generate', 'frame', 'none'), '请选择封面来源')
        require(value.get('style') in [s[0] for s in STYLES], '请选择五种封面风格之一')
        require(value.get('title_policy') in ('agent', 'user'), '标题方式无效')
        for k in ('title', 'instructions'):
            require(isinstance(value.get(k), str) and len(value[k]) <= 4000, '封面文字无效')
        require(isinstance(value.get('style_instructions', ''), str)
                and len(value.get('style_instructions', '')) <= 4000, '长期封面风格说明无效')
        if value.get('asset') is not None: check_asset(value['asset'])
        if complete and value['mode'] in ('image', 'frame'):
            require(value.get('asset') is not None, '请提供已选择的封面图片或视频截图')
        if complete and value['mode'] == 'generate' and value['title_policy'] == 'user':
            require(value['title'].strip(), '请确认封面标题，或明确交由插件决定')
    elif group == 'effects':
        style_check(value)
    elif group == 'music':
        fields(value, {'mode', 'asset', 'gain_db', 'start_frame', 'remember_asset'}, '音乐')
        require(value.get('mode') in ('file', 'none'), '请选择音乐或不加音乐')
        number(value.get('gain_db'), '音乐增益 dB', -60, 12)
        require(type(value.get('start_frame')) is int and 0 <= value['start_frame'] <= 600, '音乐起点无效')
        require(type(value.get('remember_asset')) is bool, '是否复用曲目必须明确')
        if value.get('asset') is not None: check_asset(value['asset'])
        if complete and value['mode'] == 'file': require(value.get('asset') is not None, '请先选择一首真实音乐')
    else:
        fields(value, {'pace', 'aspect', 'speech_gain_db', 'captions', 'end_fade_ms'}, '字幕与节奏')
        if 'end_fade_ms' in value:
            require(type(value['end_fade_ms']) is int and 0 <= value['end_fade_ms'] <= 3000, '片尾渐隐须为 0–3000 毫秒，0 表示关闭')
        require(value.get('pace') in ('natural', 'tight', 'basic'), '剪辑节奏无效')
        require(value.get('aspect') in ('source', '9:16', '16:9', '1:1'), '画面比例无效')
        if value.get('speech_gain_db') is not None: number(value['speech_gain_db'], '人声 dB', -60, 15)
        c = value.get('captions', {})
        fields(c, {'enabled', 'size', 'x', 'y', 'color', 'font'}, '字幕')
        require(type(c.get('enabled')) is bool, '字幕开关无效')
        number(c.get('size'), '字幕字号', 1, 100)
        for k in ('x', 'y'): number(c.get(k), '字幕位置', -1, 1)
        require(isinstance(c.get('color'), str) and re.fullmatch('#[a-fA-F0-9]{6}', c['color']), '字幕颜色无效')
        if c.get('font') is not None: check_asset(c['font'])


def merge(base, patch):
    require(isinstance(patch, dict), '修改内容必须为对象')
    result = deepcopy(base)
    for key, value in patch.items():
        result[key] = merge(result[key], value) if isinstance(value, dict) and isinstance(result.get(key), dict) else deepcopy(value)
    return result


def _latest(folder):
    folder = Path(folder)
    entries = sorted(folder.glob('r[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].json'))
    if not entries: return None
    value = load(entries[-1])
    require(value.get('schema') == SCHEMA, '未知偏好记录格式')
    require(entries[-1].name == f"r{value['revision']:08d}.json", '偏好版本记录不一致')
    return value


def _append(folder, value, expected):
    current = _latest(folder)
    require((current['revision'] if current else 0) == expected, '偏好已更新，请读取最新摘要后操作')
    result = deepcopy(value)
    result['revision'] = expected + 1
    # Exclusive create also rejects concurrent writers that passed the check together.
    save(Path(folder) / f"r{result['revision']:08d}.json", result)
    return result


def read(session, revision=None):
    state = _latest(session)
    require(state is not None and state.get('kind') == 'session', '找不到创作偏好会话')
    if revision is not None: require(state['revision'] == revision, '偏好已更新，不能沿用旧版本')
    return state


def defaults(root=None):
    return _latest((Path(root) if root else home_dir()) / 'defaults')


def start(root=None):
    root = Path(root) if root else home_dir()
    saved = defaults(root)
    choices = deepcopy(saved['choices']) if saved else {g: None for g in GROUPS}
    # Older defaults may contain a previous video's topic in instructions.
    # Clean only the new session; never rewrite the user's stored history.
    if saved:
        choices['cover']['instructions'] = ''
        choices['cover'].setdefault('style_instructions', '')
    state = {'schema': SCHEMA, 'kind': 'session', 'choices': choices, 'confirmed_digest': None,
             'cover_review': None, 'defaults_revision': saved['revision'] if saved else 0,
             'defaults_root': str((root / 'defaults').resolve())}
    folder = root / 'sessions' / uuid.uuid4().hex
    state = _append(folder, state, 0)
    return status(folder, state)


def status(session, state=None):
    state = state or read(session)
    pending = []
    for group in GROUPS:
        try: validate_group(group, state['choices'][group], complete=True)
        except (ValueError, TypeError): pending.append(group)
    confirmed = not pending and state['confirmed_digest'] == digest(state['choices'])
    cover = state['choices'].get('cover') or {}
    review = state.get('cover_review')
    reviewed = cover.get('mode') == 'none' or bool(review and review.get('approved') and review.get('choice_digest') == digest(cover))
    phase = 'needs-choices' if pending else 'needs-confirmation' if not confirmed else 'needs-cover-review' if not reviewed else 'ready-for-project'
    return {'status': phase, 'session': str(Path(session).resolve()), 'revision': state['revision'],
            'choices': state['choices'], 'pending_groups': pending, 'confirmed': confirmed,
            'cover_review': review, 'defaults_revision': state['defaults_revision'], 'ui_actions': 0,
            'native_readiness': 'not-checked', 'can_plan': confirmed, 'can_deliver': confirmed and reviewed}


def update(session, revision, patch, *, recommended=()):
    state = read(session, revision)
    require(isinstance(patch, dict) and not set(patch) - set(GROUPS), '未知偏好分组')
    require(set(recommended) <= set(GROUPS), '未知推荐设置分组')
    old_cover = deepcopy(state['choices']['cover'])
    for group in set(patch) | set(recommended):
        base = recommendations()[group] if group in recommended or state['choices'][group] is None else state['choices'][group]
        value = merge(base, patch.get(group, {}))
        validate_group(group, value)
        state['choices'][group] = value
    state['confirmed_digest'] = None
    if old_cover != state['choices']['cover']: state['cover_review'] = None
    return status(session, _append(session, state, revision))


def confirm(session, revision, *, scope):
    require(scope in ('once', 'defaults'), '必须明确仅本次或保存默认')
    state = read(session, revision)
    for g in GROUPS: validate_group(g, state['choices'][g], complete=True)
    for group in ('cover', 'music'):
        c = state['choices'][group]
        if c.get('asset') is not None and c['mode'] != 'none': check_asset(c['asset'], verify=True)
    font = state['choices']['editing']['captions'].get('font')
    if font is not None: check_asset(font, verify=True)
    state['confirmed_digest'] = digest(state['choices'])
    # Commit the session first: never save defaults for a failed/stale session write.
    if scope == 'defaults':
        old = _latest(state['defaults_root'])
        require((old['revision'] if old else 0) == state['defaults_revision'], '默认设置已被其他任务修改，请先重新查看默认设置')
    result = _append(session, state, revision)
    if scope == 'defaults':
        choices = deepcopy(state['choices'])
        choices['cover'].update(title='', asset=None, instructions='')
        if not choices['music']['remember_asset']: choices['music']['asset'] = None
        saved = _append(state['defaults_root'], {'schema': SCHEMA, 'kind': 'defaults', 'choices': choices}, state['defaults_revision'])
        result['defaults_revision'] = saved['revision']
        result = _append(session, result, result['revision'])
    return status(session, result)


def cover_review(session, revision, *, image=None, title=None, approve=False):
    state = read(session, revision)
    cover = state['choices']['cover']
    # A cover can be shown and approved as soon as its own choices are ready.
    # status/execution still require all groups and the overall confirmation.
    validate_group('cover', cover, complete=True)
    require(cover['mode'] != 'none', '本次不加封面')
    if approve:
        require(image is None and title is None, '先提交成图供用户查看，再独立确认；不能同时上传并批准')
        review = state.get('cover_review')
        require(review is not None and review['choice_digest'] == digest(cover), '请先展示当前风格的实际封面')
        check_asset(review['asset'], verify=True)
        from .cover_size import verify as verify_cover_size
        verify_cover_size(review['asset']['path'], cover.get('size'))
        review['approved'] = True
    else:
        require(image is not None, '请提供待确认的实际封面图片')
        selected = asset(image)
        from .cover_size import verify as verify_cover_size
        verify_cover_size(selected['path'], cover.get('size'))
        if cover['mode'] in ('image', 'frame'):
            require(selected == cover['asset'], '实际封面与用户选择不一致，请更新选择后重新确认')
        require(title is None or isinstance(title, str), '标题无效')
        actual_title = title if title is not None else cover['title']
        if cover['mode'] == 'generate':
            require(bool(actual_title.strip()), '生成封面需要记录实际标题')
            if cover['title_policy'] == 'user': require(actual_title == cover['title'], '封面标题与确认标题不一致')
        state['cover_review'] = {'asset': selected, 'title': actual_title, 'approved': False,
                                 'choice_digest': digest(cover)}
    return status(session, _append(session, state, revision))


def execution(session, revision):
    state = read(session, revision)
    require(status(session, state)['can_deliver'], '创作设置或封面尚未确认，不能交付')
    for c in (state['choices']['music'], state['choices']['editing']['captions']):
        a = c.get('asset') if c.get('mode') == 'file' else c.get('font')
        if a: check_asset(a, verify=True)
    if state['choices']['cover']['mode'] != 'none':
        check_asset(state['cover_review']['asset'], verify=True)
        from .cover_size import verify as verify_cover_size
        verify_cover_size(state['cover_review']['asset']['path'], state['choices']['cover'].get('size'))
    return state
