param([string]$Python, [string]$TestRoot)
$ErrorActionPreference = 'Stop'
$lightcutOriginalModulePath = $env:PSModulePath
try {
    . ([IO.Path]::Combine($PSScriptRoot, 'windows-bootstrap.ps1'))
    # Reproduce a foreign host's incompatible Utility module preceding PSHOME.
    $lightcutShadow = [IO.Path]::Combine($TestRoot, 'foreign-modules')
    $lightcutBadModule = [IO.Path]::Combine($lightcutShadow, 'Microsoft.PowerShell.Utility')
    [void][IO.Directory]::CreateDirectory($lightcutBadModule)
    [IO.File]::WriteAllText([IO.Path]::Combine($lightcutBadModule, 'Microsoft.PowerShell.Utility.psd1'),
        "@{ ModuleVersion = '99.0'; PowerShellVersion = '99.0'; RootModule = 'missing.psm1' }")
    $env:PSModulePath = $lightcutShadow + [IO.Path]::PathSeparator + $lightcutOriginalModulePath
    Initialize-LightCutPowerShell
    # Binary commands can report a DLL directly under PSHOME, while script
    # commands report a path under PSHOME/Modules. Both belong to this host.
    $lightcutHostRoot = $PSHOME + [IO.Path]::DirectorySeparatorChar
    foreach ($lightcutCommand in @('Get-FileHash', 'Out-File', 'Expand-Archive', 'Invoke-WebRequest', 'Get-Content')) {
        $lightcutResolved = Get-Command $lightcutCommand -ErrorAction Stop
        if (!$lightcutResolved.Module.Path.StartsWith($lightcutHostRoot, [StringComparison]::OrdinalIgnoreCase)) {
            throw ('Wrong module host for ' + $lightcutCommand)
        }
    }
    $lightcutLog = [IO.Path]::Combine($TestRoot, 'bootstrap.log')
    $lightcutArguments = '-c "import sys; print(''managed-python-path''); print(''uv diagnostic'', file=sys.stderr)"'
    $lightcutOutput = Invoke-LightCutUv -Executable $Python -Arguments $lightcutArguments -LogPath $lightcutLog
    Write-LightCutBootstrapLog -LogPath $lightcutLog -Text $lightcutOutput
    if ($lightcutOutput -ne 'managed-python-path') { throw 'stderr contaminated the executable path' }
    $lightcutText = [IO.File]::ReadAllText($lightcutLog)
    if (!$lightcutText.Contains('uv diagnostic') -or !$lightcutText.Contains('managed-python-path')) { throw 'Missing child log output' }
    # A rejected child must preserve stderr and release its handles for retry.
    $lightcutRejected = $false
    try {
        $lightcutFailureArgs = '-c "import sys; print(''retry diagnostic'', file=sys.stderr); sys.exit(3)"'
        Invoke-LightCutUv -Executable $Python -Arguments $lightcutFailureArgs -LogPath $lightcutLog
    } catch {
        if (!$_.ToString().Contains('exit 3')) { throw }
        $lightcutRejected = $true
    }
    if (!$lightcutRejected) { throw 'Failed child accepted' }
    $lightcutOutput = Invoke-LightCutUv -Executable $Python -Arguments $lightcutArguments -LogPath $lightcutLog
    Write-LightCutBootstrapLog -LogPath $lightcutLog -Text $lightcutOutput
    if (![IO.File]::ReadAllText($lightcutLog).Contains('retry diagnostic')) { throw 'Failure log lost' }
    Write-Output 'WINDOWS_BOOTSTRAP_REGRESSION_PASSED'
} finally {
    $env:PSModulePath = $lightcutOriginalModulePath
}
