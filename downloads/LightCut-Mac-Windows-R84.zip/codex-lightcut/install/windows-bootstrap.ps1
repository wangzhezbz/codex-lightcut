# Shared by the Windows launcher and its offline regression check.
function Initialize-LightCutPowerShell {
    # A Windows PowerShell child may inherit a PowerShell 7 module path.
    # Resolve built-in modules from THIS host before any utility auto-import.
    $lightcutNativeModules = [IO.Path]::Combine($PSHOME, 'Modules')
    $env:PSModulePath = $lightcutNativeModules + [IO.Path]::PathSeparator + $env:PSModulePath
    foreach ($lightcutModule in @('Microsoft.PowerShell.Management', 'Microsoft.PowerShell.Utility', 'Microsoft.PowerShell.Archive')) {
        $lightcutManifest = [IO.Path]::Combine($lightcutNativeModules, $lightcutModule, ($lightcutModule + '.psd1'))
        Import-Module -Name $lightcutManifest -Global -Force -ErrorAction Stop
    }
}

function Write-LightCutBootstrapLog([string]$LogPath, [string]$Text) {
    # Each append opens and closes its own handle; never keep a pipeline sink
    # open while a child function is appending stderr to the same file.
    if ($Text) {
        [IO.File]::AppendAllText($LogPath, $Text + [Environment]::NewLine, [Text.UTF8Encoding]::new($false))
    }
}

function Invoke-LightCutUv([string]$Executable, [string]$Arguments, [string]$LogPath) {
    $lightcutProcess = [Diagnostics.Process]::new()
    try {
        $lightcutProcess.StartInfo.FileName = $Executable
        $lightcutProcess.StartInfo.Arguments = $Arguments
        $lightcutProcess.StartInfo.UseShellExecute = $false
        $lightcutProcess.StartInfo.CreateNoWindow = $true
        $lightcutProcess.StartInfo.RedirectStandardOutput = $true
        $lightcutProcess.StartInfo.RedirectStandardError = $true
        [void]$lightcutProcess.Start()
        $lightcutStdout = $lightcutProcess.StandardOutput.ReadToEndAsync()
        $lightcutStderr = $lightcutProcess.StandardError.ReadToEndAsync()
        if (!$lightcutProcess.WaitForExit(600000)) {
            $lightcutProcess.Kill()
            throw 'Managed Python preparation timed out; rerun to resume.'
        }
        $lightcutText = $lightcutStdout.Result
        Write-LightCutBootstrapLog -LogPath $LogPath -Text $lightcutStderr.Result
        if ($lightcutProcess.ExitCode -ne 0) {
            Write-LightCutBootstrapLog -LogPath $LogPath -Text $lightcutText
            throw ('Managed Python preparation failed (exit ' + $lightcutProcess.ExitCode + '); rerun to resume.')
        }
        return $lightcutText.Trim()
    } finally {
        $lightcutProcess.Dispose()
    }
}
