"""Windows pilot. Default is read-only diagnostics; no editor launch/close."""
import argparse,datetime,hashlib,json,os,pathlib,subprocess,sys,uuid
ROOT=pathlib.Path(__file__).resolve().parent
def preflight_reports(doctor,evidence,validation):
    native=doctor.get('native_check',{})
    checks=native.get('checks',[])
    if not checks or not all(c.get('ok') is True for c in checks):return False
    if evidence.get('status')!='complete' or len(evidence.get('applications',[]))!=1:return False
    if not evidence.get('checks') or not all(c.get('ok') is True for c in evidence['checks']):return False
    installation=native.get('installation',{});app=evidence['applications'][0]
    selected=evidence.get('selected_installation')
    if not selected or not installation.get('directory'):return False
    normalize=lambda p:os.path.normcase(os.path.normpath(p))
    if normalize(selected)!=normalize(installation['directory']):return False
    libs=[x for x in app.get('libraries',[]) if x.get('name')=='videoeditor.dll']
    return (len(libs)==1 and bool(installation.get('engine_library_sha256'))
            and libs[0].get('sha256')==installation['engine_library_sha256']
            and app.get('version')==str(installation.get('version'))+'.'+str(installation.get('build'))
            and validation.get('asset_hashes_checked') is True)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--build',action='store_true',help='Build sample offline after identity checks')
    p.add_argument('--app-dir',type=pathlib.Path,help='Jianying version directory containing videoeditor.dll; process-local override')
    a=p.parse_args()
    if os.name!='nt':raise ValueError('Run this pilot on a Windows PC')
    if sys.version_info<(3,11):raise ValueError('Python 3.11 or newer is required')
    for rel,expected in json.loads((ROOT/'BUNDLE_SHA256.json').read_text(encoding='utf-8')).items():
        path=ROOT/rel
        if path.is_symlink() or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
            raise ValueError('Package file changed: '+rel)
    folder=ROOT/'results'/(datetime.datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:6]);folder.mkdir(parents=True)
    env=dict(os.environ,PYTHONUTF8='1')
    if a.app_dir:env['JY14_APP_BUNDLE']=str(a.app_dir.resolve(strict=True))
    def run(name,*args):
        r=subprocess.run([sys.executable,str(ROOT/'studio/run.py'),*map(str,args)],capture_output=True,text=True,
                         encoding='utf-8',env=env,timeout=300,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        (folder/(name+'.stdout.json')).write_text(r.stdout,encoding='utf-8')
        (folder/(name+'.stderr.txt')).write_text(r.stderr,encoding='utf-8')
        return {'step':name,'exit_code':r.returncode}
    rows=[run('doctor','doctor','--native'),run('validate','validate','--project',ROOT/'sample-project'),
          run('windows-evidence','windows-evidence','--out',folder/'environment.json')]
    compatible=False
    if all(x['exit_code']==0 for x in rows):
        try:
            read=lambda name:json.loads((folder/name).read_text(encoding='utf-8'))
            compatible=preflight_reports(read('doctor.stdout.json'),read('environment.json'),read('validate.stdout.json'))
        except (ValueError,OSError,KeyError,TypeError):compatible=False
    rows.append({'step':'preflight-report-consistency','exit_code':0 if compatible else 2})
    if a.build and compatible:
        # New work copy and name for each run; original bundle remains immutable.
        rows.append(run('package','package','--project',ROOT/'sample-project','--out',folder/'project'))
        if rows[-1]['exit_code']==0:
            project=folder/'project/project.json';data=json.loads(project.read_text(encoding='utf-8'))
            data['name']='Windows兼容测试-'+folder.name
            project.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
            rows.append(run('audio-audit','audio-audit','--project',folder/'project','--out',folder/'audio'))
            if rows[-1]['exit_code']==0:
                rows.append(run('build','build','--project',folder/'project','--audio-audit',folder/'audio/report.json','--out',folder/'build'))
    report={'steps':rows,'ui_actions':0,'draft_registration_requested':False,'native_visual_acceptance':'pending',
            'preflight_reports_consistent':compatible,'package_revision':'20260923-r2'}
    (folder/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2));print('Results: '+str(folder))
    return 0 if all(x['exit_code']==0 for x in rows) else 2
if __name__=='__main__':
    try:raise SystemExit(main())
    except (ValueError,OSError,subprocess.SubprocessError) as exc:
        print(str(exc),file=sys.stderr);raise SystemExit(2)
