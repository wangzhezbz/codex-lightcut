"""Privately attach an existing reviewed engine to this release, never overwrite it."""
import argparse
import os
import uuid
from pathlib import Path
from jianying_studio.platforms import host
from jianying_studio.storage import load,sha,require,asset_path,copy_file,save

MAC_PIN='e7c4e50b1c5c0caaf642838b99a673e4f6b1bb08724aa8499ee2982c38597ed6'


def attach(source):
    source=Path(source).resolve(strict=True)
    root=Path(__file__).resolve().parent.parent
    if host()=='windows':
        from jianying_studio.windows_backend import PIN
        lock=source/'STUDIO_SOURCE_LOCK.json';require(sha(lock)==PIN,'Existing Windows engine lock mismatch')
        files=dict(load(lock)['files']);files['STUDIO_SOURCE_LOCK.json']=PIN
        target=root/'upstream/jianying-headless-windows'
    else:
        require(host()=='macos','Only Mac and Windows are supported')
        lock=Path(__file__).parent/'resources/mac-runtime-source-lock.json'
        require(sha(lock)==MAC_PIN,'Mac runtime descriptor changed')
        files=load(lock)['files'];target=root/'upstream/jianying-headless'
    for relative,expected in files.items():require(sha(asset_path(source,relative))==expected,'Existing runtime differs: '+relative)
    existing = target.exists()
    missing = []
    for relative, expected in files.items():
        dst = target / relative
        if dst.exists() or dst.is_symlink():
            require(sha(asset_path(target,relative)) == expected, 'Installed runtime differs; refusing overwrite')
        else:
            missing.append(relative)
    if not missing:
        return {'status':'already-attached','host':host(),'files':len(files),'ui_actions':0}
    for relative in missing:
        src=asset_path(source,relative);dst=target/relative
        # Interrupted copies stay beside the target, never as an apparently
        # installed engine file. Re-entry fills only genuinely missing files.
        pending=dst.with_name(dst.name+'.pending-'+uuid.uuid4().hex)
        copy_file(src,pending)
        require(sha(pending)==files[relative], 'Runtime copy verification failed')
        if os.name!='nt':pending.chmod(0o755 if src.stat().st_mode & 0o111 else 0o644)
        require(not dst.exists(), 'Runtime was concurrently attached; retry verification')
        pending.rename(dst)
    require(all(sha(asset_path(target,n))==h for n,h in files.items()),'Runtime copy verification failed')
    return {'status':'resumed-existing-reviewed-engine' if existing else 'attached-existing-reviewed-engine',
            'host':host(),'files':len(files),'copied_files':len(missing),'target':str(target),'ui_actions':0}


if __name__=='__main__':
    import json
    p=argparse.ArgumentParser();p.add_argument('--source',required=True,type=Path)
    print(json.dumps(attach(p.parse_args().source),ensure_ascii=False))
