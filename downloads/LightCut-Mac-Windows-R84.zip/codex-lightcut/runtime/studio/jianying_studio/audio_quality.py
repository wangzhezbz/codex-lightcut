"""Offline audio reference analysis. Never plays sound or renders a video.

FFmpeg atempo/mixing is a diagnostic reference, not a claim of pixel/sample
identity with Jianying's native engine. All generated files stay in a new audit.
"""
import array
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
import sys
import time

from .media import probe
from .platforms import background_priority
from .project import validate
from .storage import asset_path, load, require, save

RATE = 48000


def run(args, *, stdout=subprocess.PIPE, timeout=120):
    result = subprocess.run(args, stdin=subprocess.DEVNULL, stdout=stdout, stderr=subprocess.PIPE,
                            timeout=timeout, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    require(result.returncode == 0, 'Audio analysis failed: ' + result.stderr.decode('utf-8', 'replace')[-1800:])
    return result


def envelope(seg):
    points = seg.get('keyframes', {}).get('volume')
    if not points: return str(seg.get('volume', 1))
    expr = str(points[-1]['value'])
    for left, right in reversed(list(zip(points, points[1:]))):
        a, b = left['at_us']/1e6, right['at_us']/1e6
        value = f"({left['value']}+({right['value']}-{left['value']})*(t-{a})/{b-a})"
        expr = f'if(lt(t,{b}),{value},{expr})'
    return expr


def tempo(speed):
    filters = []
    while speed > 2:
        filters.append('atempo=2'); speed /= 2
    while speed < .5:
        filters.append('atempo=0.5'); speed /= .5
    if abs(speed-1) > 1e-8: filters.append('atempo=' + str(speed))
    return filters


def render_reference(project, root, output, mode='mix'):
    info = validate(project, root)
    require(mode in ('mix', 'voice', 'music'), 'Unknown audio reference mode')
    root, output = Path(root), Path(output)
    require(not output.exists(), 'Audio output must be new')
    exe = shutil.which('ffmpeg'); require(exe is not None, 'ffmpeg is required')
    inputs, clips = {}, []
    for ti, track in enumerate(project['tracks']):
        if track['type'] not in ('video', 'audio'): continue
        if mode == 'voice' and track['type'] != 'video': continue
        if mode == 'music' and track['type'] != 'audio': continue
        for si, seg in enumerate(track['segments']):
            ident = seg['asset']; asset = project['assets'][ident]
            if asset['kind'] == 'image': continue
            if ident not in inputs:
                path = asset_path(root, asset['path'])
                metadata = probe(path)
                if not any(s['codec_type'] == 'audio' for s in metadata['streams']): continue
                inputs[ident] = {'path': path, 'uses': 0, 'input': len(inputs)}
            require(not seg.get('transition_out'), 'Audio reference does not yet reproduce native transition mixing')
            entry = inputs[ident]; use = entry['uses']; entry['uses'] += 1
            clips.append((entry, use, seg, ti, si))
    output.parent.mkdir(parents=True, exist_ok=True)
    args = [exe, '-nostdin', '-hide_banner', '-loglevel', 'error', '-n']
    graph = []
    for entry in inputs.values():
        args += ['-threads', '2', '-i', str(entry['path'])]
        labels = ''.join(f"[s{entry['input']}_{i}]" for i in range(entry['uses']))
        graph.append(f"[{entry['input']}:a:0]asplit={entry['uses']}{labels}")
    outputs = []
    for ci, (entry, use, seg, _, _) in enumerate(clips):
        start, span = seg.get('source_start_us', 0)/1e6, seg.get('source_duration_us', seg['duration_us'])/1e6
        length = seg['duration_us']/1e6
        filters = [f'atrim=start={start}:duration={span}', 'asetpts=PTS-STARTPTS'] + tempo(seg.get('speed', 1))
        filters += [f'aresample={RATE}', 'aformat=sample_fmts=flt:channel_layouts=stereo', f'apad=whole_dur={length}', f'atrim=duration={length}',
                    'asetnsamples=n=240:p=0', f"volume='{envelope(seg)}':eval=frame",
                    f"adelay={round(seg.get('start_us', 0)*RATE/1e6)}S:all=1", 'asetpts=N/SR/TB']
        label = f'o{ci}'; outputs.append(f'[{label}]')
        graph.append(f"[s{entry['input']}_{use}]" + ','.join(filters) + f'[{label}]')
    if outputs:
        graph.append(''.join(outputs) + f'amix=inputs={len(outputs)}:normalize=0:dropout_transition=0,asetpts=N/SR/TB,apad=whole_dur={info["duration_us"]/1e6},atrim=duration={info["duration_us"]/1e6}[mix]')
        args += ['-filter_complex_threads', '2', '-filter_complex', ';'.join(graph), '-map', '[mix]']
    else:
        args += ['-f', 'lavfi', '-i', f'anullsrc=r={RATE}:cl=stereo', '-t', str(info['duration_us']/1e6)]
    seconds = info['duration_us']/1e6
    byte_limit = math.ceil(seconds * RATE * 2 * 4) + 65536
    args += ['-t', str(seconds), '-fs', str(byte_limit), '-c:a', 'pcm_f32le', '-ar', str(RATE), '-threads', '2', str(output)]
    background_priority(); run(args)
    require(output.stat().st_size < byte_limit, 'Audio reference hit its byte limit')
    actual = probe(output)
    require(abs(float(actual['format']['duration']) - seconds) <= 1/RATE + 1e-6, 'Audio reference has wrong duration')
    return {'file': str(output), 'mode': mode, 'duration_us': info['duration_us'], 'clips': len(clips), 'native_render': False}


def measure(path):
    exe = shutil.which('ffmpeg'); require(exe is not None, 'ffmpeg required')
    result = run([exe, '-nostdin', '-hide_banner', '-i', str(path), '-vn', '-threads', '2',
                  '-af', 'loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json', '-f', 'null', '-'])
    text = result.stderr.decode('utf-8', 'replace'); a, b = text.rfind('{'), text.rfind('}')
    require(a >= 0 and b > a, 'No loudness measurement returned')
    measurement = json.loads(text[a:b+1])
    def numeric(key):
        n = float(measurement[key]); return n if math.isfinite(n) else None
    return {'integrated_lufs': numeric('input_i'), 'true_peak_dbtp': numeric('input_tp'),
            'loudness_range_lu': numeric('input_lra'), 'gated_threshold_lufs': numeric('input_thresh')}


def pcm(path):
    result = run([shutil.which('ffmpeg'), '-nostdin', '-hide_banner', '-loglevel', 'error', '-i', str(path),
                  '-vn', '-ar', str(RATE), '-af', 'pan=mono|c0=0.5*c0+0.5*c1', '-f', 'f32le', '-'])
    samples = array.array('f'); samples.frombytes(result.stdout)
    if sys.byteorder != 'little': samples.byteswap()
    return samples


def db(value):
    return 20*math.log10(max(value, 1e-10))


def boundary_metrics(samples, time_us, window_ms=20):
    i = round(time_us * RATE / 1e6); n = round(window_ms * RATE / 1000)
    if i <= 0 or i >= len(samples): return {'at_us': time_us, 'status': 'outside-audio'}
    left, right = samples[max(0, i-n):i], samples[i:min(len(samples), i+n)]
    rms = lambda values: math.sqrt(sum(v*v for v in values)/max(1, len(values)))
    return {'at_us': time_us, 'jump_dbfs': round(db(abs(samples[i]-samples[i-1])), 2),
            'left_rms_dbfs': round(db(rms(left)), 2), 'right_rms_dbfs': round(db(rms(right)), 2),
            'semantic_cut_acceptance': 'not-determined-by-waveform'}


def tail_metrics(samples):
    block = RATE//50; quiet = 0
    for end in range(len(samples), max(0,len(samples)-RATE), -block):
        values=samples[max(0,end-block):end]
        level=db(math.sqrt(sum(v*v for v in values)/max(1,len(values))))
        if level>=-45: break
        quiet+=len(values)
    return {'quiet_tail_ms':round(quiet/RATE*1000,2),'threshold_dbfs':-45,'window_ms':20,
            'semantic_completion':'not-established-by-silence'}


def audit(project, root, output):
    output = Path(output).resolve(); output.mkdir(parents=True, exist_ok=False)
    start = time.perf_counter(); stats = {}; paths = {}
    for mode in ('voice', 'music', 'mix'):
        path = output / (mode + '.wav'); paths[mode] = path
        render_reference(project, root, path, mode)
        stats[mode] = measure(path)
    samples = pcm(paths['voice'])
    cuts = [s.get('start_us', 0) for s in project['tracks'][0]['segments'][1:] if s.get('start_us', 0) > 0]
    metrics = [boundary_metrics(samples, t) for t in cuts]
    clip_levels = []
    for i, s in enumerate(project['tracks'][0]['segments']):
        if project['assets'][s['asset']]['kind'] != 'video': continue
        a, b = round(s.get('start_us', 0)*RATE/1e6), round((s.get('start_us', 0)+s['duration_us'])*RATE/1e6)
        values = samples[a:b]
        clip_levels.append({'segment': i, 'rms_dbfs': round(db(math.sqrt(sum(v*v for v in values)/max(1,len(values)))),2),
                            'sample_peak_dbfs': round(db(max((abs(v) for v in values),default=0)),2)})
    report = {'schema':'jianying-studio-audio-audit/v1','project_sha256':project_digest(project),
              'measurements':stats,'cut_boundaries':metrics,'voice_clips':clip_levels,'voice_tail':tail_metrics(samples),
              'seconds':time.perf_counter()-start,'reference':'ffmpeg-reference-not-native-jianying',
              'semantic_word_cuts':'requires-listening-or-word-alignment','ui_actions':0,'played_audio':False}
    save(output/'report.json',report)
    return report


def project_digest(project):
    return hashlib.sha256(json.dumps(project, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def gain_at(seg, at_us):
    points = seg.get('keyframes', {}).get('volume')
    if not points: return seg.get('volume', 1)
    if at_us <= points[0]['at_us']: return points[0]['value']
    for a, b in zip(points, points[1:]):
        if at_us <= b['at_us']:
            return a['value']+(b['value']-a['value'])*(at_us-a['at_us'])/(b['at_us']-a['at_us'])
    return points[-1]['value']


def refine(project, audit_report, *, target_lufs=-16, duck_gain=.22):
    """Retune an independently saved copy; no source trim or timing changes."""
    from copy import deepcopy
    import statistics
    from .operations import duck_music
    from .project import number
    number(target_lufs, 'Voice target', -24, -12); number(duck_gain, 'Ducking gain', .01, 1)
    require(audit_report.get('project_sha256') == project_digest(project), 'Audio audit belongs to a different project')
    voice = audit_report['measurements']['voice']
    require(voice['integrated_lufs'] is not None and voice['true_peak_dbtp'] is not None, 'Voice is silent or unmeasurable')
    result = deepcopy(project)
    measured = audit_report['voice_clips']; median = statistics.median(n['rms_dbfs'] for n in measured)
    global_db = min(target_lufs - voice['integrated_lufs'], -2 - voice['true_peak_dbtp'])
    gains = []
    for row in measured:
        i = row['segment']; seg = result['tracks'][0]['segments'][i]
        require(not seg.get('keyframes', {}).get('volume'), 'Cannot replace existing voice automation')
        adjustment = max(-2, min(2, median-row['rms_dbfs']))
        total = global_db + adjustment
        value = seg.get('volume', 1) * 10**(total/20)
        require(0 <= value <= 4, 'Required voice gain is outside the native range')
        seg['volume'] = round(value, 8)
        gains.append({'segment':i,'gain_db':round(total,3),'native_volume':seg['volume']})
    speech = [[s.get('start_us',0), s.get('start_us',0)+s['duration_us']] for t in result['tracks'] if t['type']=='text' for s in t['segments']]
    require(speech, 'Ducking needs speech/caption intervals')
    music_tracks = [i for i,t in enumerate(result['tracks']) if t['type']=='audio']
    require(len(music_tracks) == 1, 'Select a music track explicitly before refining a multi-audio project')
    track = music_tracks[0]
    # This operation explicitly replaces music automation in the new copy.
    for seg in result['tracks'][track]['segments']:
        seg.pop('keyframes', None); seg['volume'] = 1.0
    result = duck_music(result, track, speech, gain=duck_gain, attack_us=180000, release_us=650000)
    for seg in result['tracks'][track]['segments']:
        span = seg['duration_us']; original = deepcopy(seg)
        fade_in, fade_out = min(200000,span), min(500000,span)
        times = {p['at_us'] for p in seg['keyframes']['volume']} | {0,span,fade_in,span-fade_out}
        times.update(range(0,fade_in,50000)); times.update(range(span-fade_out,span,50000))
        pts = []
        for t in sorted(times):
            edge = min(1,t/fade_in,(span-t)/fade_out)
            pts.append({'at_us':t,'value':round(gain_at(original,t)*max(0,edge),8)})
        seg['volume'] = pts[0]['value']; seg['keyframes'] = {'volume':pts}
    validate(result, verify_assets=False)
    return result, {'target_voice_lufs':target_lufs,'global_gain_db':round(global_db,3),'clip_gains':gains,
                    'music_duck_gain':duck_gain,'attack_ms':180,'release_ms':650,'music_fade_in_ms':200,'music_fade_out_ms':500,
                    'cuts_changed':False,'music_automation_replaced_in_copy':True,'requires_after_measurement':True}
