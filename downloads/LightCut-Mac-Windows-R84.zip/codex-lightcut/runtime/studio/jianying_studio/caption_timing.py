"""Map reviewed source-time captions through the FINAL edit, on either OS.

This does not align speech. Coarse ASR timestamps must be corrected first.
Never duplicate the full text of a partially removed sentence across a cut.
"""
from copy import deepcopy
from fractions import Fraction

from .storage import require


def map_captions(clips, captions):
    """Return timeline cues and provenance; source identifiers match exactly.

    Each cue has source, start_us, duration_us, text and optional text style.
    Entirely removed cues are dropped. Partially removed cues fail closed:
    caller must supply shorter, reviewed word/phrase cues or realign final audio.
    Repeated source footage deliberately produces repeated captions.
    """
    from .project import TEXT_FIELDS, fields, integer, number
    windows = []
    previous = 0
    for index, clip in enumerate(clips):
        start = clip.get('start_us', 0)
        duration = clip['duration_us']
        integer(start, 'Clip start'); integer(duration, 'Clip duration', 1)
        require(start >= previous, 'Caption mapping requires ordered non-overlapping clips')
        previous = start + duration
        source_start = clip.get('source_start_us', 0)
        source_duration = clip.get('source_duration_us', duration)
        integer(source_start, 'Source start'); integer(source_duration, 'Source duration', 1)
        number(clip.get('speed', 1), 'Speed', .1, 8)
        require(abs(source_duration / clip.get('speed', 1) - duration) <= 2,
                'Caption mapping speed/timing mismatch')
        require(isinstance(clip.get('source'), str) and clip['source'], 'Clip source missing')
        windows.append((index, clip, source_start, source_start + source_duration))
    result, evidence, removed = [], [], []
    sources = {c['source'] for c in clips}
    for cue_index, cue in enumerate(captions):
        fields(cue, TEXT_FIELDS | {'source'}, 'Source caption')
        require(cue.get('source') in sources, 'Caption source does not match main video')
        a, span = cue.get('start_us', 0), cue['duration_us']
        integer(a, 'Caption source start'); integer(span, 'Caption source duration', 1)
        b = a + span
        require(isinstance(cue.get('text'), str) and cue['text'].strip(), 'Empty source caption')
        require(not cue.get('keyframes'), 'Realign caption animation after editing')
        hits = [(i, c, x, y) for i, c, x, y in windows
                if c['source'] == cue['source'] and max(a, x) < min(b, y)]
        if not hits:
            removed.append(cue_index)
            continue
        for i, c, x, y in hits:
            require(x <= a and b <= y,
                    f'字幕 {cue_index}「{cue["text"]}」跨剪切边界 ({a}–{b} us, clip {i}); '
                    '请按保留字词重新分句并对齐，禁止把整句复制到接缝两侧')
            # Absolute endpoints, not accumulated rounded durations. Includes
            # covers, gaps and the actual rounded source span of each clip.
            scale = Fraction(c['duration_us'], y - x)
            start = c.get('start_us', 0) + round((a - x) * scale)
            end = c.get('start_us', 0) + round((b - x) * scale)
            require(end > start, 'Caption shorter than timeline precision')
            mapped = deepcopy(cue); mapped.pop('source')
            mapped.update(start_us=start, duration_us=end-start)
            result.append(mapped)
            evidence.append({'cue': cue_index, 'clip': i, 'source_start_us': a,
                             'source_end_us': b, 'start_us': start, 'end_us': end})
    ordered = sorted(zip(result, evidence), key=lambda pair: pair[0]['start_us'])
    for left, right in zip(ordered, ordered[1:]):
        require(left[0]['start_us'] + left[0]['duration_us'] <= right[0]['start_us'],
                'Mapped captions overlap; review source word timestamps')
    return [p[0] for p in ordered], {'mapped': [p[1] for p in ordered],
                                   'removed_cues': removed, 'speech_alignment_verified': False}


def expand_plan(plan):
    """Optional source_captions track becomes a normal native text track."""
    from .project import fields
    result = deepcopy(plan)
    spec = result.pop('source_captions', None)
    if spec is None:
        return result, None
    fields(spec, {'name', 'segments'}, 'Source captions')
    require(isinstance(spec.get('segments'), list), 'Source captions must be a list')
    require(result.get('tracks') and result['tracks'][0]['type'] == 'video', 'Main video missing')
    cues, report = map_captions(result['tracks'][0]['segments'], spec['segments'])
    if cues:
        result['tracks'].append({'type': 'text', 'name': spec.get('name', '字幕'), 'segments': cues})
    return result, report
