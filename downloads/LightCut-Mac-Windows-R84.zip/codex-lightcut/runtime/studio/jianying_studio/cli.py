import argparse
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys

from . import __version__
from .platforms import diagnose, host
from .project import compile_plan, import_plan, package_project, validate
from .storage import load, require, save


def main(argv=None):
    parser = argparse.ArgumentParser(description='后台剪辑工程工具：不启动剪映，不模拟输入，不默认导出视频。')
    parser.add_argument('--version', action='version', version=__version__)
    subs = parser.add_subparsers(dest='command', required=True)
    subs.add_parser('capabilities', help='新版双端能力及验收范围，不操作剪映')
    p = subs.add_parser('transcribe-local', help='使用独立安装的本地模型转写，不上传原片、不自动生成剪辑决定')
    p.add_argument('--source', required=True, type=Path)
    p.add_argument('--out', required=True, type=Path)
    p.add_argument('--model', type=Path)
    p = subs.add_parser('prepare-selected', help='按选定风格检查新版双端资源')
    p.add_argument('--style', required=True, type=Path)
    p.add_argument('--out', required=True, type=Path)
    p.add_argument('--profile', type=Path)
    p.add_argument('--allow-download', action='store_true')
    p = subs.add_parser('windows-style-prepare', help='联合风格试运行：按所选效果准备Windows资源，不读旧草稿')
    p.add_argument('--style', required=True, type=Path)
    p.add_argument('--out', required=True, type=Path)
    p.add_argument('--profile', required=True, type=Path)
    p.add_argument('--allow-download', action='store_true')
    p = subs.add_parser('windows-filter-prepare', help='准备 Windows 高清增强资源，保留官方权益标记；不导出')
    p.add_argument('--out', required=True, type=Path)
    p = subs.add_parser('windows-filter-copy', help='给已确认草稿的新副本追加高清增强12%%，保留原草稿')
    p.add_argument('--source', required=True, type=Path)
    p.add_argument('--resource', required=True, type=Path)
    p.add_argument('--out', required=True, type=Path)
    for cmd in ('windows-filter-verify', 'windows-filter-register'):
        p = subs.add_parser(cmd)
        p.add_argument('--build', required=True, type=Path)
        if cmd == 'windows-filter-register': p.add_argument('--audit', required=True, type=Path)
    p = subs.add_parser('preferences-catalog', help='四组创作选项与五种封面风格；不是自动确认')
    p = subs.add_parser('preferences-start', help='建立本次创作设置，复用已保存默认')
    p.add_argument('--home', type=Path)
    p = subs.add_parser('preferences-defaults', help='查看默认设置，不修改')
    p.add_argument('--home', type=Path)
    p = subs.add_parser('preferences-asset', help='记录用户已选素材的路径和摘要')
    p.add_argument('--path', type=Path, required=True)
    for cmd in ('preferences-status', 'preferences-update', 'preferences-confirm', 'preferences-cover', 'preferences-bindings', 'preferences-apply'):
        p = subs.add_parser(cmd)
        p.add_argument('--session', type=Path, required=True)
        if cmd != 'preferences-status': p.add_argument('--revision', type=int, required=True)
        if cmd == 'preferences-update':
            p.add_argument('--patch', type=Path)
            p.add_argument('--recommended', nargs='+', choices=('cover','effects','music','editing'))
        if cmd == 'preferences-confirm': p.add_argument('--scope', required=True, choices=('once','defaults'))
        if cmd == 'preferences-cover':
            a = p.add_mutually_exclusive_group(required=True)
            a.add_argument('--image', type=Path); a.add_argument('--approve', action='store_true')
            p.add_argument('--title')
        if cmd in ('preferences-bindings','preferences-apply'):
            p.add_argument('--project', type=Path, required=True)
            p.add_argument('--out', type=Path, required=True)
        if cmd == 'preferences-apply': p.add_argument('--bindings', type=Path, required=True)
    p = subs.add_parser('windows-effects-build', help='显式 Windows 原生效果分项测试；不作为完整风格交付、不登记')
    p.add_argument('--project', required=True, type=Path)
    p.add_argument('--out', required=True, type=Path)
    p.add_argument('--scope', required=True, choices=('beauty','adjustment','beauty-adjustment'))
    p = subs.add_parser('windows-effects-verify', help='分项效果资源、原生回读和镜像验证')
    p.add_argument('--build', required=True, type=Path)
    p = subs.add_parser('windows-effects-register', help='显式登记美颜/调色开发测试草稿，等待用户最终验收')
    p.add_argument('--build', required=True, type=Path)
    p.add_argument('--audit', required=True, type=Path)
    p = subs.add_parser('setup', help='自动检查默认风格和本机资源，不打开剪映、不读取草稿')
    p.add_argument('--out', type=Path)
    p.add_argument('--release-preview', action='store_true', help='新版双端首次检查，只读且不确认推荐设置')
    p = subs.add_parser('deliver', help='应用默认风格、检测、音频质检、构建；可后台排队登记')
    p.add_argument('--project', required=True, type=Path)
    p.add_argument('--out', required=True, type=Path)
    p.add_argument('--register', action='store_true')
    p.add_argument('--windows-style-pilot', action='store_true', help='显式启用Windows三项效果联合试运行，尚非正式支持')
    p.add_argument('--release-preview', action='store_true', help='新版双端统一预览，按已确认会话准备所选资源')
    p.add_argument('--session', type=Path)
    p.add_argument('--revision', type=int)
    p.add_argument('--bindings', type=Path)
    p = subs.add_parser('doctor', help='检测当前机器，不写剪映文件')
    p.add_argument('--native', action='store_true')
    p = subs.add_parser('windows-evidence', help='在Windows采集版本与程序库指纹，不读取账号或草稿内容')
    p.add_argument('--app', type=Path); p.add_argument('--draft-root', type=Path); p.add_argument('--out', type=Path, required=True)
    p = subs.add_parser('enqueue-publish', help='后台等待剪映自然退出，再登记已验证草稿')
    p.add_argument('--build', type=Path, required=True); p.add_argument('--job', type=Path, required=True)
    p.add_argument('--timeout', type=int, default=86400)
    p = subs.add_parser('job-status'); p.add_argument('--job', type=Path, required=True)
    p = subs.add_parser('cancel-job'); p.add_argument('--job', type=Path, required=True)
    p = subs.add_parser('_publish-job', help=argparse.SUPPRESS); p.add_argument('--job', type=Path, required=True)
    p = subs.add_parser('import-plan', help='将已有计划和素材装入可迁移工程')
    p.add_argument('--plan', required=True, type=Path); p.add_argument('--out', required=True, type=Path)
    from .onboarding import DEFAULT_STYLE
    p.add_argument('--style', type=Path, default=DEFAULT_STYLE)
    p = subs.add_parser('prepare-media', help='后台预处理素材，保留原片；结果可复用缓存')
    p.add_argument('--source', required=True, type=Path); p.add_argument('--recipe', required=True, type=Path)
    p.add_argument('--cache', required=True, type=Path)
    for command in ('audio-audit', 'refine-sound', 'quality-check'):
        p = subs.add_parser(command)
        p.add_argument('--project', required=True, type=Path); p.add_argument('--out', required=True, type=Path)
        if command != 'audio-audit': p.add_argument('--audio-audit', type=Path, required=command=='refine-sound')
        if command == 'quality-check': p.add_argument('--build', type=Path)
        if command == 'refine-sound':
            p.add_argument('--name', required=True); p.add_argument('--target-lufs', type=float, default=-16)
    for command in ('validate', 'compile', 'package', 'build', 'duck', 'apply-style'):
        p = subs.add_parser(command)
        p.add_argument('--project', required=True, type=Path)
        if command != 'validate': p.add_argument('--out', required=True, type=Path)
        if command == 'build':
            p.add_argument('--native-profile', type=Path)
            p.add_argument('--audio-audit', type=Path)
        if command == 'duck':
            p.add_argument('--track', type=int, required=True); p.add_argument('--speech', type=Path, required=True)
            p.add_argument('--gain', type=float, default=.16)
        if command == 'apply-style': p.add_argument('--style', type=Path, required=True)
    p = subs.add_parser('capture-profile', help='采集本机已授权效果样本，仅适配当前Mac')
    p.add_argument('--snapshots', type=Path, required=True); p.add_argument('--catalog', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    for command in ('verify-build', 'publish'):
        p = subs.add_parser(command); p.add_argument('--build', type=Path, required=True)
        if command == 'publish':
            p.add_argument('--audit', type=Path, required=True); p.add_argument('--wait-seconds', type=int, default=0)
    args = parser.parse_args(argv)
    try:
        command = args.command
        if command.startswith('preferences-'):
            from . import preferences as pref, preference_project
            if command == 'preferences-catalog': result = pref.catalog()
            elif command == 'preferences-start': result = pref.start(args.home)
            elif command == 'preferences-defaults': result = pref.defaults(args.home) or {'status':'no-saved-defaults'}
            elif command == 'preferences-asset': result = pref.asset(args.path)
            elif command == 'preferences-status': result = pref.status(args.session)
            elif command == 'preferences-update':
                require(args.patch or args.recommended, '需要用户选择的设置或明确接受推荐设置')
                result = pref.update(args.session, args.revision, load(args.patch) if args.patch else {}, recommended=args.recommended or ())
            elif command == 'preferences-confirm': result = pref.confirm(args.session, args.revision, scope=args.scope)
            elif command == 'preferences-cover': result = pref.cover_review(args.session, args.revision, image=args.image, title=args.title, approve=args.approve)
            elif command == 'preferences-bindings':
                result = preference_project.bindings_template(args.session, args.revision, args.project)
                save(args.out, result)
            else: result = preference_project.apply(args.session, args.revision, args.project, args.out, load(args.bindings))
        elif command == 'capabilities':
            from .release import capabilities
            result = capabilities()
        elif command == 'prepare-selected':
            from .release import prepare as prepare_release
            result, profile = prepare_release(load(args.style), allow_download=args.allow_download)
            save(args.out, result)
            if profile and args.profile: save(args.profile, profile)
        elif command == 'windows-style-prepare':
            from .windows_style_setup import prepare as prepare_windows
            result, profile = prepare_windows(load(args.style), allow_download=args.allow_download)
            save(args.out, result)
            if profile: save(args.profile, profile)
        elif command == 'windows-filter-prepare':
            from .windows_filter_resource import fetch
            result = {k: v for k, v in fetch(args.out).items() if k not in ('files', 'models')}
        elif command in ('windows-filter-copy', 'windows-filter-verify', 'windows-filter-register'):
            from . import windows_filter_build
            if command == 'windows-filter-copy': result = windows_filter_build.build(args.source, args.resource, args.out)
            elif command == 'windows-filter-verify': result = windows_filter_build.verify(args.build)
            else: result = windows_filter_build.register(args.build, args.audit)
        elif command == 'windows-effects-register':
            from .windows_effect_registration import register
            result = register(args.build, args.audit)
        elif command in ('windows-effects-build', 'windows-effects-verify'):
            from . import windows_effect_build
            result = (windows_effect_build.build(args.project, args.out, args.scope) if command == 'windows-effects-build'
                      else windows_effect_build.verify(args.build))
        elif command == 'transcribe-local':
            from .local_asr import transcribe
            result = transcribe(args.source, args.out, args.model)
        elif command == 'setup':
            if args.release_preview:
                from .release import prepare
                from .preferences import recommendations, catalog
                result, _ = prepare(recommendations()['effects'])
                result['platform_notice'] = catalog()['platform_notice']
                result['recommendations_are_confirmations'] = False
            else:
                from .onboarding import prepare
                result, _ = prepare()
            if args.out: save(args.out, result)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0 if result['status'] == 'ready-for-build' else 2
        elif command == 'deliver':
            from .delivery import deliver
            result = deliver(args.project, args.out, register=args.register,
                             session=args.session, revision=args.revision,
                             bindings=load(args.bindings) if args.bindings else None,
                             windows_style_pilot=args.windows_style_pilot, release_preview=args.release_preview)
        elif command == 'doctor':
            result = diagnose()
            if args.native:
                if host() == 'windows':
                    from .windows_backend import doctor
                    result['native_check'] = doctor()
                elif host() != 'macos': result['native_check'] = {'status': 'unsupported'}
                else:
                    from .mac_backend import engine
                    result['native_check'] = engine()[0].nd.validate_runtime()
        elif command in ('enqueue-publish', 'job-status', 'cancel-job', '_publish-job'):
            from .jobs import enqueue, work
            if command == 'enqueue-publish': result = enqueue(args.build, args.job, args.timeout)
            elif command == '_publish-job': result = work(args.job)
            elif command == 'job-status': result = load(args.job / 'state.json')
            else:
                require((args.job / 'request.json').is_file(), 'Not a job directory')
                status = load(args.job / 'state.json')['status']
                require(status in ('queued', 'waiting-for-editor-to-close'), 'Job has already committed or stopped')
                save(args.job / 'cancel.request', {'cancel': True})
                result = {'status': 'cancellation-requested', 'job': str(args.job.resolve())}
        elif command == 'windows-evidence':
            from .windows_probe import collect
            result = collect(args.app, args.draft_root); save(args.out, result)
        elif command in ('audio-audit', 'refine-sound', 'quality-check'):
            from .audio_quality import audit, refine
            from .quality import inspect
            project = load(args.project/'project.json')
            if command == 'audio-audit': result = audit(project,args.project,args.out)
            elif command == 'quality-check':
                result = inspect(project,args.project,audio_report=load(args.audio_audit) if args.audio_audit else None,build=args.build)
                save(args.out,result)
                print(json.dumps(result,ensure_ascii=False,indent=2)); return 2 if result['errors'] else 0
            else:
                revised,changes=refine(project,load(args.audio_audit),target_lufs=args.target_lufs)
                revised['name']=args.name; validate(revised,args.project)
                package_project(args.project,args.out); save(args.out/'project.json',revised,replace=True)
                save(args.out/'sound-changes.json',changes)
                result={'status':'sound-refined','project':str(args.out/'project.json'),'changes':changes}
        elif command == 'prepare-media':
            from .media import prepare
            result = prepare(args.source, load(args.recipe), args.cache)
        elif command == 'import-plan':
            project = import_plan(args.plan, args.out, load(args.style))
            result = validate(project, args.out)
            result['project'] = str(args.out.resolve() / 'project.json')
        elif command in ('validate', 'compile'):
            root = args.project.resolve(); project = load(root / 'project.json')
            if command == 'validate': result = validate(project, root)
            else:
                plan = compile_plan(project, root); save(args.out, plan)
                result = {'status': 'compiled', 'plan': str(args.out.resolve()), 'native_draft': False,
                          'native_backend': 'macos-adapter' if host() == 'macos' else 'windows-experimental'}
        elif command == 'package': result = package_project(args.project, args.out)
        elif command in ('duck', 'apply-style'):
            from .operations import duck_music
            source = load(args.project / 'project.json')
            if command == 'duck': result_project = duck_music(source, args.track, load(args.speech), gain=args.gain)
            else:
                result_project = deepcopy(source); result_project['style'] = load(args.style)
                validate(result_project, args.project)
            package_project(args.project, args.out)
            save(args.out / 'project.json', result_project, replace=True)
            result = validate(result_project, args.out)
            result['project'] = str(args.out.resolve() / 'project.json')
        else:
            from .native_backend import current
            backend = current()
            if command == 'capture-profile' and host() != 'macos': raise ValueError('Native profile capture is only adapted on Mac')
            if command == 'capture-profile': result = backend.create_profile(args.snapshots, args.out, args.catalog)
            elif command == 'build': result = backend.build(args.project, args.out, args.native_profile, args.audio_audit)
            elif command == 'verify-build':
                r = backend.verify(args.build)
                result = {'status': 'verified', 'name': r['name'], 'acceptance': r['acceptance']}
            elif command == 'publish': result = backend.publish(args.build, args.audit, args.wait_seconds)
            else: raise ValueError('Unknown command')
        print(json.dumps(result, ensure_ascii=False, indent=2))
        if command == 'windows-evidence':
            return 0 if result.get('status') == 'complete' and result.get('applications') else 2
        if command == 'doctor' and host() == 'windows' and args.native:
            checks = result.get('native_check', {}).get('checks', [])
            return 0 if checks and all(c.get('ok') for c in checks) else 2
        if result.get('status') == 'needs-attention': return 2
        return 3 if result.get('status') == 'waiting-for-editor-to-close' else 0
    except (ValueError, OSError, KeyError, StopIteration, ImportError, RuntimeError, subprocess.SubprocessError) as error:
        print(json.dumps({'status': 'failed', 'command': args.command, 'error': str(error),
                          'ui_actions': 0, 'files_deleted': False}, ensure_ascii=False), file=sys.stderr)
        return 2
