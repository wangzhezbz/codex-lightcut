"""Cover asset dimensions are independent of the video canvas, on both hosts."""
import json
import subprocess
from .storage import require


def validate_size(size):
    if size is None: return
    require(isinstance(size, dict) and set(size) == {'width', 'height'}, '封面尺寸须包含 width/height')
    require(all(type(size[k]) is int and 16 <= size[k] <= 8192 for k in size), '封面尺寸须为 16–8192 的整数像素')


def verify(path, size):
    validate_size(size)
    if size is None: return None  # Legacy choices: never infer size from the video canvas.
    result = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v:0',
        '-show_entries', 'stream=width,height:stream_side_data=rotation', '-of', 'json', str(path)],
        stdin=subprocess.DEVNULL, capture_output=True, timeout=15,
        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    require(result.returncode == 0, '无法读取封面实际尺寸，请检查图片和 ffprobe')
    streams = json.loads(result.stdout).get('streams', [])
    require(len(streams) == 1, '封面没有可读取的图像尺寸')
    stream = streams[0]
    actual = {k: stream.get(k) for k in ('width', 'height')}
    require(not any(s.get('rotation', 0) for s in stream.get('side_data_list', [])), '封面含旋转标记，请先规范方向并复核尺寸')
    require(actual == size, f"封面尺寸不符：要求 {size['width']}×{size['height']}，实际 {actual['width']}×{actual['height']}；不能以正片画布替代封面尺寸")
    return actual
