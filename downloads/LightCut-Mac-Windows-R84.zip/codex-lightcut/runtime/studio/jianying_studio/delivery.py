"""Agent-facing default delivery pipeline for an already edited portable project.

Speech recognition and editorial decisions precede this step. Existing source
projects/drafts are never overwritten. No editor UI calls.
"""
from pathlib import Path
from .storage import load, save, require
from .project import package_project, validate
from .onboarding import DEFAULT_STYLE, prepare


def deliver(project_dir, output, *, register=False, session=None, revision=None, bindings=None, windows_style_pilot=False,
            release_preview=False):
    project_dir, output = Path(project_dir).resolve(), Path(output).resolve()
    require(not output.exists(), '交付目录已存在；请使用新的输出目录')
    require(not (release_preview and windows_style_pilot), 'Select one delivery preview entry')
    require(not release_preview or session is not None, '新版交付必须使用已确认的创作会话')
    # Readiness is checked before expensive media copying or rendering.
    source = load(project_dir / 'project.json')
    validate(source, project_dir)
    if session is not None:
        from . import preference_project, preferences
        require(revision is not None and bindings is not None, '交付需要当前偏好版本与素材角色记录')
        selected, _ = preference_project.configured(session, revision, project_dir, bindings)
        if release_preview:
            from .release import prepare as prepare_release
            report, profile = prepare_release(selected['style'], allow_download=True)
        elif windows_style_pilot:
            from .windows_style_setup import prepare as prepare_windows
            report, profile = prepare_windows(selected['style'], allow_download=True)
        else:
            report, profile = prepare(style=selected['style'])
    else:
        require(revision is None and bindings is None, '偏好参数缺少 session')
        require('creative_policy' not in source, '此工程已含确认的创作选择，请携带当前会话交付，不能重置为默认风格')
        if windows_style_pilot:
            from .windows_style_setup import prepare as prepare_windows
            report, profile = prepare_windows(load(DEFAULT_STYLE), allow_download=True)
        else:
            report, profile = prepare()
    output.mkdir(parents=True, exist_ok=False)
    save(output / 'setup.json', report)
    if report['status'] != 'ready-for-build':
        result = {'status': 'needs-attention', 'stage': 'setup', 'blockers': report['blockers'],
                  'draft_created': False, 'ui_actions': 0, 'report': str(output / 'setup.json')}
        save(output / 'result.json', result)
        return result
    project_root = output / 'project'
    if session is not None:
        preference_project.apply(session, revision, project_dir, project_root, bindings)
    else:
        package_project(project_dir, project_root)
    project = load(project_root / 'project.json')
    if session is None: project['style'] = load(DEFAULT_STYLE)
    # Names must be unique before registration, even when reusing one input.
    from datetime import datetime
    import uuid
    project['name'] = ('轻剪联合试运行-' if windows_style_pilot else '轻剪-') + datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:6]
    layout = load(Path(__file__).resolve().parents[1] / 'presets/竖屏字幕位置.json')
    if session is None and project['canvas']['width'] * 16 == project['canvas']['height'] * 9:
        for track in project['tracks']:
            if track['type'] != 'text': continue
            for segment in track['segments']:
                require(not any(k in segment.get('keyframes', {}) for k in ('x', 'y', 'scale')),
                        '字幕已有位置动画，需要先明确其与默认位置的关系')
                segment.update(size=layout['font_size'], **layout['native_transform'])
    validate(project, project_root)
    save(project_root / 'project.json', project, replace=True)
    if session is not None:
        from .audio_quality import project_digest
        receipt = load(project_root / 'creative-settings.json')
        receipt['project_sha256'] = project_digest(project)
        save(project_root / 'creative-settings.json', receipt, replace=True)
    if profile: save(output / 'native-profile.json', profile)
    from .quality import inspect
    quality = inspect(project, project_root)
    save(output / 'quality.json', quality)
    require(not quality['errors'], '工程质检失败；请查看交付目录中的 quality.json')
    from .audio_quality import audit
    audio_dir = output / 'audio'
    audit(project, project_root, audio_dir)
    from .native_backend import current
    backend = current()
    build_root = output / 'build'
    built = backend.build(project_root, build_root,
                          output / 'native-profile.json' if profile else None, audio_dir / 'report.json')
    backend.verify(build_root)
    if session is not None: preferences.execution(session, revision)
    result = {'status': 'built-offline', 'name': built['name'], 'build': str(build_root),
              'default_style': project['style']['name'], 'ui_actions': 0,
              'acceptance': built['acceptance'], 'audio_parameters': 'preserved-from-input-project'}
    if session is not None:
        result.update(creative_settings=str(project_root / 'creative-settings.json'),
                      preference_revision=revision, audio_parameters='confirmed-creative-settings')
    if register:
        from .jobs import enqueue
        guard = {'session': str(Path(session).resolve()), 'revision': revision} if session is not None else None
        result['registration'] = enqueue(build_root, output / 'publish-job', 86400, preference_guard=guard)
        result['status'] = 'registration-queued'
    save(output / 'result.json', result)
    return result
