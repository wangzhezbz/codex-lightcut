"""Editable visual ending shared by Mac and Windows; never changes audio."""
from copy import deepcopy
import hashlib
from pathlib import Path
import struct
import zlib

from .project import validate
from .storage import require

NAME = '轻剪片尾渐隐'


def black_png(width, height):
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
    # One-bit grayscale, zero pixels = black; full canvas aspect ratio.
    rows = (b'\0' + bytes((width + 7)//8)) * height
    return (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 1, 0, 0, 0, 0))
            + chunk(b'IDAT', zlib.compress(rows)) + chunk(b'IEND', b''))


def fade_tracks(project):
    """Recognize our track and the preceding Mac helper's exact track shape."""
    end = validate(project, verify_assets=False)['duration_us']
    found = []
    for i, track in enumerate(project['tracks']):
        if track.get('name') not in (NAME, '片尾淡出') or track['type'] != 'video' or len(track['segments']) != 1:
            continue
        segment = track['segments'][0]
        points = segment.get('keyframes', {}).get('opacity', [])
        if (project['assets'][segment['asset']]['kind'] == 'image'
                and segment.get('volume', 1) == 0 and segment.get('opacity') == 0
                and segment.get('start_us', 0) + segment['duration_us'] == end
                and len(points) == 2 and points[0] == {'at_us': 0, 'value': 0}
                and points[-1]['value'] == 1):
            found.append(i)
    return found


def apply(project, root, milliseconds):
    """Apply an explicitly selected ending to a newly copied project."""
    require(type(milliseconds) is int and 0 <= milliseconds <= 3000, '片尾渐隐须为 0–3000 毫秒')
    result = deepcopy(project)
    existing = fade_tracks(result)
    require(len(existing) <= 1, '发现多个片尾渐隐轨道，请先明确保留哪一个')
    info = validate(result, verify_assets=False)
    if existing:
        index = existing[0]
        # Remove only a recognized visual ending. Adjust role indices when an
        # older project happened to put another role-bearing track after it.
        result['tracks'].pop(index)
        if 'creative_policy' in result:
            result['creative_policy']['music_tracks'] = [i-(i>index) for i in result['creative_policy']['music_tracks']]
    if not milliseconds:
        return result
    fps = result['canvas']['fps']
    frame = 1e6 / fps
    available_frames = int(info['duration_us'] / frame + 1e-5)
    require(available_frames >= 2, '视频不足两帧，不能添加渐隐')
    count = min(available_frames, max(2, round(milliseconds * fps / 1000)))
    duration = round(count * frame)
    duration = min(duration, info['duration_us'])
    # End on the final displayed frame, not at the exclusive timeline endpoint.
    last_key = round(duration - frame)
    canvas = result['canvas']; payload = black_png(canvas['width'], canvas['height'])
    checksum = hashlib.sha256(payload).hexdigest()
    ident = 'lightcut-end-fade-' + checksum[:16]
    relative = 'assets/' + ident + '.png'
    target = Path(root) / relative
    if target.exists(): require(target.read_bytes() == payload, '片尾黑色素材内容不匹配')
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as f: f.write(payload)
    result['assets'][ident] = {'kind':'image','path':relative,'sha256':checksum,'size':len(payload)}
    result['tracks'].append({'type':'video','name':NAME,'segments':[
        {'asset':ident,'start_us':info['duration_us']-duration,'duration_us':duration,
         'opacity':0,'volume':0,'keyframes':{'opacity':[{'at_us':0,'value':0},{'at_us':last_key,'value':1}]}}]})
    validate(result, root)
    return result


def verify_native(project, timeline):
    indices = fade_tracks(project)
    for index in indices:
        expected = project['tracks'][index]['segments'][0]
        actual = timeline['tracks'][index]['segments'][0]
        require(timeline['tracks'][index]['type'] == 'video', '片尾渐隐原生轨道缺失')
        require(actual['target_timerange'] == {'start':expected['start_us'],'duration':expected['duration_us']}, '片尾渐隐时间改变')
        require(actual.get('volume') == 0 and actual.get('clip',{}).get('alpha') == 0, '片尾渐隐初始值改变')
        groups = [g for g in actual.get('common_keyframes',[]) if g['property_type']=='KFTypeAlpha']
        require(len(groups)==1, '片尾渐隐透明度关键帧缺失')
        points = [{'at_us':k['time_offset'],'value':k['values'][0]} for k in groups[0]['keyframe_list']]
        require(points == expected['keyframes']['opacity'], '片尾渐隐关键帧改变')
    return {'tracks':len(indices),'native_keyframes':'verified' if indices else 'not-requested','visual':'not-checked'}
