"""Restore verified static speech gain after the upstream capped base builder."""
from copy import deepcopy
from .storage import require


def stage(plan):
    base = deepcopy(plan)
    for track in base['tracks']:
        for seg in track['segments']:
            if seg.get('volume', 1) > 4:
                require(track['type'] == 'video' and not seg.get('keyframes', {}).get('volume'),
                        'High gain supports static video speech only')
                require(seg['volume'] <= 5.6234130859375, 'Unverified speech gain')
                seg['volume'] = 4
    return base


def apply_or_verify(timeline, plan, *, apply=False):
    verified = []
    for ti, track in enumerate(plan['tracks']):
        for si, seg in enumerate(track['segments']):
            if seg.get('volume', 1) <= 4:
                continue
            native_track = timeline['tracks'][ti]
            require(native_track['type'] == track['type'] == 'video', 'Gain track mismatch')
            require(len(native_track['segments']) == len(track['segments']), 'Gain segment count mismatch')
            native = native_track['segments'][si]
            for field, start, duration in [('target_timerange', seg.get('start_us', 0), seg['duration_us']),
                                           ('source_timerange', seg.get('source_start_us', 0), seg.get('source_duration_us', seg['duration_us']))]:
                require(native[field] == {'start': start, 'duration': duration}, 'Gain timing mismatch')
            if apply:
                require(native['volume'] == 4, 'Unexpected staged gain')
                native['volume'] = seg['volume']
            require(abs(native['volume'] - seg['volume']) < 1e-8, 'Native speech gain differs')
            verified.append({'track': ti, 'segment': si, 'volume': native['volume']})
    return verified
