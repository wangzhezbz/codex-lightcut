"""A bounded background publication job; never exits or starts the editor."""
from contextlib import contextmanager
import errno
import os
from pathlib import Path
import subprocess
import sys
import time

from .platforms import background_priority, process_pids
from .storage import load, require, save


def _lock_path():
    # All installations and QA preference homes for this OS user share this gate.
    # Keep the file permanently: unlinking a locked file can create two lock owners.
    return Path.home() / '.codex-lightcut' / 'publication.lock'


@contextmanager
def _publication_lock():
    """Nonblocking OS lock; released even after a worker crash. No stale PID locks."""
    path = _lock_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a+b') as handle:
        if os.fstat(handle.fileno()).st_size == 0:
            handle.write(b'\0'); handle.flush()
        acquired = False
        def attempt():
            nonlocal acquired
            if acquired: return True
            handle.seek(0)
            try:
                if sys.platform == 'win32':
                    import msvcrt
                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError as error:
                if error.errno not in (errno.EACCES, errno.EAGAIN, errno.EDEADLK): raise
                return False
            acquired = True
            return True
        try:
            yield attempt
        finally:
            if acquired:
                handle.seek(0)
                if sys.platform == 'win32':
                    import msvcrt
                    msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def enqueue(build, folder, timeout=86400, *, preference_guard=None):
    from .native_backend import current
    verify = current().verify
    verify(build)
    require(type(timeout) is int and 1 <= timeout <= 86400, 'Timeout must be 1..86400 seconds')
    if preference_guard:
        from .preferences import execution
        execution(preference_guard['session'], preference_guard['revision'])
    folder = Path(folder).resolve(); folder.mkdir(parents=True, exist_ok=False)
    request = {'build': str(Path(build).resolve(strict=True)), 'timeout_seconds': timeout}
    if preference_guard: request['preference_guard'] = preference_guard
    save(folder / 'request.json', request)
    save(folder / 'state.json', {'status': 'queued', 'created_unix': time.time(), 'ui_actions': 0})
    with (folder / 'worker.log').open('xb') as log:
        child = subprocess.Popen([sys.executable, str(Path(__file__).resolve().parents[1] / 'run.py'),
                                  '_publish-job', '--job', str(folder)], stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=log, start_new_session=sys.platform != 'win32',
                                 creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    save(folder / 'process.json', {'pid': child.pid})
    return {'status': 'queued', 'job': str(folder), 'pid': child.pid, 'state': str(folder / 'state.json')}


def work(folder):
    from .native_backend import current
    backend = current(); publish, verify = backend.publish, backend.verify
    folder = Path(folder).resolve(strict=True); request = load(folder / 'request.json')
    started = time.monotonic(); last = None
    background_priority()
    def update(status, **kw):
        nonlocal last
        if last != status:
            save(folder / 'state.json', {'status': status, 'pid': os.getpid(), 'updated_unix': time.time(),
                 'ui_actions': 0, 'build': request['build'], **kw}, replace=True)
            last = status
    try:
        def current_preferences(check_assets=True):
            guard = request.get('preference_guard')
            if not guard: return True
            from .preferences import execution, read
            try:
                if check_assets: execution(guard['session'], guard['revision'])
                else: read(guard['session'], guard['revision'])
                return True
            except (ValueError, OSError) as error:
                update('superseded-preferences', live_files_written=False, message=str(error))
                return False
        if not current_preferences(): return load(folder / 'state.json')
        verify(Path(request['build']))
        def stopped():
            if not current_preferences(check_assets=False): return load(folder / 'state.json')
            if (folder / 'cancel.request').exists():
                update('cancelled', live_files_written=False); return load(folder / 'state.json')
            if time.monotonic() - started >= request['timeout_seconds']:
                update('waiting-timeout', live_files_written=False); return load(folder / 'state.json')
            return None
        while True:
            terminal = stopped()
            if terminal: return terminal
            if process_pids():
                update('waiting-for-editor-to-close')
                time.sleep(2)
                continue
            with _publication_lock() as acquire:
                if not acquire():
                    update('waiting-for-publication-slot', live_files_written=False)
                else:
                    terminal = stopped()
                    if terminal: return terminal
                    # Another job may have occupied the slot while the editor reopened.
                    if process_pids(): continue
                    if not current_preferences(): return load(folder / 'state.json')
                    update('registering')
                    result = publish(Path(request['build']), folder / 'audit')
                    break
            time.sleep(2)
        # The editor may reopen between the worker check and the transaction.
        if result['status'] == 'waiting-for-editor-to-close':
            update('deferred-editor-reopened', live_files_written=False)
        else: update('registered', result=result)
        return load(folder / 'state.json')
    except Exception as error:
        update('failed', error=str(error), recovery='Inspect retained job and audit; do not retry blindly')
        raise
