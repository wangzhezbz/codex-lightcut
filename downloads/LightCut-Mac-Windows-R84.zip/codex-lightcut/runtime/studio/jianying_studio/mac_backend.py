"""Mac-only native bridge, loaded lazily. Upstream pins and guards stay intact."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

from . import native_style, gain_bridge
from .platforms import background_priority, host, process_pids
from .project import compile_plan
from .storage import asset_path, copy_file, load, manifest, require, save, sha

REPO = Path(__file__).resolve().parents[2]


def engine():
    require(host() == 'macos', 'Native Windows draft backend is not adapted; portable validation/packaging remain available')
    upstream = REPO / 'upstream/jianying-headless/engine'
    require(upstream.is_dir(), 'Install the matched upstream repository beside studio before native builds')
    sys.path.insert(0, str(upstream))
    import jy14_headless as j
    import native_edit
    import native_compound
    return j, native_edit, native_compound


def create_profile(snapshots, output, catalog_path):
    j, _, _ = engine()
    runtime = j.nd.validate_runtime()
    snapshots = Path(snapshots)
    profile = native_style.capture(load(snapshots / '1-timeline.json'), load(snapshots / 'beauty-preset.json'), load(snapshots / 'adjust-preset.json'))
    profile['runtime_profile'] = runtime['runtime_profile']
    all_ids = {n.get('resource_id') for n in profile['beauty_nodes']}
    for mats in profile['materials'].values():
        all_ids.update(n.get('resource_id') for rows in mats.values() for n in rows)
    profile['catalog'] = {k: v for k, v in load(catalog_path).items() if k in all_ids}
    save(output, profile)
    return {'profile': str(output), 'host': 'macos', 'runtime_profile': profile['runtime_profile']}


def write_existing(path, payload):
    with Path(path).open('wb') as f:
        f.write(payload)
        f.flush()
        import os
        os.fsync(f.fileno())


def build(project_dir, output, profile_path=None, audio_report_path=None):
    j, edit, compound = engine()
    background_priority()
    started = time.perf_counter()
    project_dir, output = Path(project_dir).resolve(), Path(output).resolve()
    project = load(project_dir / 'project.json')
    plan = compile_plan(project, project_dir)
    runtime = j.nd.validate_runtime()
    from .onboarding import needs_effects, automatic_profile
    need_profile = needs_effects(project['style'])
    profile = load(profile_path) if profile_path else automatic_profile(project['style']) if need_profile else None
    if profile:
        require(profile['runtime_profile'] == runtime['runtime_profile'], 'Profile/runtime mismatch')
    j.nd.fresh_directory(output)
    from .quality import inspect
    audio_report = load(audio_report_path) if audio_report_path else None
    quality = inspect(project, project_dir, audio_report=audio_report)
    save(output / 'quality-before-build.json', quality)
    require(not quality['errors'], 'Quality gate failed; see quality-before-build.json')
    if audio_report: save(output / 'audio-audit.json', audio_report)
    save(output / 'project.json', project)
    save(output / 'native-plan.json', plan)
    save(output / 'base-plan.json', gain_bridge.stage(plan))
    j.build(output / 'base-plan.json', output / 'base-build')
    base = j.verify_build(output / 'base-build')
    folder = output / 'draft'
    shutil.copytree(output / 'base-build/draft', folder, copy_function=copy_file)
    h = j.nd.helper()
    timeline = h._decrypt_metadata_in_memory(folder / 'draft_info.json')
    speech_gains = gain_bridge.apply_or_verify(timeline, plan, apply=True)
    # Upstream thumbnails use the first video source, even when an image leads
    # the timeline. Use that first-frame image for both native cover mirrors.
    first = project['tracks'][0]['segments'][0]
    cover_asset = project['assets'][first['asset']]
    if cover_asset['kind'] == 'image' and first.get('start_us', 0) == 0:
        thumbnail = output / 'generated-draft-cover.jpg'
        subprocess.run(['ffmpeg', '-nostdin', '-hide_banner', '-loglevel', 'error', '-n',
                        '-i', str(asset_path(project_dir, cover_asset['path'])),
                        '-frames:v', '1', '-vf', 'scale=320:-2', '-threads', '2', str(thumbnail)],
                       check=True, capture_output=True, timeout=30)
        for target in (folder / 'draft_cover.jpg', folder / 'Timelines' / timeline['id'] / 'draft_cover.jpg'):
            write_existing(target, thumbnail.read_bytes())
    if profile:
        save(output / 'native-profile.json', profile)
        timeline = native_style.apply(timeline, project['style'], profile)
    resources, mapping = [], {}

    def localize(value):
        if isinstance(value, dict): return {k: localize(v) for k, v in value.items()}
        if isinstance(value, list): return [localize(v) for v in value]
        if not isinstance(value, str): return value
        if value.startswith('/Users/') and '/User Data/Cache/' in value:
            source = Path(value).resolve(strict=True)
            if source not in mapping:
                relative = 'Resources/native-effects/' + hashlib.sha256(str(source).encode()).hexdigest()[:20] + '/' + source.name
                target = folder / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                if source.is_dir():
                    before = manifest(source)
                    shutil.copytree(source, target, copy_function=copy_file)
                    require(before == manifest(target) == manifest(source), 'Effect resource changed during copy')
                else:
                    before = sha(source); copy_file(source, target)
                    require(before == sha(target) == sha(source), 'Effect resource changed during copy')
                mapping[source] = native_style.TOKEN + relative
                resources.append({'source': str(source), 'relative': relative})
            return mapping[source]
        return value

    timeline = localize(timeline)
    from .ending import verify_native
    ending = verify_native(project, timeline)
    for video in timeline['materials'].get('videos', []):
        (folder / 'video/figure_algorithm' / video['id']).mkdir(parents=True, exist_ok=True)
    compound.require_publishable(timeline)
    edit.basic_validation(timeline)
    encrypted = output / 'timeline.encrypted'
    h._encrypt_metadata_from_memory(j.nd.packed(timeline), encrypted)
    require(h._decrypt_metadata_in_memory(encrypted) == timeline, 'Native round-trip mismatch')
    payload = encrypted.read_bytes()
    tid = timeline['id']
    for rel in ('draft_info.json', 'template-2.tmp', 'draft_info.json.bak',
                f'Timelines/{tid}/draft_info.json', f'Timelines/{tid}/template-2.tmp', f'Timelines/{tid}/draft_info.json.bak'):
        write_existing(folder / rel, payload)
    meta = h._decrypt_metadata_in_memory(folder / 'draft_meta_info.json')
    meta['draft_timeline_materials_size_'] = sum(p.stat().st_size for p in (folder / 'Resources').rglob('*') if p.is_file()) + len(payload)
    h._encrypt_metadata_from_memory(j.nd.packed(meta), output / 'metadata.encrypted')
    write_existing(folder / 'draft_meta_info.json', (output / 'metadata.encrypted').read_bytes())
    if profile:
        catalog = load(folder / 'key_value.json'); catalog.update(profile.get('catalog', {}))
        write_existing(folder / 'key_value.json', j.nd.packed(catalog))
    save(output / 'timeline.json', timeline)
    report = {k: base[k] for k in ('name', 'target', 'draft_id', 'timeline_id', 'runtime_profile')}
    report.update(schema='jianying-studio-native-build/v1', status='built-offline', files=manifest(folder), resources=resources,
                  project_sha256=sha(output / 'project.json'), plan_sha256=sha(output / 'native-plan.json'),
                  timeline_sha256=sha(output / 'timeline.json'),
                  profile_sha256=sha(output / 'native-profile.json') if profile else None,
                  seconds=time.perf_counter() - started, ui_actions=0, video_encoded=False,
                  quality_policy='preflight-and-native-effects/v1',
                  effect_scope='main-video-only/v1',
                  speech_gain_policy='native-static-15db/v1', speech_gains=speech_gains,
                  acceptance={'structure': 'verified', 'visual': 'not-checked', 'windows': 'not-adapted'},
                  ownership=native_style.verify_ownership(timeline, project['style'].get('beauty', {}).get('enabled', False)), ending=ending)
    save(output / 'build.json', report)
    quality = inspect(project, project_dir, audio_report=audio_report, build=output)
    save(output / 'quality-after-build.json', quality)
    require(not quality['errors'], 'Native quality gate failed; see quality-after-build.json')
    verify(output)
    return {k: v for k, v in report.items() if k not in ('files', 'resources')}


def verify(output):
    j, edit, compound = engine()
    output = Path(output).resolve(strict=True)
    report = load(output / 'build.json')
    require(report['schema'] == 'jianying-studio-native-build/v1', 'Wrong build schema')
    base = j.verify_build(output / 'base-build')
    for key in ('name', 'target', 'draft_id', 'timeline_id', 'runtime_profile'):
        require(base[key] == report[key], 'Base identity changed: ' + key)
    for name, key in [('project.json', 'project_sha256'), ('native-plan.json', 'plan_sha256'), ('timeline.json', 'timeline_sha256')]:
        require(sha(output / name) == report[key], 'Frozen build input changed: ' + name)
    if report['profile_sha256']:
        require(sha(output / 'native-profile.json') == report['profile_sha256'], 'Native profile changed')
    require(manifest(output / 'draft') == report['files'], 'Draft files changed')
    h = j.nd.helper()
    timeline = h._decrypt_metadata_in_memory(output / 'draft/draft_info.json')
    require(timeline == load(output / 'timeline.json'), 'Encrypted timeline differs')
    from .ending import verify_native
    verify_native(load(output / 'project.json'), timeline)
    if report.get('speech_gain_policy'):
        require(gain_bridge.apply_or_verify(timeline, load(output / 'native-plan.json')) == report['speech_gains'],
                'Speech gain verification changed')
    if report.get('quality_policy'):
        from .audio_quality import project_digest
        quality = load(output / 'quality-after-build.json')
        require(not quality['errors'] and quality['project_sha256'] == project_digest(load(output/'project.json')),
                'Quality gate failed or belongs to a different project')
    compound.require_publishable(timeline); edit.basic_validation(timeline)
    mirrors = edit.mirrors(output / 'draft', report['timeline_id'])
    require(len({sha(p) for p in mirrors}) == 1 and len({p.stat().st_ino for p in mirrors}) == 4, 'Timeline mirrors differ or share inode')
    project = load(output / 'project.json')
    require(native_style.verify_ownership(timeline, project['style'].get('beauty', {}).get('enabled', False)) == report['ownership'],
            'Beauty ownership changed')
    for nodes in timeline['materials'].values():
        for n in nodes:
            path = n.get('path') or n.get('font_path')
            if not path: continue
            if path.startswith(native_style.TOKEN):
                actual = output / 'draft' / path[len(native_style.TOKEN):]
                require(actual.resolve(strict=True).is_relative_to((output / 'draft').resolve()), 'Resource path escapes draft')
            elif path.startswith(report['target'] + '/'):
                actual = output / 'draft' / Path(path).relative_to(report['target'])
                require(actual.resolve(strict=True).is_relative_to((output / 'draft').resolve()), 'Asset path escapes draft')
            else:
                require(path.startswith('/Applications/VideoFusion-macOS.app/') and Path(path).exists(), 'Unowned or missing resource: ' + path)
    return report


def verify_live(output):
    j, _, _ = engine()
    report = verify(output)
    require(manifest(Path(report['target'])) == report['files'], 'Registered bytes differ')
    entries = load(j.nd.DRAFT_ROOT / 'root_meta_info.json')['all_draft_store']
    matches = [e for e in entries if e.get('draft_id') == report['draft_id']]
    require(len(matches) == 1 and matches[0]['draft_fold_path'] == report['target'], 'Homepage registration differs')
    return {'status': 'verified', 'draft': report['target'], 'acceptance': report['acceptance']}


def publish(output, audit, wait_seconds=0):
    engine()
    require(type(wait_seconds) is int and 0 <= wait_seconds <= 86400, 'Invalid wait timeout')
    output, audit = Path(output).resolve(strict=True), Path(audit).resolve()
    started = time.monotonic()
    verify(output)
    while process_pids():
        if time.monotonic() - started >= wait_seconds:
            return {'status': 'waiting-for-editor-to-close', 'live_files_written': False, 'build': str(output)}
        time.sleep(min(2, max(0, wait_seconds - (time.monotonic() - started))))
    sys.path.insert(0, str(REPO / 'research'))
    from publish_preserving_inode import publish as register
    return register(output, audit, verify_build_fn=verify, verify_live_fn=verify_live)
