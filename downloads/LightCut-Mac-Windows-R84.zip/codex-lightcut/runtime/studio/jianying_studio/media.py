"""Portable background media preprocessing with an integrity-checked cache.

These operations create a new local media asset; they do not masquerade as
editable native crop/denoise sliders. Original files are never overwritten.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

from .platforms import background_priority
from .project import fields, integer, number
from .storage import load, require, save, sha


def probe(source):
    executable = shutil.which('ffprobe')
    require(executable is not None, 'ffprobe is required')
    result = subprocess.run([executable, '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(source)],
                            capture_output=True, text=True, timeout=60,
                            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    require(result.returncode == 0, 'Media probe failed: ' + result.stderr[-1500:])
    return json.loads(result.stdout)


def recipe_check(recipe):
    fields(recipe, {'schema', 'kind', 'crop', 'mirror_x', 'mirror_y', 'fps', 'width', 'height',
                    'gain_db', 'loudness_lufs', 'denoise', 'fade_in_ms', 'fade_out_ms'}, 'Media recipe')
    require(recipe.get('schema') == 'jianying-studio-media/v1', 'Unknown media recipe')
    require(recipe.get('kind') in ('video', 'audio'), 'Invalid media kind')
    for k in ('mirror_x', 'mirror_y', 'denoise'):
        require(type(recipe.get(k, False)) is bool, 'Expected boolean: ' + k)
    if recipe['kind'] == 'audio':
        require(not {'crop', 'mirror_x', 'mirror_y', 'fps', 'width', 'height'} & set(recipe), 'Audio recipe has video controls')
    if 'crop' in recipe:
        fields(recipe['crop'], {'x', 'y', 'width', 'height'}, 'Crop')
        for k in ('x', 'y', 'width', 'height'): integer(recipe['crop'][k], 'Crop ' + k, 2 if k in ('width', 'height') else 0)
    if 'fps' in recipe: require(recipe['fps'] in (24, 25, 30, 50, 60), 'Invalid fps')
    require(('width' in recipe) == ('height' in recipe), 'Specify width and height together')
    for k in ('width', 'height'):
        if k in recipe:
            integer(recipe[k], k, 16); require(recipe[k] <= 8192 and recipe[k] % 2 == 0, 'Dimensions must be even and <=8192')
    number(recipe.get('gain_db', 0), 'Gain dB', -60, 24)
    if 'loudness_lufs' in recipe: number(recipe['loudness_lufs'], 'Loudness LUFS', -30, -10)
    for k in ('fade_in_ms', 'fade_out_ms'):
        integer(recipe.get(k, 0), k)


def prepare(source, recipe, cache, timeout=3600):
    recipe_check(recipe)
    source = Path(source).resolve(strict=True)
    require(source.is_file(), 'Source must be a file')
    executable = shutil.which('ffmpeg'); require(executable is not None, 'ffmpeg is required')
    identity = subprocess.check_output([executable, '-version'], text=True, timeout=15,
                                     creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)).splitlines()[0]
    fingerprint = sha(source)
    key = hashlib.sha256(json.dumps({'source': fingerprint, 'recipe': recipe, 'ffmpeg': identity}, sort_keys=True).encode()).hexdigest()
    folder = Path(cache).resolve() / key
    receipt = folder / 'result.json'
    if receipt.exists():
        r = load(receipt)
        output = folder / r['file']
        require(sha(output) == r['sha256'], 'Cached media changed; retained for investigation')
        return dict(r, cached=True, output=str(output))
    require(not folder.exists(), 'Incomplete cache job retained; use another cache directory to retry')
    info = probe(source)
    video = next((s for s in info['streams'] if s['codec_type'] == 'video'), None)
    audio = next((s for s in info['streams'] if s['codec_type'] == 'audio'), None)
    require(video is not None if recipe['kind'] == 'video' else audio is not None, 'Requested stream is absent')
    duration = float(info['format'].get('duration', 0)); require(duration > 0, 'Unknown duration')
    if recipe['kind'] == 'video' and 'crop' in recipe:
        width, height = video['width'], video['height']
        rotation = float(video.get('tags', {}).get('rotate', 0))
        for item in video.get('side_data_list', []): rotation = float(item.get('rotation', rotation))
        if round(rotation) % 180: width, height = height, width
        c = recipe['crop']; require(c['x'] + c['width'] <= width and c['y'] + c['height'] <= height, 'Crop outside oriented source')
    folder.mkdir(parents=True, exist_ok=False)
    save(folder / 'request.json', {'source_sha256': fingerprint, 'recipe': recipe, 'ffmpeg': identity})
    output = folder / ('media.mp4' if recipe['kind'] == 'video' else 'media.wav')
    args = [executable, '-nostdin', '-hide_banner', '-loglevel', 'error', '-n', '-threads', '2', '-i', str(source),
            '-filter_threads', '2']
    if recipe['kind'] == 'video':
        args += ['-map', '0:v:0', '-map', '0:a:0?']
        vf = []
        if 'crop' in recipe:
            c = recipe['crop']; vf.append(f"crop={c['width']}:{c['height']}:{c['x']}:{c['y']}")
        if recipe.get('mirror_x'): vf.append('hflip')
        if recipe.get('mirror_y'): vf.append('vflip')
        if 'width' in recipe:
            w, h = recipe['width'], recipe['height']
            vf += [f'scale={w}:{h}:force_original_aspect_ratio=decrease', f'pad={w}:{h}:(ow-iw)/2:(oh-ih)/2:black']
        if 'fps' in recipe: vf.append('fps=' + str(recipe['fps']))
        vf.append('setsar=1')
        args += ['-vf', ','.join(vf), '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p',
                 '-threads', '2', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart']
    else: args += ['-map', '0:a:0', '-vn', '-c:a', 'pcm_s16le', '-ar', '48000']
    af = []
    audio_controls = {'gain_db', 'loudness_lufs', 'denoise', 'fade_in_ms', 'fade_out_ms'} & set(recipe)
    require(not audio_controls or audio is not None, 'Audio controls requested for silent source')
    if recipe.get('denoise'): af.append('afftdn=nf=-25')
    if recipe.get('gain_db'): af.append('volume=' + str(recipe['gain_db']) + 'dB')
    if 'loudness_lufs' in recipe: af.append('loudnorm=I=' + str(recipe['loudness_lufs']) + ':TP=-1.5:LRA=11')
    for k, mode in [('fade_in_ms', 'in'), ('fade_out_ms', 'out')]:
        ms = recipe.get(k, 0)
        if ms:
            require(ms / 1000 <= duration, 'Audio fade exceeds duration')
            af.append(f'afade=t={mode}:st={0 if mode == "in" else duration-ms/1000}:d={ms/1000}')
    if af: args += ['-af', ','.join(af)]
    args += ['-map_metadata', '-1', str(output)]
    background_priority(); start = time.perf_counter()
    with (folder / 'ffmpeg.log').open('wb') as log:
        result = subprocess.run(args, stdin=subprocess.DEVNULL, stdout=log, stderr=log, timeout=timeout,
                                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    require(result.returncode == 0, 'Media processing failed; log and partial output retained at ' + str(folder))
    require(sha(source) == fingerprint, 'Source changed during media processing')
    result_info = probe(output)
    require(abs(float(result_info['format']['duration']) - duration) <= .1, 'Processed media duration differs')
    report = {'status': 'prepared', 'file': output.name, 'sha256': sha(output), 'source_sha256': fingerprint,
              'recipe': recipe, 'seconds': time.perf_counter() - start, 'threads': 2,
              'native_controls': False, 'ui_actions': 0, 'ffmpeg': identity}
    save(receipt, report)
    return dict(report, cached=False, output=str(output))
