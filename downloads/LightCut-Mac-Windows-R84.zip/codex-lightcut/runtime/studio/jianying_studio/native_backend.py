"""Choose a native adapter without importing the other platform's engine."""
from .platforms import host
from .storage import require


def current():
    if host() == 'windows':
        from . import windows_backend
        return windows_backend
    require(host() == 'macos', 'Native draft output requires macOS or Windows')
    from . import mac_backend
    return mac_backend
