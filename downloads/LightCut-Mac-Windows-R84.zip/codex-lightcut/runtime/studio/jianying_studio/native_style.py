"""Native structure adapter. Pure data operations; never accesses the editor."""
from copy import deepcopy
import json
import uuid

from .project import style_check
from .storage import require

TOKEN = '##_draftpath_placeholder_0E685133-18CE-45ED-8CB8-2904A212EC80_##/'


def uid():
    return str(uuid.uuid4()).upper()


def index(doc):
    return {node['id']: (bucket, node) for bucket, rows in doc['materials'].items() for node in rows}


def capture(donor, beauty, adjustment):
    idx = index(donor)
    pair = next((s, idx[s['material_id']][1]) for t in donor['tracks'] if t['type'] == 'video'
                for s in t['segments'] if any(p.get('preset_id') == beauty['id']
                for p in idx[s['material_id']][1].get('beauty_face_preset_infos', [])))
    seg, video = pair
    profile = {'schema': 'jianying-studio-native-profile/v1', 'host': 'macos', 'name': 'local-talking-head-v1',
               'beauty_video': {k: deepcopy(v) for k, v in video.items() if k in
                 ('is_unified_beauty_mode', 'is_set_beauty_mode', 'beauty_face_preset_infos', 'beauty_face_auto_preset')},
               'beauty_nodes': [deepcopy(idx[r][1]) for r in seg['extra_material_refs']
                                if idx[r][0] == 'effects' and idx[r][1]['type'] in ('figure', 'makeup_root')],
               'color_match_enabled': adjustment['color_match']['enable'], 'tracks': {}, 'materials': {}}
    for kind in ('filter', 'adjust'):
        track = next(t for t in donor['tracks'] if t['type'] == kind)
        require(len(track['segments']) == 1, 'Profile needs one continuous effect segment')
        profile['tracks'][kind] = deepcopy(track)
        refs = {r for s in track['segments'] for r in [s['material_id']] + s.get('extra_material_refs', [])}
        profile['materials'][kind] = {k: [deepcopy(n) for n in rows if n['id'] in refs]
                                      for k, rows in donor['materials'].items()}
    text = next(n for n in donor['materials']['texts'] if n.get('has_shadow'))
    profile['shadow_fields'] = {k: deepcopy(v) for k, v in text.items() if k == 'has_shadow' or k.startswith('shadow_')}
    profile['shadow_style'] = deepcopy(json.loads(text['content'])['styles'][0]['shadows'])
    return profile


def remap(value, ids):
    if isinstance(value, dict): return {k: remap(v, ids) for k, v in value.items()}
    if isinstance(value, list): return [remap(v, ids) for v in value]
    return ids.get(value, value) if isinstance(value, str) else value


def video_ranges(timeline):
    """Main-track video intervals; never tint a cover or a black image tail."""
    idx = index(timeline)
    ranges = []
    for seg in timeline['tracks'][0]['segments']:
        if idx[seg['material_id']][1].get('type') != 'video': continue
        span = deepcopy(seg['target_timerange'])
        if ranges and ranges[-1]['start'] + ranges[-1]['duration'] == span['start']:
            ranges[-1]['duration'] += span['duration']
        else: ranges.append(span)
    return ranges


def apply(base, style, profile):
    style_check(style)
    require(profile.get('schema') == 'jianying-studio-native-profile/v1' and profile.get('host') == 'macos',
            'Wrong native profile')
    result = deepcopy(base)
    require(not result['materials'].get('drafts'), 'Nested drafts are not supported')
    idx = index(result)
    beauty = style.get('beauty', {})
    if beauty.get('enabled'):
        originals = profile['beauty_nodes']
        overrides = beauty.get('values', {})
        require(set(overrides) <= {n.get('name') for n in originals}, 'Profile lacks requested beauty control')
        for seg in result['tracks'][0]['segments']:
            video = idx[seg['material_id']][1]
            if video.get('type') != 'video': continue  # No face effects on cover photos.
            video.update(deepcopy(profile['beauty_video']))
            changed = any(n.get('name') in overrides and overrides[n['name']] != n.get('value', 0) for n in originals)
            if changed: video['beauty_face_preset_infos'] = []  # Custom parameters, not the saved preset identity.
            nodes = deepcopy(originals)
            for n in nodes:
                n['id'] = uid()
                if n.get('name') in overrides: n['value'] = overrides[n['name']]
                if n.get('algorithm_artifact_path'):
                    n['algorithm_artifact_path'] = TOKEN + 'video/figure_algorithm/' + video['id']
                result['materials'].setdefault('effects', []).append(n)
                seg['extra_material_refs'].append(n['id'])
    for kind, setting in [('filter', style.get('filter', {})), ('adjust', style.get('adjustment', {}))]:
        if not setting.get('enabled'): continue
        require(not any(t['type'] == kind for t in result['tracks']), 'Duplicate effect track')
        track, mats = deepcopy(profile['tracks'][kind]), deepcopy(profile['materials'][kind])
        ids = {n['id']: uid() for rows in mats.values() for n in rows}
        ids[track['id']] = uid()
        ids.update({s['id']: uid() for s in track['segments']})
        track, mats = remap(track, ids), remap(mats, ids)
        ranges = video_ranges(result)
        require(ranges, 'Default talking-head effects require a video segment')
        original = track['segments'][0]
        track['segments'] = []
        for span in ranges:
            segment = deepcopy(original)
            segment.update(id=uid(), target_timerange=span)
            track['segments'].append(segment)
        for rows in mats.values():
            for n in rows:
                if kind == 'filter' and n.get('type') == 'filter': n['value'] = setting.get('strength', .12)
                if kind == 'adjust':
                    if n.get('type') in setting.get('values', {}): n['value'] = setting['values'][n['type']]
                    if n.get('type') == 'hsl': n.update(setting.get('orange_hsl', {}))
                    if n.get('type') == 'color_match':
                        require(profile.get('color_match_enabled') is False, 'Enabled color matching needs separate support')
                        n['color_match_info'] = {}
        for bucket, rows in mats.items(): result['materials'].setdefault(bucket, []).extend(rows)
        result['tracks'].append(track)
    if style.get('subtitle_shadow'):
        for text in result['materials'].get('texts', []):
            text.update(deepcopy(profile['shadow_fields']))
            content = json.loads(text['content'])
            for s in content['styles']: s['shadows'] = deepcopy(profile['shadow_style'])
            text['content'] = json.dumps(content, ensure_ascii=False, separators=(',', ':'))
    for i, track in enumerate(result['tracks']):
        for seg in track['segments']: seg['track_render_index'] = i
    verify_ownership(result, beauty.get('enabled', False))
    return result


def verify_ownership(timeline, enabled):
    idx = index(timeline)
    videos, effects, count = set(), set(), 0
    for seg in timeline['tracks'][0]['segments']:
        video = idx[seg['material_id']][1]
        if video.get('type') != 'video': continue
        count += 1
        require(video['id'] not in videos, 'Shared video owner')
        videos.add(video['id'])
        nodes = [idx[r][1] for r in seg['extra_material_refs'] if idx[r][0] == 'effects'
                 and idx[r][1]['type'] in ('figure', 'makeup_root')]
        require(bool(nodes) == bool(enabled), 'Missing or unexpected beauty binding')
        for node in nodes:
            require(node['id'] not in effects, 'Shared mutable beauty node')
            effects.add(node['id'])
            if node.get('algorithm_artifact_path'):
                require(node['algorithm_artifact_path'] == TOKEN + 'video/figure_algorithm/' + video['id'], 'Wrong face-analysis owner')
    return {'video_owners': count, 'beauty_nodes': len(effects), 'beauty_enabled': enabled}
