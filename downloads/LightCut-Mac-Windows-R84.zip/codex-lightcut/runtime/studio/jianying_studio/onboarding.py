"""Read-only first-use checks and automatic native resource binding.

Never opens the editor, reads accounts or silently substitutes an effect. A
resource match is not a rendering/entitlement claim. Windows stays gated until
its native recipe has been validated on a real installation.
"""
from copy import deepcopy
import importlib.util
import ntpath
import os
from pathlib import Path, PureWindowsPath
import re
import sys

from .platforms import host, diagnose
from .storage import load, manifest, require

STUDIO = Path(__file__).resolve().parents[1]
DEFAULT_STYLE = STUDIO / 'presets/口播清晰自然.json'
RECIPE = STUDIO / 'resources/talking-head.recipe.json'


def needs_effects(style):
    return bool(style.get('native_profile') or style.get('subtitle_shadow') or
                any(style.get(k, {}).get('enabled') for k in ('beauty', 'filter', 'adjustment')))


def _safe_directory(path):
    """Reject Windows junctions as well as symlinks, including ancestors."""
    path = Path(path).absolute()
    for part in (path, *path.parents):
        info = part.lstat()
        require(not part.is_symlink() and not getattr(info, 'st_file_attributes', 0) & 0x400,
                'Resource path contains a link or junction')
    require(path.is_dir(), 'Resource directory missing')
    return path


def cache_roots(kind, home=None):
    home = Path(home) if home else Path.home()
    if kind == 'macos':
        return [home / 'Movies/JianyingPro/User Data/Cache',
                home / 'Library/Containers/com.lemon.lvpro/Data/Movies/JianyingPro/User Data/Cache']
    if kind == 'windows':
        local = Path(os.environ.get('JY14_LOCALAPPDATA') or os.environ.get('LOCALAPPDATA') or home / 'AppData/Local')
        jyhome = Path(os.environ.get('JY14_HOME') or local / 'JianyingPro')
        return [jyhome / 'User Data/Cache']
    return []


def resource_manifest(path):
    _safe_directory(path)
    count = 0
    for item in Path(path).rglob('*'):
        count += 1
        require(count <= 5000, 'Resource tree exceeds probe limit')
        require(not item.is_symlink() and not getattr(item.lstat(), 'st_file_attributes', 0) & 0x400,
                'Linked file in resource')
    return manifest(path)


def resolve_resources(recipe, cache_dirs, application_dirs):
    """Direct known locations only; no drive-wide search or hash-name guessing."""
    bindings, checks = {}, []
    for key, requirement in recipe['resources'].items():
        relative = requirement['relative']
        require(not Path(relative).is_absolute() and '\\' not in relative and ':' not in relative
                and all(p not in ('', '.', '..') for p in relative.split('/')), 'Unsafe resource locator')
        roots = cache_dirs if requirement['scope'] == 'cache' else application_dirs
        rejected, variants = [], []
        for root in roots:
            path = Path(root) / relative
            if not path.exists():
                # Collect only sibling package names for developer adaptation;
                # never treat a different package as an equivalent resource.
                parent = path.parent
                try:
                    _safe_directory(parent)
                    variants.extend(p.name for p in parent.iterdir() if p.is_dir() and not p.is_symlink())
                except (OSError, ValueError):
                    pass
                continue
            try:
                require(resource_manifest(path) == requirement['files'], 'Resource content differs from reviewed recipe')
                bindings[key] = str(path)
                break
            except (OSError, ValueError) as exc:
                rejected.append(str(exc))
        checks.append({'resource': key, 'scope': requirement['scope'], 'relative': relative,
                       'status': 'matched' if key in bindings else 'different' if rejected or variants else 'missing',
                       'alternatives': sorted(set(variants))[:20], 'details': rejected})
    return bindings, checks


def bind_profile(recipe, bindings, kind, runtime_profile):
    require(runtime_profile in recipe['supported_profiles'].get(kind, []),
            '默认风格尚未适配当前剪映版本；不能以基础草稿代替完整效果')
    require(set(bindings) == set(recipe['resources']), '默认风格资源尚未齐全；未删除请求的效果')
    def visit(value):
        if isinstance(value, dict): return {k: visit(v) for k, v in value.items()}
        if isinstance(value, list): return [visit(v) for v in value]
        if isinstance(value, str) and value.startswith('lightcut-resource://'):
            return bindings[value.split('://', 1)[1]]
        return value
    result = visit(deepcopy(recipe['profile']))
    result.update(host=kind, runtime_profile=runtime_profile)
    return result


def registry_install_paths(values):
    """Parse registry path hints as Windows paths on either test host; never execute."""
    def local(value):
        if not re.match(r'^[A-Za-z]:[\\/]', value): return None
        path = PureWindowsPath(value)
        if any(part in ('.', '..') or any(c in part for c in '<>:"|?*')
               or any(ord(c) < 32 for c in part) for part in path.parts[1:]): return None
        return path
    paths = []
    location = values.get('InstallLocation')
    if isinstance(location, str):
        location = local(ntpath.expandvars(location.strip().strip('"')))
        if location: paths.append(str(location))
    icon = values.get('DisplayIcon')
    if isinstance(icon, str):
        match = re.fullmatch(r'\s*(?:"([^"\r\n]+\.exe)"|([^"\r\n]+\.exe))\s*(?:,\s*-?\d+)?\s*',
                             ntpath.expandvars(icon), re.IGNORECASE)
        if match:
            path = local(match.group(1) or match.group(2))
            if path: paths.append(str(path.parent))
    return sorted(set(paths))


def windows_install_hints():
    """Bounded uninstall registry lookup for custom installation drives."""
    if sys.platform != 'win32': return []
    import winreg
    found = []
    for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
        for view in (winreg.KEY_WOW64_64KEY, winreg.KEY_WOW64_32KEY):
            try:
                with winreg.OpenKey(hive, r'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall', 0,
                                    winreg.KEY_READ | view) as root:
                    count = min(winreg.QueryInfoKey(root)[0], 4096)
                    for i in range(count):
                        try:
                            with winreg.OpenKey(root, winreg.EnumKey(root, i)) as entry:
                                name = winreg.QueryValueEx(entry, 'DisplayName')[0]
                                if not any(s in str(name).lower() for s in ('jianying', '剪映')): continue
                                values = {}
                                for field in ('InstallLocation', 'DisplayIcon'):
                                    try: values[field] = winreg.QueryValueEx(entry, field)[0]
                                    except OSError: pass
                                found.extend(Path(p) for p in registry_install_paths(values))
                        except OSError: continue
            except OSError: continue
    return sorted(set(found), key=str)


def discover_windows_installation():
    from .windows_backend import _imports
    _imports()
    import windows_platform as wp
    explicit = os.environ.get('JY14_APP_BUNDLE')
    if explicit: return wp.inspect(Path(explicit))  # Never override an explicit choice.
    candidates = list(wp.candidate_directories())
    for root in windows_install_hints():
        for base in (root, root / 'Apps'):
            if not base.is_dir(): continue
            if (base / wp.ENGINE_LIBRARY).is_file(): candidates.append(base)
            candidates.extend(p for p in base.iterdir() if p.is_dir() and (p / wp.ENGINE_LIBRARY).is_file())
    inspected = []
    for p in dict.fromkeys(candidates):
        try: inspected.append(wp.inspect(p))
        except (OSError, ValueError): continue
    require(inspected, '未找到剪映安装；请先安装已支持的剪映版本')
    reviewed = [p for p in inspected if wp.review_status(p)['reviewed']]
    require(len(reviewed) <= 1, '发现多个已适配剪映安装；需要选择本次使用的安装')
    if reviewed: return reviewed[0]
    return sorted(inspected, key=lambda x: tuple(map(int, (x.version + '.' + x.build).split('.'))), reverse=True)[0]


def runtime_context():
    kind = host()
    if kind == 'macos':
        from .mac_backend import engine
        j, _, _ = engine()
        runtime = j.nd.doctor()  # No codec invocation, signature subprocess or editor launch.
        return runtime, [j.nd.APP / 'Contents/Resources']
    if kind == 'windows':
        installation = discover_windows_installation()
        import windows_platform as wp
        os.environ['JY14_APP_BUNDLE'] = str(installation.directory)  # Current process only.
        review = wp.review_status(installation)
        require(review['reviewed'], '当前剪映程序版本或指纹尚未适配')
        # Enumerated installation-relative locations; unresolved layouts remain explicit.
        app = installation.directory
        return {'runtime_profile': 'jy14-headless-win-' + installation.version,
                'app_version': installation.version + '.' + installation.build,
                'installation': str(app), 'library_sha256': installation.library_sha256}, [app, app / 'Resources']
    raise ValueError('仅支持 macOS 和 Windows')


def prepare(*, style=None):
    """No persistent success cache: re-check version and resource bytes each run."""
    style = load(DEFAULT_STYLE) if style is None else style
    from .project import style_check
    style_check(style)
    report = {'schema': 'lightcut-setup/v1', 'host': host(), 'style': style['name'],
              'status': 'needs-attention', 'blockers': [], 'resources': [], 'ui_actions': 0,
              'draft_writes': 0, 'account_access': False, 'downloads': 0,
              'acceptance': {'render': 'not-checked', 'entitlement': 'checked-by-editor'}}
    diag = diagnose()
    report['tools'] = diag['tools']
    if sys.version_info < (3, 11):
        report['blockers'].append({'code': 'python-missing', 'message': '需要 Python 3.11 或以上运行环境', 'owner': 'plugin-packaging'})
    for name, path in diag['tools'].items():
        if not path: report['blockers'].append({'code': 'tool-missing', 'message': '缺少 ' + name, 'owner': 'plugin-packaging'})
    if importlib.util.find_spec('fontTools') is None:
        report['blockers'].append({'code': 'font-tools-missing', 'message': '缺少字体校验依赖 fontTools', 'owner': 'plugin-packaging'})
    profile = None
    try:
        runtime, app_roots = runtime_context()
        report['runtime'] = runtime
    except (ValueError, OSError, ImportError, RuntimeError) as exc:
        report['blockers'].append({'code': 'runtime-unavailable', 'message': str(exc), 'owner': 'runtime-adapter'})
        # Still inspect cache resources on unsupported/missing installations.
        runtime, app_roots = {}, []
    if needs_effects(style):
        recipe = load(RECIPE)
        bindings, checks = resolve_resources(recipe, cache_roots(host()), app_roots)
        report['resources'] = checks
        if runtime.get('runtime_profile') not in recipe['supported_profiles'].get(host(), []):
            report['blockers'].append({'code': 'style-adapter-pending', 'message': '当前平台/版本的完整风格尚待开发适配与实机验收', 'owner': 'developer'})
        if len(bindings) != len(recipe['resources']):
            report['blockers'].append({'code': 'style-resources-unavailable', 'message': '缺少或不匹配的滤镜/美颜/调色资源；不会要求用户制作参考草稿', 'owner': 'resource-adapter'})
        if not report['blockers']: profile = bind_profile(recipe, bindings, host(), runtime['runtime_profile'])
    if not report['blockers']: report['status'] = 'ready-for-build'
    report['matched_resources'] = sum(r['status'] == 'matched' for r in report['resources'])
    report['required_resources'] = len(report['resources'])
    return report, profile


def automatic_profile(style):
    report, profile = prepare(style=style)
    require(report['status'] == 'ready-for-build',
            '默认风格准备未完成：' + '；'.join(b['message'] for b in report['blockers']))
    require(profile is not None, 'No automatic native profile resolved')
    return profile
