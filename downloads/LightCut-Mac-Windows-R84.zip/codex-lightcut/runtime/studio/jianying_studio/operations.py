"""Deterministic, non-destructive project operations used on both platforms."""
from copy import deepcopy

from .project import number, validate
from .storage import require


def duck_music(project, track_index, speech, *, gain=.16, attack_us=120000, release_us=240000):
    """Create editable volume keyframes; no rendered/re-encoded audio file."""
    validate(project, verify_assets=False)
    number(gain, 'Duck gain', 0, 1)
    require(type(attack_us) is int and attack_us > 0 and type(release_us) is int and release_us > 0,
            'Positive attack/release required')
    result = deepcopy(project)
    require(type(track_index) is int and 0 <= track_index < len(result['tracks']), 'Invalid music track')
    track = result['tracks'][track_index]
    require(track['type'] == 'audio', 'Ducking needs an audio track')
    require(isinstance(speech, list), 'Speech intervals must be a list')
    intervals = []
    for row in speech:
        require(isinstance(row, list) and len(row) == 2 and all(type(x) is int for x in row)
                and 0 <= row[0] < row[1], 'Invalid speech interval')
        intervals.append(row)
    merged = []
    for start, end in sorted(intervals):
        if merged and start - merged[-1][1] <= attack_us + release_us:
            merged[-1][1] = max(merged[-1][1], end)
        else: merged.append([start, end])
    for seg in track['segments']:
        require(not seg.get('keyframes') and seg.get('source_start_us', 0) == 0 and seg.get('speed', 1) == 1,
                'Ducking cannot overwrite animation or unverified trimmed audio timing')
        start, span, volume = seg.get('start_us', 0), seg['duration_us'], seg.get('volume', 1)
        active = [(a - start, b - start) for a, b in merged if b + release_us > start and a - attack_us < start + span]
        def value(t):
            result = 1.0
            for a, b in active:
                if a <= t <= b: factor = gain
                elif a - attack_us < t < a: factor = 1 - (1 - gain) * (t - a + attack_us) / attack_us
                elif b < t < b + release_us: factor = gain + (1 - gain) * (t - b) / release_us
                else: factor = 1.0
                result = min(result, factor)
            return round(volume * result, 8)
        times = {0, span}
        for a, b in active:
            times.update(max(0, min(span, t)) for t in (a - attack_us, a, b, b + release_us))
        points = [{'at_us': t, 'value': value(t)} for t in sorted(times)]
        seg['volume'] = points[0]['value']
        seg['keyframes'] = {'volume': points}
    validate(result, verify_assets=False)
    return result


def prepend_cover(project, image_asset, duration_us):
    result = deepcopy(project)
    require(result['assets'].get(image_asset, {}).get('kind') == 'image', 'Cover must be a project image asset')
    require(type(duration_us) is int and duration_us > 0, 'Cover needs positive duration')
    for track in result['tracks']:
        for seg in track['segments']:
            seg['start_us'] = seg.get('start_us', 0) + duration_us
    result['tracks'][0]['segments'].insert(0, {'asset': image_asset, 'start_us': 0, 'duration_us': duration_us,
                                              'source_duration_us': duration_us, 'volume': 0})
    validate(result, verify_assets=False)
    return result


def add_end_fade(project, black_image_asset, duration_us=300000):
    result = deepcopy(project)
    info = validate(result, verify_assets=False)
    require(result['assets'].get(black_image_asset, {}).get('kind') == 'image', 'Fade requires a black image asset')
    require(type(duration_us) is int and 0 < duration_us <= info['duration_us'], 'Invalid fade duration')
    result['tracks'].append({'type': 'video', 'name': '片尾淡出', 'segments': [
        {'asset': black_image_asset, 'start_us': info['duration_us'] - duration_us, 'duration_us': duration_us,
         'opacity': 0, 'volume': 0, 'keyframes': {'opacity': [{'at_us': 0, 'value': 0}, {'at_us': duration_us, 'value': 1}]}}]})
    validate(result, verify_assets=False)
    return result
