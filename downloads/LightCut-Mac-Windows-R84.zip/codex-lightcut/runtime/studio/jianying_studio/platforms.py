import csv
import io
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys


def host():
    return 'macos' if sys.platform == 'darwin' else 'windows' if sys.platform == 'win32' else 'unsupported'


def background_priority():
    if sys.platform == 'win32':
        import ctypes
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.GetCurrentProcess.restype = ctypes.c_void_p
        kernel.SetPriorityClass.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
        return bool(kernel.SetPriorityClass(kernel.GetCurrentProcess(), 0x00004000))  # BELOW_NORMAL_PRIORITY_CLASS
    if hasattr(os, 'nice'):
        if os.getpriority(os.PRIO_PROCESS, 0) < 10:
            os.nice(10 - os.getpriority(os.PRIO_PROCESS, 0))
        return True
    return False


def process_pids():
    if host() == 'macos':
        rows = subprocess.check_output(['ps', '-axo', 'pid=,command='], text=True, timeout=15)
        executable = '/Applications/VideoFusion-macOS.app/Contents/MacOS/VideoFusion-macOS'
        return [int(row.strip().split(None, 1)[0]) for row in rows.splitlines()
                if len(row.strip().split(None, 1)) == 2 and row.strip().split(None, 1)[1] == executable]
    if host() == 'windows':
        rows = subprocess.check_output(['tasklist', '/FO', 'CSV', '/NH'], text=True, timeout=15,
                                       creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        return [int(row[1]) for row in csv.reader(io.StringIO(rows))
                if len(row) >= 2 and row[0].lower() in {'jianyingpro.exe', 'capcut.exe'}]
    return []


def diagnose():
    kind = host()
    tools = {name: shutil.which(name) for name in ('ffmpeg', 'ffprobe')}
    root = os.environ.get('JIANYING_DRAFT_ROOT')
    # Windows candidate is a discovery hint only, never permission to write.
    candidate = (Path.home() / 'Movies/JianyingPro/User Data/Projects/com.lveditor.draft' if kind == 'macos'
                 else Path(os.environ.get('LOCALAPPDATA', '')) / 'JianyingPro/User Data/Projects/com.lveditor.draft')
    draft_root = Path(root) if root else candidate
    return {'schema': 'jianying-studio-doctor/v1', 'host': kind, 'python': platform.python_version(),
            'tools': tools, 'draft_root_candidate': str(draft_root), 'draft_root_exists': draft_root.is_dir(),
            'portable_plan': 'available', 'native_backend': 'requires-runtime-check' if kind == 'macos' else 'experimental-basic-drafts-pending-validation' if kind == 'windows' else 'unsupported',
            'windows_native_acceptance': 'not-tested-on-windows',
            'ui_actions': 0, 'account_access': False}
