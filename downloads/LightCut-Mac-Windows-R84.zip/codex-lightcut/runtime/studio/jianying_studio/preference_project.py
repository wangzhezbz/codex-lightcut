"""Apply confirmed choices to a NEW portable project, never to an open draft.

Editing/content decisions precede this step. An explicit digest-bound role map
identifies cover, BGM and captions, so other photos, audio and titles stay intact.
"""
from copy import deepcopy
from pathlib import Path

from . import preferences as pref
from .project import validate, fields, package_project
from .storage import load, require, save, copy_file, sha
from .audio_quality import project_digest


def bindings_template(session, revision, project_dir):
    state = pref.read(session, revision)
    require(state['confirmed_digest'] == pref.digest(state['choices']), '请先确认创作选择')
    project = load(Path(project_dir) / 'project.json')
    validate(project, project_dir)
    return {'schema': 'lightcut-role-bindings/v1', 'project_sha256': project_digest(project),
            'choices_sha256': state['confirmed_digest'], 'cover_segment': None,
            'music_tracks': [], 'caption_tracks': [], 'editing_applied': None,
            'instructions': '由 Agent 标注真实素材角色，完成节奏与比例规划后填写 editing_applied={pace,aspect}；不让用户编辑此文件。'}


def configured(session, revision, project_dir, bindings):
    state = pref.execution(session, revision)
    source = load(Path(project_dir) / 'project.json')
    validate(source, project_dir)
    fields(bindings, {'schema', 'project_sha256', 'choices_sha256', 'cover_segment', 'music_tracks',
                      'caption_tracks', 'editing_applied', 'instructions'}, '素材角色')
    require(bindings.get('schema') == 'lightcut-role-bindings/v1', '素材角色格式无效')
    require(bindings.get('project_sha256') == project_digest(source), '素材角色不是当前工程的，请重新标注')
    require(bindings.get('choices_sha256') == state['confirmed_digest'], '剪辑计划使用了旧偏好，请按最新选择更新计划')
    choices = state['choices']
    edit = choices['editing']
    require(bindings.get('editing_applied') == {k: edit[k] for k in ('pace', 'aspect')},
            '请先按所选节奏与比例完成内容剪辑规划；应用设置不会代替语义剪辑')
    if edit['aspect'] != 'source':
        w, h = map(int, edit['aspect'].split(':'))
        require(source['canvas']['width'] * h == source['canvas']['height'] * w, '画面比例不匹配，请先完成构图')
    for key, kind in [('music_tracks', 'audio'), ('caption_tracks', 'text')]:
        indices = bindings.get(key)
        require(isinstance(indices, list) and all(type(i) is int and 0 <= i < len(source['tracks']) for i in indices)
                and len(set(indices)) == len(indices), '轨道角色索引无效')
        require(all(source['tracks'][i]['type'] == kind for i in indices), '轨道角色类型不匹配')
    cover_index = bindings.get('cover_segment')
    require(cover_index is None or type(cover_index) is int and cover_index == 0, '仅支持明确标注的首片段封面')
    if choices['cover']['mode'] == 'none':
        require(cover_index is None, '用户不加封面，请从剪辑计划移除封面并重新对齐时间线')
    else:
        require(cover_index == 0, '请把已确认封面放入首片段并标注封面角色')
        clip = source['tracks'][0]['segments'][0]
        a = source['assets'][clip['asset']]
        require(a['kind'] == 'image' and a['sha256'] == state['cover_review']['asset']['sha256'], '工程封面不是已确认的图片')
    music = choices['music']
    if music['mode'] == 'file':
        require(bool(bindings['music_tracks']), '请先将已选音乐放入背景音乐轨道')
        clips = [s for i in bindings['music_tracks'] for s in source['tracks'][i]['segments']]
        require(all(source['assets'][s['asset']]['sha256'] == music['asset']['sha256'] for s in clips), '工程音乐与已选曲目不一致')
        require(min(s.get('start_us', 0) for s in clips) == round(music['start_frame'] * 1e6 / source['canvas']['fps']),
                '音乐起点与已确认设置不一致，请调整时间线')
    captions = edit['captions']
    if captions['enabled']: require(bool(bindings['caption_tracks']), '请先按语义生成字幕并标注字幕轨道')
    project = deepcopy(source)
    style = deepcopy(choices['effects'])
    style['name'] = '轻剪自选风格'
    if not captions['enabled']: style['subtitle_shadow'] = False
    if not (style.get('subtitle_shadow') or any(style.get(k, {}).get('enabled') for k in ('filter', 'beauty', 'adjustment'))):
        style['native_profile'] = None
    project['style'] = style
    font = captions.get('font') if captions['enabled'] else None
    if font:
        # The actual copy happens only after the new project folder is created.
        ident = 'lightcut-font-' + font['sha256'][:16]
        path = Path(font['path'])
        project['assets'][ident] = {'kind': 'font', 'path': 'assets/' + ident + path.suffix.lower(),
                                    'sha256': font['sha256'], 'size': path.stat().st_size}
    removed = set()
    for i, track in enumerate(project['tracks']):
        if i in bindings['music_tracks']:
            if music['mode'] == 'none': removed.add(i); continue
            for s in track['segments']:
                s['volume'] = 10 ** (music['gain_db'] / 20)
                s.get('keyframes', {}).pop('volume', None)
        if i in bindings['caption_tracks']:
            if not captions['enabled']: removed.add(i); continue
            for s in track['segments']:
                require(not any(k in s.get('keyframes', {}) for k in ('x', 'y', 'scale')), '字幕含位置动画，需先明确新的字幕布局')
                s.update({k: captions[k] for k in ('size', 'x', 'y', 'color')})
                if font: s['font_asset'] = ident
        if track['type'] == 'video' and edit['speech_gain_db'] is not None:
            for s in track['segments']:
                if project['assets'][s['asset']]['kind'] == 'video':
                    s['volume'] = min(5.6234130859375, 10 ** (edit['speech_gain_db'] / 20))
                    s.get('keyframes', {}).pop('volume', None)
    retained = [i for i in range(len(project['tracks'])) if i not in removed]
    project['tracks'] = [project['tracks'][i] for i in retained]
    project['creative_policy'] = {
        'schema': 'lightcut-creative-policy/v1', 'choices_sha256': state['confirmed_digest'],
        'music_tracks': [retained.index(i) for i in bindings['music_tracks'] if i in retained],
        'music_gain_db': music['gain_db'], 'music_start_frame': music['start_frame']}
    validate(project)
    return project, state


def apply(session, revision, project_dir, output, bindings):
    output = Path(output)
    require(not output.exists(), '输出目录已存在，请为修改创建新版本')
    project, state = configured(session, revision, project_dir, bindings)
    package_project(project_dir, output)
    font = state['choices']['editing']['captions'].get('font')
    if font and state['choices']['editing']['captions']['enabled']:
        ident = 'lightcut-font-' + font['sha256'][:16]
        dest = output / project['assets'][ident]['path']
        if not dest.exists(): copy_file(font['path'], dest)
        require(sha(dest) == font['sha256'], '复制后的字体与选择不一致')
    if 'end_fade_ms' in state['choices']['editing']:
        from .ending import apply as apply_ending
        project = apply_ending(project, output, state['choices']['editing']['end_fade_ms'])
    # Do not let changes during copying become a silently stale final project.
    pref.execution(session, revision)
    validate(project, output)
    save(output / 'project.json', project, replace=True)
    result = {'schema': 'lightcut-preference-application/v1', 'status': 'preferences-applied',
              'session': str(Path(session).resolve()), 'revision': revision,
              'choices_sha256': state['confirmed_digest'], 'project_sha256': project_digest(project),
              'project': str(output.resolve()), 'choices': state['choices'],
              'semantic_editing': 'agent-planned-not-listening-verified', 'native_render': 'not-checked', 'ui_actions': 0}
    save(output / 'creative-settings.json', result)
    return result
