"""Platform-neutral plans. Media/font paths are relative; native IDs stay outside."""
from copy import deepcopy
import math
from pathlib import Path
import re

from .storage import asset_path, component, copy_file, load, require, save, sha

SCHEMA = 'jianying-studio-project/v1'
CHANNELS = {'x': (-5, 5), 'y': (-5, 5), 'scale': (.01, 10), 'rotation': (-360, 360),
            'opacity': (0, 1), 'volume': (0, 4)}
MEDIA_FIELDS = {'asset', 'start_us', 'duration_us', 'source_start_us', 'source_duration_us', 'speed', 'volume', 'keyframes'}
VIDEO_FIELDS = MEDIA_FIELDS | {'x', 'y', 'scale', 'rotation', 'opacity', 'mask', 'transition_out'}
TEXT_FIELDS = {'start_us', 'duration_us', 'text', 'size', 'x', 'y', 'color', 'border_color', 'border_width', 'font_asset', 'keyframes', 'opacity'}
BEAUTY_KEYS = {'磨皮', '匀肤', '丰盈', '祛黑眼圈', '祛法令纹', '瘦脸', '小脸', '下颌骨', '白牙', '美白'}
ADJUST_KEYS = {'brightness', 'contrast', 'saturation', 'highlight', 'clear'}


def fields(obj, allowed, label):
    require(isinstance(obj, dict) and not set(obj) - allowed, label + ': unsupported fields')


def integer(n, label, minimum=0):
    require(type(n) is int and n >= minimum, label + ': invalid integer')


def number(n, label, low, high):
    require(type(n) in (int, float) and math.isfinite(n) and low <= n <= high, label + ': invalid number')


def style_check(style):
    fields(style, {'schema', 'name', 'native_profile', 'beauty', 'filter', 'adjustment', 'subtitle_shadow'}, 'Style')
    require(style.get('schema') == 'jianying-studio-style/v1', 'Unknown style schema')
    component(style['name'])
    require(style.get('native_profile') in (None, 'local-talking-head-v1'), 'Native profile is not adapted')
    for flag in ('subtitle_shadow',):
        require(type(style.get(flag, False)) is bool, 'Expected boolean ' + flag)
    beauty = style.get('beauty', {})
    fields(beauty, {'enabled', 'values'}, 'Beauty')
    require(type(beauty.get('enabled', False)) is bool, 'Beauty enabled must be boolean')
    fields(beauty.get('values', {}), BEAUTY_KEYS, 'Beauty values')
    for k, v in beauty.get('values', {}).items():
        number(v, k, 0, 1)
    filt = style.get('filter', {})
    fields(filt, {'enabled', 'strength'}, 'Filter')
    require(type(filt.get('enabled', False)) is bool, 'Filter enabled must be boolean')
    number(filt.get('strength', .12), 'Filter strength', 0, 1)
    adj = style.get('adjustment', {})
    fields(adj, {'enabled', 'values', 'orange_hsl'}, 'Adjustment')
    require(type(adj.get('enabled', False)) is bool, 'Adjustment enabled must be boolean')
    fields(adj.get('values', {}), ADJUST_KEYS, 'Adjustment values')
    for k, v in adj.get('values', {}).items():
        number(v, k, -1, 1)
    fields(adj.get('orange_hsl', {}), {'hue', 'saturation', 'lightness'}, 'Orange HSL')
    for k, v in adj.get('orange_hsl', {}).items():
        number(v, k, -100, 100)
    require(not (beauty.get('enabled') or filt.get('enabled') or adj.get('enabled') or style.get('subtitle_shadow'))
            or style.get('native_profile') == 'local-talking-head-v1', 'Effects require an adapted native profile')


def validate(project, root=None, verify_assets=True):
    fields(project, {'schema', 'name', 'canvas', 'assets', 'tracks', 'style', 'creative_policy'}, 'Project')
    require(project.get('schema') == SCHEMA, 'Unknown project schema')
    component(project['name'])
    fields(project['canvas'], {'width', 'height', 'fps'}, 'Canvas')
    for key in ('width', 'height'):
        integer(project['canvas'][key], key, 16)
        require(project['canvas'][key] <= 8192, 'Canvas too large')
    require(project['canvas'].get('fps') in (24, 25, 30, 50, 60), 'Unsupported fps')
    require(isinstance(project['assets'], dict), 'Assets must be an object')
    for ident, a in project['assets'].items():
        component(ident)
        fields(a, {'path', 'sha256', 'size', 'kind'}, 'Asset')
        require(a['kind'] in ('video', 'audio', 'font', 'image'), 'Unknown asset type')
        require(re.fullmatch('[a-f0-9]{64}', a['sha256']) is not None, 'Invalid asset digest')
        integer(a['size'], 'Asset size', 1)
        if root is not None:
            p = asset_path(root, a['path'])
            require(p.stat().st_size == a['size'], 'Asset size changed: ' + ident)
            if verify_assets:
                require(sha(p) == a['sha256'], 'Asset bytes changed: ' + ident)
    tracks = project['tracks']
    require(isinstance(tracks, list) and tracks and tracks[0].get('type') == 'video', 'Main video must be first')
    duration = 0
    for ti, track in enumerate(tracks):
        fields(track, {'type', 'name', 'segments'}, 'Track')
        kind = track['type']
        require(kind in ('video', 'audio', 'text'), 'Unsupported track type')
        require(isinstance(track.get('name', kind), str), 'Track name must be text')
        require(isinstance(track['segments'], list) and track['segments'], 'Empty track')
        prior = 0
        for si, seg in enumerate(track['segments']):
            fields(seg, VIDEO_FIELDS if kind == 'video' else MEDIA_FIELDS if kind == 'audio' else TEXT_FIELDS, 'Segment')
            start, span = seg.get('start_us', 0), seg['duration_us']
            integer(start, 'Start'); integer(span, 'Duration', 1)
            require(start >= prior and (ti != 0 or abs(start - prior) <= 1), 'Overlap or main video gap')
            prior = start + span
            if kind == 'text':
                require(isinstance(seg.get('text'), str) and seg['text'].strip(), 'Empty subtitle')
                number(seg.get('size', 6), 'Text size', 1, 100)
                number(seg.get('border_width', .05), 'Border width', 0, 1)
                for c in ('color', 'border_color'):
                    require(re.fullmatch('#[0-9a-fA-F]{6}', seg.get(c, '#FFFFFF')) is not None, 'Invalid text color')
                if 'font_asset' in seg:
                    require(project['assets'].get(seg['font_asset'], {}).get('kind') == 'font', 'Missing font')
            else:
                allowed_kinds = ('video', 'image') if kind == 'video' else ('audio',)
                require(project['assets'].get(seg.get('asset'), {}).get('kind') in allowed_kinds, 'Missing/wrong media asset')
                integer(seg.get('source_start_us', 0), 'Source start')
                integer(seg.get('source_duration_us', span), 'Source duration', 1)
                number(seg.get('speed', 1), 'Speed', .1, 8)
                # Native donor saved with the user's +15 dB speech setting.
                max_volume = 5.6234130859375 if project['assets'][seg['asset']]['kind'] == 'video' else 4
                number(seg.get('volume', 1), 'Volume', 0, max_volume)
                require(abs(seg.get('source_duration_us', span) / seg.get('speed', 1) - span) <= 2, 'Speed/timing mismatch')
            for k in ('x', 'y', 'scale', 'rotation', 'opacity'):
                if k in seg:
                    number(seg[k], k, *CHANNELS[k])
            series = seg.get('keyframes', {})
            allowed_channels = set(CHANNELS) if kind == 'video' else {'volume'} if kind == 'audio' else {'x', 'y', 'scale', 'rotation'}
            fields(series, allowed_channels, 'Keyframes')
            if series:
                require(seg.get('source_start_us', 0) == 0 and seg.get('speed', 1) == 1,
                        'Keyframe timing on trimmed/retimed sources is not verified')
            for k, pts in series.items():
                require(isinstance(pts, list) and len(pts) >= 2, 'At least two keyframes required')
                at = -1
                for pt in pts:
                    fields(pt, {'at_us', 'value'}, 'Keyframe')
                    integer(pt['at_us'], 'Keyframe time')
                    require(at < pt['at_us'] <= span, 'Keyframe outside clip or out of order')
                    at = pt['at_us']; number(pt['value'], 'Keyframe value', *CHANNELS[k])
                require(pts[0]['at_us'] == 0, 'First keyframe must start at zero')
                require(k not in seg or abs(seg[k] - pts[0]['value']) < 1e-7, 'Static/keyframe values conflict')
            if 'mask' in seg:
                m = seg['mask']
                fields(m, {'shape', 'width', 'height', 'x', 'y', 'rotation', 'feather', 'invert', 'round_corner'}, 'Mask')
                require(m.get('shape') in ('circle', 'rectangle', 'line', 'mirror', 'star', 'heart'), 'Unknown mask shape')
                require(type(m.get('invert', False)) is bool, 'Mask invert must be boolean')
                require(m['shape'] != 'line' or not {'width', 'height'} & set(m), 'Line mask has no width/height controls')
                require(m['shape'] == 'rectangle' or m.get('round_corner', 0) == 0, 'Only rectangles have rounded corners')
                for k, limits in {'width': (.001, 5), 'height': (.001, 5), 'x': (-5, 5), 'y': (-5, 5),
                                  'rotation': (-360, 360), 'feather': (0, 1), 'round_corner': (0, 1)}.items():
                    if k in m: number(m[k], 'Mask ' + k, *limits)
            if 'transition_out' in seg:
                tr = seg['transition_out']; fields(tr, {'name', 'duration_us', 'edge_policy'}, 'Transition')
                require(ti == 0 and si + 1 < len(track['segments']) and tr.get('name') == 'dissolve', 'Only adjacent main-track dissolve is adapted')
                n = tr['duration_us']; integer(n, 'Transition duration', 1)
                frames = round(n * project['canvas']['fps'] / 1000000)
                require(frames >= 2 and frames % 2 == 0 and abs(frames * 1000000 / project['canvas']['fps'] - n) <= 2,
                        'Dissolve needs an even number of frames')
                require(n <= min(span, track['segments'][si + 1]['duration_us']), 'Transition too long')
                require(tr.get('edge_policy', 'require-handles') in ('require-handles', 'repeat-edge'), 'Invalid transition edge policy')
        if ti == 0: duration = prior
        require(prior <= duration, 'Track exceeds main duration')
    if 'creative_policy' in project:
        policy = project['creative_policy']
        fields(policy, {'schema', 'choices_sha256', 'music_tracks', 'music_gain_db', 'music_start_frame'}, 'Creative policy')
        require(policy.get('schema') == 'lightcut-creative-policy/v1', 'Unknown creative policy')
        require(isinstance(policy.get('choices_sha256'), str) and re.fullmatch('[a-f0-9]{64}', policy['choices_sha256']), 'Invalid choices digest')
        indices = policy.get('music_tracks')
        require(isinstance(indices, list) and all(type(i) is int and 0 <= i < len(tracks) and tracks[i]['type'] == 'audio' for i in indices), 'Invalid music role')
        require(len(indices) == len(set(indices)), 'Duplicate music role')
        number(policy.get('music_gain_db'), 'Music policy gain', -60, 12)
        integer(policy.get('music_start_frame'), 'Music start frame')
        music = [s for i in indices for s in tracks[i]['segments']]
        if music:
            require(all(abs(s.get('volume', 1) - 10 ** (policy['music_gain_db'] / 20)) < 1e-7 and not s.get('keyframes', {}).get('volume') for s in music), 'Music differs from confirmed volume')
            require(min(s.get('start_us', 0) for s in music) == round(policy['music_start_frame'] * 1e6 / project['canvas']['fps']), 'Music differs from confirmed start')
    style_check(project['style'])
    return {'name': project['name'], 'duration_us': duration, 'assets': len(project['assets']),
            'tracks': len(tracks), 'segments': sum(len(t['segments']) for t in tracks), 'asset_hashes_checked': verify_assets}


def import_plan(plan_path, destination, style):
    plan = load(plan_path)
    require(plan.get('schema') == 'jy14-headless-plan/v1', 'Expected native source plan')
    fields(plan, {'schema', 'name', 'canvas', 'tracks', 'source_captions'}, 'Source plan')
    from .caption_timing import expand_plan
    plan, caption_report = expand_plan(plan)
    component(plan['name']); style_check(style)
    dest = Path(destination).resolve()
    dest.mkdir(parents=True, exist_ok=False)
    project = {'schema': SCHEMA, 'name': plan['name'], 'canvas': plan['canvas'], 'tracks': deepcopy(plan['tracks']),
               'assets': {}, 'style': deepcopy(style)}
    seen = {}
    for track in project['tracks']:
        for seg in track['segments']:
            for old, new, kind in [('source', 'asset', track['type']), ('font_path', 'font_asset', 'font')]:
                if old not in seg: continue
                p = Path(seg.pop(old)).resolve(strict=True)
                require(p.is_file(), 'Missing source')
                kind = 'image' if kind == 'video' and p.suffix.lower() in ('.png', '.jpg', '.jpeg', '.gif') else kind
                key = (str(p), kind)
                if key not in seen:
                    fingerprint = sha(p)
                    ident = kind + '-' + fingerprint[:24]
                    rel = 'assets/' + fingerprint + p.suffix.lower()
                    if ident not in project['assets']:
                        if not (dest / rel).exists(): copy_file(p, dest / rel)
                        require(sha(dest / rel) == fingerprint and sha(p) == fingerprint, 'Source changed during import')
                        project['assets'][ident] = {'path': rel, 'sha256': fingerprint, 'size': p.stat().st_size, 'kind': kind}
                    seen[key] = ident
                seg[new] = seen[key]
    validate(project, dest)
    save(dest / 'project.json', project)
    if caption_report is not None:
        save(dest / 'caption-timing.json', caption_report)
    return project


def compile_plan(project, root):
    validate(project, root)
    tracks = deepcopy(project['tracks'])
    for track in tracks:
        for seg in track['segments']:
            for old, new in [('asset', 'source'), ('font_asset', 'font_path')]:
                if old in seg:
                    seg[new] = str(asset_path(root, project['assets'][seg.pop(old)]['path']))
    return {'schema': 'jy14-headless-plan/v1', 'name': project['name'], 'canvas': deepcopy(project['canvas']), 'tracks': tracks}


def package_project(source, destination):
    source, destination = Path(source).resolve(), Path(destination).resolve()
    require(not destination.is_relative_to(source), 'Package must be outside source project')
    project = load(source / 'project.json'); validate(project, source)
    destination.mkdir(parents=True, exist_ok=False)
    for a in project['assets'].values():
        target = destination / a['path']
        if not target.exists(): copy_file(asset_path(source, a['path']), target)
    save(destination / 'project.json', project)
    validate(project, destination)
    return {'status': 'packaged', 'project': str(destination / 'project.json'), 'native_draft': False}
