"""Portable pre-delivery checks with explicit unverified visual/semantic scope."""
import json
import math
from pathlib import Path

from .audio_quality import project_digest
from .media import probe
from .native_style import index, verify_ownership, video_ranges
from .project import validate
from .storage import asset_path, load, sha


def inspect(project, root, *, audio_report=None, build=None):
    root = Path(root).resolve()
    errors, warnings, checks = [], [], []
    unverified = ['剪映画面与保存重开', '自动换行及文字实际像素边界', '剪切点是否吞字及主观听感', 'Windows原生草稿兼容']
    def issue(items, code, message, **details): items.append(dict(code=code,message=message,**details))
    def done(code, **details): checks.append(dict(code=code,status='passed',**details))
    try:
        info = validate(project, root)
        done('project-and-asset-integrity', **info)
    except (ValueError,OSError,KeyError) as e:
        issue(errors,'invalid-project',str(e))
        return {'schema':'jianying-studio-quality/v1','status':'failed','errors':errors,'warnings':warnings,'checks':checks,'unverified':unverified}
    sources = {}
    for ident, asset in project['assets'].items():
        if asset['kind']=='font': continue
        try:
            data=probe(asset_path(root,asset['path'])); sources[ident]=data
            if asset['kind'] in ('video','audio'):
                stream=next(s for s in data['streams'] if s['codec_type']==('video' if asset['kind']=='video' else 'audio'))
                duration=float(stream.get('duration',data['format'].get('duration',0)))
                if not math.isfinite(duration) or duration<=0: raise ValueError('Cannot determine source duration')
                sources[ident]['usable_duration_us']=round(duration*1e6)
                if asset['kind']=='video':
                    rotation=float(stream.get('tags',{}).get('rotate',0))
                    for side in stream.get('side_data_list',[]): rotation=float(side.get('rotation',rotation))
                    if rotation%360: issue(errors,'source-rotation','素材需要先规范化旋转信息',asset=ident,rotation=rotation)
        except (ValueError,OSError,KeyError,StopIteration) as e:
            issue(errors,'source-probe',str(e),asset=ident)
    if not any(x['code']=='source-probe' for x in errors): done('media-stream-probes',assets=len(sources))
    fonts={}; texts=0
    # Legacy timeline-only plans have no source caption provenance. Flag cues
    # that straddle an edit rather than treating clean JSON as sync evidence.
    main_segments = project['tracks'][0]['segments']
    caption_seams = [s['start_us'] for s in main_segments[1:]]
    caption_layout = load(Path(__file__).resolve().parents[1] / 'presets/竖屏字幕位置.json')
    fixed_captions = (project['style'].get('name') == caption_layout['style_name']
                      and project['canvas']['width'] * 16 == project['canvas']['height'] * 9)
    for ti,track in enumerate(project['tracks']):
        for si,seg in enumerate(track['segments']):
            loc={'track':ti,'segment':si}
            if 'asset' in seg and project['assets'][seg['asset']]['kind'] in ('video','audio'):
                data=sources.get(seg['asset'],{}); limit=data.get('usable_duration_us')
                end=seg.get('source_start_us',0)+seg.get('source_duration_us',seg['duration_us'])
                if limit is not None and end>limit+1000000/project['canvas']['fps']:
                    issue(errors,'source-trim-outside-media','剪切区间超过源素材时长',end_us=end,source_us=limit,**loc)
                if track['type']=='video' and seg.get('volume',1)>0 and data and not any(s['codec_type']=='audio' for s in data['streams']):
                    issue(warnings,'silent-video-source','该视频片段没有音轨',**loc)
            if track['type']!='text': continue
            texts+=1; text=seg['text']
            crossed = [at for at in caption_seams
                       if seg.get('start_us', 0) < at < seg.get('start_us', 0) + seg['duration_us']]
            if crossed:
                issue(warnings, 'caption-crosses-edit',
                      '字幕跨视频剪切点，请按最终人声核对字词时序；结构通过不代表同步',
                      cuts_us=crossed, text=text, **loc)
            if fixed_captions:
                for axis, expected in caption_layout['native_transform'].items():
                    values = [seg.get(axis, 0)] + [p['value'] for p in seg.get('keyframes', {}).get(axis, [])]
                    if any(abs(value - expected) > 1e-6 for value in values):
                        issue(errors,'caption-fixed-position','字幕偏离用户确认的竖屏位置；旧y=-0.8已被用户否定',axis=axis,expected=expected,actual=values,**loc)
            if '\n' in text or '\r' in text: issue(errors,'multiline-caption','字幕含显式换行',text=text,**loc)
            if any(ord(c)<32 and c not in '\n\r' for c in text): issue(errors,'caption-control-character','字幕含控制字符',**loc)
            if abs(seg.get('x',0))>1 or abs(seg.get('y',0))>1:
                issue(warnings,'caption-center-offscreen','字幕中心超出标准画布范围，需确认是否有意安排',**loc)
            asset_id=seg.get('font_asset')
            if not asset_id:
                issue(warnings,'unbundled-font','字幕未指定随工程保存的字体',**loc); continue
            if asset_id not in fonts:
                try:
                    from fontTools.ttLib import TTFont
                    with TTFont(asset_path(root,project['assets'][asset_id]['path'])) as font:
                        fonts[asset_id]={'cmap':font.getBestCmap(),'metrics':dict(font['hmtx'].metrics),'em':font['head'].unitsPerEm}
                except (ImportError,ValueError,OSError,KeyError) as e:
                    fonts[asset_id]=None; issue(warnings,'font-metrics-unavailable',str(e),asset=asset_id)
            metrics=fonts[asset_id]
            if metrics:
                missing=sorted({c for c in text if not c.isspace() and ord(c) not in metrics['cmap']})
                if missing: issue(errors,'missing-glyph','指定字体缺少字幕字符',characters=''.join(missing),**loc)
                width=sum(metrics['metrics'].get(metrics['cmap'].get(ord(c)),(0,0))[0] for c in text)/metrics['em']
                if width>18:
                    issue(warnings,'long-line-risk','单行字宽较长，可能自动折行；尚非原生像素边界测量',em_width=round(width,2),text=text,**loc)
    if not any(x['code']=='source-trim-outside-media' for x in errors): done('source-trim-durations')
    if not any(x['code'] in ('multiline-caption','caption-control-character','missing-glyph') for x in errors):
        done('caption-content',segments=texts,font_metrics_available=all(v is not None for v in fonts.values()))
    if fixed_captions and texts and not any(x['code']=='caption-fixed-position' for x in errors):
        done('caption-fixed-position',**caption_layout['native_transform'])
    main_end=info['duration_us']; last_text=max((s.get('start_us',0)+s['duration_us'] for t in project['tracks'] if t['type']=='text' for s in t['segments']),default=0)
    quiet_tail = (audio_report or {}).get('voice_tail',{}).get('quiet_tail_ms',0)
    current_audio = audio_report and audio_report.get('project_sha256')==project_digest(project)
    if last_text and main_end-last_text<100000 and not (current_audio and quiet_tail>=100):
        issue(warnings,'tight-ending','最后一条字幕距离片尾不足100毫秒，需确认尾字是否完整',remaining_us=main_end-last_text)
    elif current_audio and quiet_tail>=100:
        done('quiet-voice-tail',milliseconds=quiet_tail,semantic_completion='not-proven')
    for ti,track in enumerate(project['tracks']):
        if track['type']!='audio': continue
        for si,s in enumerate(track['segments']):
            pts=s.get('keyframes',{}).get('volume',[])
            ending=pts[-1]['value'] if pts else s.get('volume',1)
            if abs(s.get('start_us',0)+s['duration_us']-main_end)<=1000000/project['canvas']['fps'] and ending>.001:
                issue(warnings,'abrupt-music-ending','音乐抵达片尾时尚未淡出',track=ti,segment=si,last_volume=ending)
    music_policy = load(Path(__file__).resolve().parents[1] / 'presets/固定背景音乐.json')
    confirmed_music_tracks = set(project.get('creative_policy', {}).get('music_tracks', []))
    fixed_music = [s for ti,t in enumerate(project['tracks']) if t['type']=='audio' and ti not in confirmed_music_tracks for s in t['segments']
                   if project['assets'][s['asset']]['sha256']==music_policy['sha256']]
    if fixed_music:
        if any(abs(s.get('volume',1)-1)>1e-8 or s.get('keyframes',{}).get('volume') for s in fixed_music):
            issue(errors,'fixed-music-volume','用户固定背景音乐必须0.0dB，不得闪避或用音量关键帧衰减')
        if min(s.get('start_us',0) for s in fixed_music)!=round(1e6/project['canvas']['fps']):
            issue(errors,'fixed-music-start','用户固定背景音乐必须从第二帧开始')
        if not any(x['code'].startswith('fixed-music-') for x in errors): done('fixed-music-policy',gain_db=0,start_frame=1)
    if audio_report:
        if audio_report.get('project_sha256')!=project_digest(project):
            issue(errors,'stale-audio-audit','音频测量不属于当前工程，不能复用旧结果')
        else:
            levels=audio_report['measurements']; mix=levels['mix']; voice=levels['voice']; music=levels['music']
            if mix['true_peak_dbtp'] is None: issue(warnings,'silent-mix','参考混音没有可测量声音')
            elif mix['true_peak_dbtp']>-.5: issue(errors,'mix-headroom','参考混音峰值余量不足',peak_dbtp=mix['true_peak_dbtp'])
            else: done('reference-mix-headroom',true_peak_dbtp=mix['true_peak_dbtp'])
            if voice['integrated_lufs'] is not None and not -18<=voice['integrated_lufs']<=-14:
                issue(warnings,'voice-loudness','参考人声响度超出本项目-18到-14 LUFS的目标范围',lufs=voice['integrated_lufs'])
            if voice['integrated_lufs'] is not None and music['integrated_lufs'] is not None:
                gap=voice['integrated_lufs']-music['integrated_lufs']
                if gap<10: issue(warnings,'music-masking-risk','音乐与人声响度差较小，存在遮盖风险',difference_lu=round(gap,2))
                else: done('reference-voice-music-balance',difference_lu=round(gap,2))
            for cut in audio_report['cut_boundaries']:
                if cut.get('jump_dbfs',-200)>-30:
                    issue(warnings,'cut-discontinuity','参考波形剪切点有较大跳变，需检查爆音',**cut)
            done('reference-audio-duration-and-analysis',reference=audio_report['reference'])
    else: unverified.append('响度、峰值和切口波形：尚未提供当前工程音频测量')
    if build:
        try:
            folder=Path(build); record=load(folder/'build.json'); timeline=load(folder/'timeline.json')
            if load(folder/'project.json')!=project: raise ValueError('Native build belongs to another project')
            if sha(folder/'timeline.json')!=record['timeline_sha256']: raise ValueError('Native timeline was changed')
            expected=project['style'].get('beauty',{}); enabled=expected.get('enabled',False)
            ownership=verify_ownership(timeline,enabled); idx=index(timeline)
            if fixed_captions:
                for track in timeline['tracks']:
                    if track['type'] != 'text': continue
                    for seg in track['segments']:
                        transform = seg.get('clip', {}).get('transform', {})
                        for axis, expected_position in caption_layout['native_transform'].items():
                            if abs(transform.get(axis, 0) - expected_position) > 1e-6:
                                raise ValueError('Native caption position differs from user preset: ' + axis)
            for seg in timeline['tracks'][0]['segments']:
                video=idx[seg['material_id']][1]
                if video.get('type')!='video': continue
                nodes=[idx[r][1] for r in seg['extra_material_refs'] if idx[r][0]=='effects']
                if enabled:
                    for name,value in expected.get('values',{}).items():
                        matches=[n for n in nodes if n.get('name')==name]
                        if len(matches)!=1 or abs(matches[0].get('value',0)-value)>1e-6:
                            raise ValueError('Missing/wrong per-clip beauty parameter: '+name)
            for kind,setting in [('filter','filter'),('adjust','adjustment')]:
                if project['style'].get(setting,{}).get('enabled'):
                    tracks=[t for t in timeline['tracks'] if t['type']==kind]
                    if len(tracks)!=1: raise ValueError('Wrong effect track count: '+kind)
                    spans=[s['target_timerange'] for s in tracks[0]['segments']]
                    expected_spans = video_ranges(timeline) if record.get('effect_scope') == 'main-video-only/v1' else [{'start':0,'duration':main_end}]
                    if spans != expected_spans: raise ValueError('Effect coverage gap: '+kind)
            done('native-beauty-bindings-and-effect-coverage',**ownership)
        except (ValueError,OSError,KeyError,StopIteration) as e:
            issue(errors,'native-effects',str(e))
    else: unverified.append('原生草稿逐段美颜绑定：尚未提供本次构建')
    return {'schema':'jianying-studio-quality/v1','project_sha256':project_digest(project),
            'status':'failed' if errors else 'review-needed' if warnings else 'automated-checks-passed',
            'errors':errors,'warnings':warnings,'checks':checks,'unverified':unverified,'ui_actions':0}
