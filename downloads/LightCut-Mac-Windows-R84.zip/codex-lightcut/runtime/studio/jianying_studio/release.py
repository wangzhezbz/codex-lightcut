"""Common Mac/Windows development entry; preserves the user's selected style."""
from .platforms import host
from .project import style_check

VERSION = '0.4.0-preview.1'


def capabilities():
    return {'version':VERSION,'host':host(),'development_preview':True,'ui_actions':0,
            'windows_reviewed_version':'11.5.0.14471',
            'windows_effect_combinations':'R5 natural/custom user accepted',
            'publication_queue':'R51 Mac/Windows tests passed; native transaction integration still separate',
            'windows_subtitle_shadow':False,'automatic_beauty_resources':'R61 cold/warm resources and R63 private-first native drafts user accepted',
            'models':'existing installation/cache; missing or unknown mappings block',
            'dependency_installer':'R72 Windows dependency installation/resources accepted; R8 engine-source reuse added',
            'visual_end_fade':'R71 editable overlay; recommended 300ms; Mac native verified; Windows playback pending',
            'local_transcription':'optional faster-whisper CPU/int8; separately prepared and reviewed',
            'onboarding':'Mac and Windows editing accepted by user; R8 new guards require focused platform checks',
            'cover_dimensions':'independent cover.size validated at review, approval and delivery',
            'confirmed_resource_preparation':'automatic selected-resource preparation after confirmation; never disables missing effects',
            'engine_upgrade':'verified local receipt; public distribution unresolved',
            'bundled_native_engines':False,'bundled_media_tools':False,
            'clean_machine_acceptance':'pending'}


def prepare(style, *, allow_download=False):
    style_check(style)
    if host()=='windows':
        if style.get('subtitle_shadow'):
            return {'status':'needs-attention','style':style['name'],'ui_actions':0,'downloads':0,
                    'blockers':[{'code':'windows-subtitle-shadow-unsupported','owner':'resource-adapter',
                                 'message':'Windows 暂不支持字幕阴影；保留您的选择，请选择关闭阴影或等待适配'}],
                    'capabilities':capabilities()},None
        from .windows_style_setup import prepare as selected_prepare
        report,profile=selected_prepare(style,allow_download=allow_download,managed_resources=True)
    else:
        from .onboarding import prepare as selected_prepare
        report,profile=selected_prepare(style=style)
    report['capabilities']=capabilities()
    return report,profile
