"""No recursive deletion, shell commands, symlink traversal or shared hardlinks."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import shutil
import sys
import uuid


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'Duplicate JSON key: ' + key)
            result[key] = value
        return result
    return json.loads(Path(path).read_bytes(), object_pairs_hook=pairs,
                      parse_constant=lambda v: (_ for _ in ()).throw(ValueError('Nonfinite number: ' + v)))


def save(path, data, *, replace=False):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = json.dumps(data, ensure_ascii=False, allow_nan=False, indent=2).encode('utf-8') + b'\n'
    if not replace:
        with path.open('xb') as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
    else:
        temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.pending')
        with temp.open('xb') as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp, path)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def component(name):
    require(isinstance(name, str) and name.strip() == name and bool(name), 'Name must be nonempty')
    require(not any(c in name for c in '<>:"/\\|?*') and all(ord(c) >= 32 for c in name), 'Name is not portable')
    require(not name.startswith('.') and not name.endswith(('.', ' ')), 'Unsafe name')
    require(len(name.encode('utf-8')) <= 120, 'Name is too long')
    reserved = {'CON', 'PRN', 'AUX', 'NUL'} | {f'{s}{i}' for s in ('COM', 'LPT') for i in range(1, 10)}
    require(name.split('.')[0].upper() not in reserved, 'Reserved Windows filename')
    return name


def asset_path(root, relative):
    require(isinstance(relative, str) and '\\' not in relative and ':' not in relative, 'Use portable relative paths')
    p = PurePosixPath(relative)
    require(not p.is_absolute() and bool(p.parts) and all(x not in ('.', '..') for x in relative.split('/')),
            'Asset path escapes project')
    require(not PureWindowsPath(relative).drive, 'Absolute Windows paths are not portable')
    for part in p.parts:
        component(part)
    root = Path(root).resolve(strict=True)
    path = root
    for part in p.parts:
        path /= part
        require(not path.is_symlink(), 'Asset symlinks are not supported')
    require(path.resolve(strict=True).is_relative_to(root) and path.is_file(), 'Missing project asset')
    return path


def copy_file(source, destination):
    source, destination = Path(source), Path(destination)
    require(source.is_file() and not source.is_symlink(), 'Source must be a regular file')
    require(not destination.exists() and not destination.is_symlink(), 'Refusing to overwrite a file')
    destination.parent.mkdir(parents=True, exist_ok=True)
    if sys.platform == 'darwin':
        import ctypes
        lib = ctypes.CDLL(None, use_errno=True)
        fn = lib.clonefile
        fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int]
        if fn(os.fsencode(source), os.fsencode(destination), 0) == 0:
            return
    with source.open('rb') as src, destination.open('xb') as dst:
        shutil.copyfileobj(src, dst, 1024 * 1024)


def manifest(root):
    root = Path(root)
    result = {}
    for p in sorted(root.rglob('*')):
        require(not p.is_symlink(), 'Symlink in package')
        if p.is_file():
            result[p.relative_to(root).as_posix()] = {'size': p.stat().st_size, 'sha256': sha(p)}
    return result
