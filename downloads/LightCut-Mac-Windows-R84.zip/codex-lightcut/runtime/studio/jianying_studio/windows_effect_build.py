"""Explicit partial effect experiments: fresh offline draft, never publish.

The pinned basic engine supplies native media/fonts/IDs. A separate Windows
effect adapter writes a new copy and validates decode/graph/resource contracts.
Codec success is not effect rendering or application save/reopen acceptance.
"""
from copy import deepcopy
from datetime import datetime
import importlib
import os
from pathlib import Path
import shutil
import uuid

from . import windows_backend as basic
from . import windows_effects as effects
from .windows_effect_resources import bind
from .storage import load, save, require, manifest, sha, copy_file
from .project import package_project
from .audio_quality import audit
from .platforms import background_priority

SCHEMA = 'lightcut-windows-partial-effect-build/v1'


def mirrors(folder, tid):
    return [folder / rel for rel in ('draft_content.json', 'template-2.tmp', 'draft_content.json.bak',
        f'Timelines/{tid}/draft_content.json', f'Timelines/{tid}/template-2.tmp', f'Timelines/{tid}/draft_content.json.bak')]


def replace_new_copy(path, data, root):
    require(path.resolve(strict=True).is_relative_to(root.resolve(strict=True)), 'Write escapes fresh draft copy')
    require(not path.is_symlink(), 'Linked output file')
    with path.open('wb') as f: f.write(data); f.flush(); os.fsync(f.fileno())


def build(project_dir, output, scope):
    source = Path(project_dir).resolve(strict=True); output = Path(output).resolve(strict=False)
    require(not output.exists(), 'Partial output already exists; never overwrite')
    require(not output.is_relative_to(source), 'Partial output cannot be inside the source project')
    project = load(source / 'project.json')
    # This entry explicitly adds a selected experiment to a basic source. It
    # cannot silently strip a full-style source or replace the normal builder.
    basic.check_supported(project)
    before = manifest(source)
    bindings, resources = bind(scope)
    j = basic.engine(); background_priority(); runtime = j.nd.validate_runtime()
    require(not output.is_relative_to(j.nd.DRAFT_ROOT.resolve()), 'Partial builds cannot write live draft store')
    j.nd.fresh_directory(output)
    save(output / 'input-project.json', project)
    save(output / 'resource-binding.json', resources)
    save(output / 'experiment.json', {'scope':scope, 'full_default_style':False,
         'excluded_scopes':['filter','subtitle-shadow'], 'purpose':'Windows native effect development',
         'requested_beauty':{r[0]:r[3] for r in effects.BEAUTY} if 'beauty' in scope else None,
         'requested_adjustment':{r[0]:r[1] for r in effects.ADJUST} if 'adjustment' in scope else None,
         'hsl_orange':{'hue':0,'saturation':12,'lightness':14} if 'adjustment' in scope else None})
    package_project(source, output / 'base-project')
    staged = load(output / 'base-project/project.json')
    label = {'beauty':'美颜','adjustment':'调色','beauty-adjustment':'美颜调色'}[scope]
    staged['name'] = 'Windows' + label + '分项-' + datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:6]
    save(output / 'base-project/project.json', staged, replace=True)
    audit(staged, output / 'base-project', output / 'audio')
    basic.build(output / 'base-project', output / 'base-build', audio_report_path=output / 'audio/report.json')
    base_record = basic.verify(output / 'base-build')
    base_draft = output / 'base-build/native-build/draft'
    draft = output / 'draft'
    shutil.copytree(base_draft, draft, copy_function=copy_file)
    helper = j.nd.helper()
    baseline = helper._decrypt_metadata_in_memory(base_draft / 'draft_content.json')
    timeline = effects.apply(baseline, scope, bindings)
    native_edit = importlib.import_module('native_edit')
    native_edit.basic_validation(timeline)
    save(output / 'base-timeline.json', baseline); save(output / 'timeline.json', timeline)
    for video in effects.video_segments(timeline):
        if 'beauty' in scope: (draft / 'video/figure_algorithm' / video['material_id']).mkdir(parents=True, exist_ok=False)
    helper._encrypt_metadata_from_memory(j.nd.packed(timeline), output / 'timeline.encrypted')
    require(helper._decrypt_metadata_in_memory(output / 'timeline.encrypted') == timeline, 'Native timeline codec mismatch')
    cipher = (output / 'timeline.encrypted').read_bytes()
    for path in mirrors(draft, timeline['id']): replace_new_copy(path, cipher, draft)
    metadata = helper._decrypt_metadata_in_memory(base_draft / 'draft_meta_info.json')
    metadata['draft_timeline_materials_size_'] = sum(p.stat().st_size for p in (draft/'Resources').rglob('*') if p.is_file()) + len(cipher)
    helper._encrypt_metadata_from_memory(j.nd.packed(metadata), output / 'metadata.encrypted')
    require(helper._decrypt_metadata_in_memory(output / 'metadata.encrypted') == metadata, 'Native metadata codec mismatch')
    replace_new_copy(draft / 'draft_meta_info.json', (output/'metadata.encrypted').read_bytes(), draft)
    require(manifest(source) == before, 'Input project changed during build')
    record = {k:base_record[k] for k in ('name','target','draft_id','timeline_id','runtime_profile')}
    record.update(schema=SCHEMA,status='built-partial-experimental',scope=scope,full_default_style=False,
        files=manifest(draft), input_project_sha256=sha(output/'input-project.json'),
        experiment_sha256=sha(output/'experiment.json'), base_timeline_sha256=sha(output/'base-timeline.json'),
        timeline_sha256=sha(output/'timeline.json'), resource_binding_sha256=sha(output/'resource-binding.json'),
        base_record_sha256=sha(output/'base-build/build.json'), source_project_files=before,
        runtime_identity=runtime, ui_actions=0, live_written=False,
        acceptance={'serialization':'pending-independent-verify','effect_rendering':'not-tested',
                    'editor_open_save_reopen':'not-tested','full_default_style':'not-delivered'},
        resource_policy='installed-Windows-local-resources-pinned-and-semantic-checked',
        registration_supported=False)
    save(output / 'build.json', record)
    checked = verify(output)
    save(output / 'verification.json', checked)
    return checked


def verify(output):
    output = Path(output).resolve(strict=True); record = load(output/'build.json')
    require(record['schema'] == SCHEMA and record['full_default_style'] is False, 'Not a partial Windows effect experiment')
    require(record['registration_supported'] is False and record['live_written'] is False, 'Unexpected publish state')
    for rel, key in [('input-project.json','input_project_sha256'), ('experiment.json','experiment_sha256'),
            ('base-timeline.json','base_timeline_sha256'),('timeline.json','timeline_sha256'),
            ('resource-binding.json','resource_binding_sha256'),('base-build/build.json','base_record_sha256')]:
        require(sha(output/rel) == record[key], 'Frozen partial input changed: ' + rel)
    bindings, resources = bind(record['scope'])
    require(resources == load(output/'resource-binding.json'), 'Selected Windows resources or runtime changed')
    base_record = basic.verify(output/'base-build')
    for key in ('name','target','draft_id','timeline_id','runtime_profile'):
        require(record[key] == base_record[key], 'Native identity changed: ' + key)
    j = basic.engine(); j.nd.validate_runtime(); helper = j.nd.helper()
    draft = output/'draft'; require(manifest(draft) == record['files'], 'Partial draft files changed')
    baseline = helper._decrypt_metadata_in_memory(output/'base-build/native-build/draft/draft_content.json')
    require(baseline == load(output/'base-timeline.json'), 'Baseline differs from native base')
    timeline = helper._decrypt_metadata_in_memory(draft/'draft_content.json')
    require(timeline == load(output/'timeline.json'), 'Native readback differs from requested timeline')
    graph = effects.verify(baseline,timeline,record['scope'],bindings)
    importlib.import_module('native_edit').basic_validation(timeline)
    paths = mirrors(draft,record['timeline_id'])
    require(len({sha(p) for p in paths}) == 1 and len({p.stat().st_ino for p in paths}) == 6,
            'Six mirrors must match and be independent files')
    for path in paths: require(helper._decrypt_metadata_in_memory(path) == timeline, 'Mirror native readback mismatch')
    base_meta = helper._decrypt_metadata_in_memory(output/'base-build/native-build/draft/draft_meta_info.json')
    meta = helper._decrypt_metadata_in_memory(draft/'draft_meta_info.json')
    expected_meta = deepcopy(base_meta)
    expected_meta['draft_timeline_materials_size_'] = sum(p.stat().st_size for p in (draft/'Resources').rglob('*') if p.is_file()) + paths[0].stat().st_size
    require(meta == expected_meta, 'Native metadata changed outside resource size')
    for seg in effects.video_segments(timeline):
        if 'beauty' in record['scope']:
            require((draft/'video/figure_algorithm'/seg['material_id']).is_dir(), 'Missing independent face-analysis directory')
    return {'status':'partial-native-readback-verified','scope':record['scope'],'name':record['name'],
        'draft':str(draft),'draft_id':record['draft_id'],'timeline_id':record['timeline_id'],
        'graph':graph,'six_mirrors_verified':True,'metadata_verified':True,'resources_verified':True,
        'base_audio_captions_media_preserved':True,'ui_actions':0,'live_written':False,
        'full_default_style':False,'acceptance':{'serialization':'verified-with-installed-Windows-codec',
             'effect_rendering':'not-tested','editor_open_save_reopen':'not-tested','full_default_style':'not-delivered'}}
