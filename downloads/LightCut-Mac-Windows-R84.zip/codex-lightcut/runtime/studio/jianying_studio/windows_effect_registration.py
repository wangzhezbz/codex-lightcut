"""Explicit development-only registration for native effect acceptance.

Normal deliver/build/publish still reject this partial schema. Original frozen
records retain their offline state. The separate transaction report records
registration; neither changes rendering or complete-style acceptance.
"""
from pathlib import Path
from . import windows_effect_build as effects
from . import windows_backend as basic
from .storage import load, require


def publication_record(output):
    output = Path(output).resolve(strict=True)
    effects.verify(output)
    record = load(output / 'build.json')
    require(record['schema'] == effects.SCHEMA and record['full_default_style'] is False,
            'Only explicit partial effect experiments can be registered here')
    require(record['scope'] in ('beauty', 'adjustment', 'beauty-adjustment') and '分项' in record['name'],
            'Development draft must retain its partial-test label')
    j = basic.engine()
    # Native transaction owns Windows separator conventions; don't mutate the
    # portable frozen build record to serve this different consumer.
    return dict(record, files=j.files_manifest(output / 'draft'))


def verify_live(output):
    record = publication_record(output)
    j = basic.engine()
    target = Path(record['target'])
    require(target.parent.resolve() == j.nd.DRAFT_ROOT.resolve() and not target.is_symlink(),
            'Experimental draft target is outside the selected draft root')
    require(j.files_manifest(target) == record['files'], 'Registered experimental draft bytes differ')
    entries = load(j.nd.DRAFT_ROOT / 'root_meta_info.json')['all_draft_store']
    matches = [e for e in entries if e.get('draft_id') == record['draft_id']]
    require(len(matches) == 1 and j.plat.same_draft_path(matches[0].get('draft_fold_path'), target),
            'Experimental draft homepage registration differs')
    # Copytree must retain empty, per-video analysis directories as well.
    from .windows_effects import video_segments
    if 'beauty' in record['scope']:
        for segment in video_segments(load(Path(output) / 'timeline.json')):
            require((target / 'video/figure_algorithm' / segment['material_id']).is_dir(),
                    'Registered face-analysis directory missing')
    return {'status': 'partial-test-registration-verified', 'name': record['name'], 'draft': str(target),
            'scope': record['scope'], 'full_default_style': False, 'ui_actions': 0, 'live_written': True,
            'acceptance': {'serialization': 'verified-with-installed-Windows-codec',
                           'effect_rendering': 'not-tested', 'editor_open_save_reopen': 'not-tested',
                           'full_default_style': 'not-delivered'}}


def register(output, audit):
    from .platforms import host
    require(host() == 'windows', '测试登记必须在 Windows 上执行')
    publication_record(output)
    if basic.process_pids():
        return {'status': 'waiting-for-editor-to-close', 'live_written': False,
                'full_default_style': False, 'ui_actions': 0,
                'message': '等待剪映自然退出后重试；不会关闭或打开剪映'}
    # The existing pinned native transaction re-checks process state and exact
    # runtime under its lock, uses a unique target and preserves unrelated drafts.
    j = basic.engine()
    result = j.publish(Path(output), Path(audit), verify_build_fn=publication_record, verify_live_fn=verify_live)
    return dict(result, full_default_style=False, development_test=True)
