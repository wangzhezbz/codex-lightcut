"""Pinned Windows-local resource catalog plus independent semantic checks."""
from pathlib import Path, PurePosixPath
from .storage import load, require, sha
from .onboarding import _safe_directory, resource_manifest, runtime_context, cache_roots

CATALOG = Path(__file__).resolve().parents[1] / 'resources/windows-effects-11.5.0.json'
# Filled after developer inspection of Windows package identities and semantics.
CATALOG_SHA256 = '9a6e038ed2dffe4f461f6a68cde9d6db5f20717c00d8e63ff7cec17a3930c11f'


def child(root, relative):
    p = PurePosixPath(relative)
    require(relative and not p.is_absolute() and ':' not in relative and '\\' not in relative
            and all(x not in ('', '.', '..') for x in relative.rstrip('/').split('/')), 'Unsafe resource locator')
    value = root.joinpath(*p.parts)
    require(value.exists(), 'Resource locator missing')
    require(value.resolve(strict=True).is_relative_to(root.resolve(strict=True)), 'Resource locator escapes root')
    return value


def validate_package(path, spec):
    path = _safe_directory(path)
    require(resource_manifest(path) == spec['files'], 'Windows resource bytes changed')
    cfg = load(path / 'config.json')
    links = cfg.get('effect', {}).get('Link', [])
    require(isinstance(links, list) and links, 'Missing Windows native effect links')
    for link in links:
        require(isinstance(link, dict) and isinstance(link.get('path'), str), 'Invalid native effect link')
        require(child(path, link['path']).exists(), 'Native effect link missing')
    for relative, tokens in spec['semantic_tokens'].items():
        source = child(path, relative)
        require(source.stat().st_size <= 2_000_000, 'Semantic source is too large')
        text = source.read_text(encoding='utf-8-sig')
        require(all(token in text for token in tokens), 'Windows effect semantic evidence missing')
    return True


def bind(scope):
    from .platforms import host
    require(host() == 'windows', 'Windows 原生效果分项必须在 Windows 上执行')
    from .windows_effects import SCOPES, BEAUTY
    require(scope in SCOPES, 'Unsupported partial scope')
    require(sha(CATALOG) == CATALOG_SHA256, 'Windows resource catalog changed; developer review required')
    catalog = load(CATALOG)
    runtime, applications = runtime_context()
    require(runtime['app_version'] == catalog['app_version'] and runtime['library_sha256'] == catalog['library_sha256'],
            'Windows resource catalog/runtime mismatch')
    required = ({n[2] for n in BEAUTY} if 'beauty' in scope else set()) | ({'adjust'} if 'adjustment' in scope else set())
    bindings = {}; checks = []
    for key in sorted(required):
        spec = catalog['resources'][key]
        roots = cache_roots('windows') if spec['scope'] == 'cache' else [applications[0] / 'Resources']
        candidates = [root / spec['relative'] for root in roots if (root / spec['relative']).is_dir()]
        require(len(candidates) == 1, 'Missing/ambiguous Windows resource: ' + key)
        path = candidates[0]
        validate_package(path, spec)
        bindings[key] = path.as_posix()
        checks.append({'resource': key, 'files': len(spec['files']), 'hashes_verified': True, 'semantics_verified': True})
    if 'beauty' in scope:
        # Control IDs/names are independently observed in official local panel config.
        def walk(v):
            if isinstance(v, dict):
                yield v
                for x in v.values(): yield from walk(x)
            elif isinstance(v, list):
                for x in v: yield from walk(x)
        seen = set()
        for proof in catalog['control_identity_evidence']:
            path = child(cache_roots('windows')[0], proof['relative'])
            _safe_directory(path.parent)
            require(not path.is_symlink() and not getattr(path.lstat(), 'st_file_attributes', 0) & 0x400
                    and sha(path) == proof['sha256'], 'Windows beauty control metadata changed')
            seen.update((str(n.get('resource_id')), n.get('name')) for n in walk(load(path)))
        require(all((n[1], n[0]) in seen for n in BEAUTY), 'Windows control ID/name not present in local panel config')
    return bindings, {'schema': 'windows-partial-resource-binding/v1', 'runtime': runtime,
        'catalog_sha256': CATALOG_SHA256, 'scope': scope, 'checks': checks, 'bindings': bindings,
        'provenance': 'Windows-local-config-semantics-and-pinned-files', 'render_acceptance': 'pending'}
