"""Windows-only effect timeline implementation for explicit partial experiments.

Editable native materials, not rendered/baked media. No default-delivery enablement.
The native serialization shape is documented by the bundled timeline schema;
resource bindings and semantic evidence are independently Windows-local.
"""
from copy import deepcopy
import uuid
from .storage import require

SCOPES = ('beauty', 'adjustment', 'beauty-adjustment')
TOKEN = '##_draftpath_placeholder_0E685133-18CE-45ED-8CB8-2904A212EC80_##/'
# name, control id, package key, native value, native intensity key, category, item type
BEAUTY = (
    ('磨皮', '7408076339699322112', 'smooth', .08, None, 'auto-beauty2', 21),
    ('匀肤', '7408077497142693135', 'skin', .28, 'face_adjust_yunfu', 'auto-beauty2', 21),
    ('丰盈', '7408076532146605312', 'skin', .28, 'face_adjust_fuling', 'auto-beauty2', 21),
    ('祛黑眼圈', '7408077132145937679', 'eye', .3, 'face_adjust_Pouch', 'auto-beauty2', 21),
    ('祛法令纹', '7408077446257331471', 'eye', .3, 'face_adjust_NasolabialFolds', 'auto-beauty2', 21),
    ('瘦脸', '7408078156944379136', 'face', .2, 'face_adjust_TotalFace', 'face_shape', 20),
    ('小脸', '7406181120506678580', 'small', .2, 'face_adjust_YouTaiFace', 'face_shape', 20),
    ('下颌骨', '7408077346814627107', 'face', .2, 'face_adjust_ZoomJawbone', 'face_shape', 20),
    ('白牙', '7408077691880049960', 'teeth', .5, None, 'facial_features', 21),
    ('美白', '7408076966164778255', 'white', 0, None, 'auto-beauty2', 21),
)
ADJUST = (('brightness', -.1, 'v2'), ('contrast', -.02, 'v3'),
          ('saturation', -.1, 'v1'), ('highlight', -.04, 'v3'), ('clear', .2, None))
BEAUTY_VIDEO = {'is_unified_beauty_mode': True, 'is_set_beauty_mode': True,
                'beauty_face_preset_infos': [], 'beauty_face_auto_preset': {}}


def uid(): return str(uuid.uuid4()).upper()


def index(doc):
    nodes = [n for rows in doc['materials'].values() for n in rows]
    require(len({n['id'] for n in nodes}) == len(nodes), 'Duplicate material id')
    return {n['id']: n for n in nodes}


def selection(scope, bindings):
    require(scope in SCOPES, 'Only explicit partial Windows scopes are supported')
    beauty, adjust = 'beauty' in scope, 'adjustment' in scope
    keys = ({row[2] for row in BEAUTY} if beauty else set()) | ({'adjust'} if adjust else set())
    require(keys <= bindings.keys() and all(isinstance(bindings[k], str) and bindings[k] for k in keys),
            'Missing Windows effect resource binding')
    return beauty, adjust


def video_segments(doc):
    require(doc['tracks'] and doc['tracks'][0]['type'] == 'video', 'Main video track required')
    idx = index(doc)
    result = [s for s in doc['tracks'][0]['segments'] if idx[s['material_id']].get('type') == 'video']
    require(result, 'At least one video is required')
    require(len({s['material_id'] for s in result}) == len(result), 'Shared video owner')
    return result


def beauty_fields(control, bindings, owner):
    name, rid, package, value, key, category, item_type = control
    node = {'resource_id': rid, 'third_resource_id': '0', 'name': name, 'type': 'figure',
            'sub_type': 'none' if name == '美白' else 'auto_beauty', 'value': value,
            'path': bindings[package], 'item_effect_type': item_type, 'category_id': category,
            'source_platform': 1, 'color_match_info': {}, 'multi_language_current': '',
            'beauty_face_auto_retouch_info': {}}
    if name != '美白': node['algorithm_artifact_path'] = TOKEN + 'video/figure_algorithm/' + owner
    if key: node['intensity_key'] = key
    return node


def adjust_fields(control, bindings):
    kind, value, version = control
    node = {'resource_id': '', 'type': kind, 'sub_type': 'none', 'value': value, 'path': bindings['adjust'],
            'lumi_hub_path': bindings['adjust'].rstrip('/\\') + '/lumi_hub_path',
            'color_match_info': {}, 'multi_language_current': '', 'beauty_face_auto_retouch_info': {}}
    if version: node['version'] = version
    return node


def hsl_fields(bindings):
    # Preserved native internal units; never reinterpret as panel percentages.
    return {'resource_id': '', 'type': 'hsl', 'hsl_color_type': 2, 'hue': 0,
            'saturation': 12, 'lightness': 14, 'interacting': True, 'version': '1',
            'custom_color': '#FFE69444', 'path': bindings['adjust'],
            'lumi_hub_path': bindings['adjust'].rstrip('/\\') + '/lumi_hub_path'}


def apply(base, scope, bindings):
    beauty, adjust = selection(scope, bindings)
    require(not base['materials'].get('drafts'), 'Nested drafts are not supported')
    require(not any(t['type'] in ('filter', 'adjust') for t in base['tracks']), 'Existing effect track')
    require(not any(n.get('type') in ('figure', 'makeup_root') for n in base['materials'].get('effects', [])),
            'Existing beauty effects cannot be overwritten')
    result = deepcopy(base); idx = index(result); videos = video_segments(result)
    if beauty:
        for seg in videos:
            owner = seg['material_id']; idx[owner].update(deepcopy(BEAUTY_VIDEO))
            for control in BEAUTY:
                node = dict(beauty_fields(control, bindings, owner), id=uid())
                result['materials'].setdefault('effects', []).append(node)
                seg['extra_material_refs'].append(node['id'])
    if adjust:
        track = {'id': uid(), 'type': 'adjust', 'name': 'Windows调色分项测试', 'is_default_name': False, 'segments': []}
        for video in videos:
            placeholder = {'id': uid(), 'name': 'Windows调色', 'type': 'adjust'}
            result['materials'].setdefault('placeholders', []).append(placeholder)
            refs = []
            for control in ADJUST:
                node = dict(adjust_fields(control, bindings), id=uid())
                result['materials'].setdefault('effects', []).append(node); refs.append(node['id'])
            hsl = dict(hsl_fields(bindings), id=uid(), constant_material_id=uid())
            result['materials'].setdefault('hsl', []).append(hsl); refs.append(hsl['id'])
            track['segments'].append({'id': uid(), 'target_timerange': deepcopy(video['target_timerange']),
                'render_timerange': {}, 'material_id': placeholder['id'], 'extra_material_refs': refs,
                'track_render_index': len(result['tracks']), 'responsive_layout': {}, 'source': 'segmentsourcenormal'})
        result['tracks'].append(track)
    verify(base, result, scope, bindings)
    return result


def verify(base, actual, scope, bindings):
    beauty, adjust = selection(scope, bindings)
    idx = index(actual); base_idx = index(base); videos = video_segments(base)
    buckets = {n['id']: bucket for bucket, nodes in actual['materials'].items() for n in nodes}
    require(len(actual['tracks']) == len(base['tracks']) + int(adjust), 'Unexpected track count')
    restored = deepcopy(actual); restored_idx = index(restored)
    new_ids = set(); hsl_constants = []; expected_spans = [v['target_timerange'] for v in videos]
    for i, source_track in enumerate(base['tracks']):
        track = restored['tracks'][i]
        require(len(track['segments']) == len(source_track['segments']), 'Original segment count changed')
        if i == 0 and beauty:
            for s, old in zip(track['segments'], source_track['segments']):
                owner = old['material_id']
                if base_idx[owner].get('type') != 'video': continue
                require(s['extra_material_refs'][:len(old['extra_material_refs'])] == old['extra_material_refs'], 'Base refs changed')
                refs = s['extra_material_refs'][len(old['extra_material_refs']):]
                require(len(refs) == len(BEAUTY), 'Missing beauty node')
                for ref, control in zip(refs, BEAUTY):
                    require(ref not in new_ids and ref not in base_idx, 'Shared mutable beauty node')
                    node = idx[ref]
                    require(buckets[ref] == 'effects', 'Beauty material in wrong bucket')
                    require({k: v for k, v in node.items() if k != 'id'} == beauty_fields(control, bindings, owner), 'Beauty fields differ')
                    new_ids.add(ref)
                s['extra_material_refs'] = deepcopy(old['extra_material_refs'])
                for key, value in BEAUTY_VIDEO.items():
                    require(restored_idx[owner].get(key) == value, 'Beauty flags changed')
                    if key in base_idx[owner]: restored_idx[owner][key] = deepcopy(base_idx[owner][key])
                    else: restored_idx[owner].pop(key, None)
        require(track == source_track, 'Original tracks/audio/captions or timing changed')
    if adjust:
        track = actual['tracks'][-1]
        require(set(track) == {'id','type','name','is_default_name','segments'} and
                track['name'] == 'Windows调色分项测试' and track['is_default_name'] is False, 'Unexpected adjustment track fields')
        require(track['type'] == 'adjust' and [s['target_timerange'] for s in track['segments']] == expected_spans,
                'Adjustment must cover each video only, never a cover/tail photo')
        for s in track['segments']:
            require(set(s) == {'id','target_timerange','render_timerange','material_id','extra_material_refs',
                              'track_render_index','responsive_layout','source'}, 'Unexpected adjustment segment fields')
            require(s['track_render_index'] == len(base['tracks']) and s['render_timerange'] == {} and
                    s['responsive_layout'] == {} and s['source'] == 'segmentsourcenormal', 'Adjustment segment contract changed')
            placeholder = idx[s['material_id']]
            require(buckets[s['material_id']] == 'placeholders', 'Adjustment placeholder in wrong bucket')
            require({k:v for k,v in placeholder.items() if k != 'id'} == {'name':'Windows调色','type':'adjust'}, 'Wrong adjustment placeholder')
            refs = s['extra_material_refs']; require(len(refs) == 6, 'Adjustment refs missing')
            for ref, control in zip(refs[:5], ADJUST):
                require(buckets[ref] == 'effects', 'Adjustment effect in wrong bucket')
                require({k:v for k,v in idx[ref].items() if k != 'id'} == adjust_fields(control, bindings), 'Adjustment values changed')
            require({k:v for k,v in idx[refs[5]].items() if k not in ('id','constant_material_id')} == hsl_fields(bindings), 'HSL native values changed')
            require(buckets[refs[5]] == 'hsl', 'HSL material in wrong bucket')
            constant = idx[refs[5]].get('constant_material_id')
            require(isinstance(constant, str) and str(uuid.UUID(constant)).upper() == constant, 'Missing/invalid HSL constant identity')
            hsl_constants.append(constant)
            for ref in [s['material_id'], *refs]:
                require(ref not in new_ids and ref not in base_idx, 'Shared adjustment material')
                new_ids.add(ref)
        restored['tracks'].pop()
    for bucket, nodes in list(restored['materials'].items()):
        restored['materials'][bucket] = [n for n in nodes if n['id'] not in new_ids]
        if bucket not in base['materials'] and not restored['materials'][bucket]: del restored['materials'][bucket]
    require(restored == base, 'Unexpected native timeline mutation')
    # Also reject segment/track/material ID collisions, not just dangling refs.
    ids = list(idx) + [t['id'] for t in actual['tracks']] + [s['id'] for t in actual['tracks'] for s in t['segments']]
    require(len(ids) == len(set(ids)), 'Duplicate graph id')
    require(len(hsl_constants) == len(set(hsl_constants)) and not set(hsl_constants).intersection(ids), 'Shared/colliding HSL constant identity')
    return {'video_owners': len(videos), 'beauty_nodes': len(videos) * 10 if beauty else 0,
            'adjustment_segments': len(videos) if adjust else 0, 'base_preserved': True,
            'images_excluded': True, 'native_units_preserved': True, 'full_default_style': False}
