"""Append only the exact 高清增强 filter at native strength 0.12."""
from copy import deepcopy
import uuid
from .storage import require
RID='7426668776491453707'
TITLE='高清增强'
STRENGTH=.12

def uid():return str(uuid.uuid4()).upper()

def video_ranges(doc):
    require(doc['tracks'] and doc['tracks'][0]['type']=='video','Main video track required')
    videos={v['id']:v for v in doc['materials']['videos']}
    spans=[deepcopy(s['target_timerange']) for s in doc['tracks'][0]['segments'] if videos[s['material_id']]['type']=='video']
    require(spans,'No video ranges')
    return spans

def node_fields(path):
    require(isinstance(path,str) and path,'Bound Windows filter resource required')
    return {'effect_id':RID,'resource_id':RID,'third_resource_id':'0','name':TITLE,
            'type':'filter','sub_type':'none','path':path,'value':STRENGTH,'source_platform':1,
            'color_match_info':{},'multi_language_current':'','beauty_face_auto_retouch_info':{}}

def apply(source,path):
    require(not any(n.get('resource_id')==RID for n in source['materials'].get('effects',[])),
            'Requested filter already exists; do not silently overwrite')
    result=deepcopy(source)
    track={'id':uid(),'type':'filter','name':'高清增强 12%','is_default_name':False,'segments':[]}
    for span in video_ranges(source):
        node=dict(node_fields(path),id=uid());result['materials'].setdefault('effects',[]).append(node)
        track['segments'].append({'id':uid(),'material_id':node['id'],'target_timerange':span,
            'render_timerange':{},'extra_material_refs':[],'track_render_index':len(source['tracks']),
            'responsive_layout':{},'source':'segmentsourcenormal'})
    result['tracks'].append(track);verify(source,result,path)
    return result

def verify(source,actual,path):
    require(len(actual['tracks'])==len(source['tracks'])+1,'Unexpected track count')
    require(actual['tracks'][:-1]==source['tracks'],'Confirmed tracks/captions/audio changed')
    track=actual['tracks'][-1]
    require(set(track)=={'id','type','name','is_default_name','segments'} and track['type']=='filter'
            and track['name']=='高清增强 12%' and track['is_default_name'] is False,'Wrong filter track')
    require([s['target_timerange'] for s in track['segments']]==video_ranges(source),'Filter touches a cover/non-video range')
    old_ids={n['id'] for rows in source['materials'].values() for n in rows}
    indexed={n['id']:n for n in actual['materials'].get('effects',[])}
    new_ids=set()
    for segment in track['segments']:
        require(set(segment)=={'id','material_id','target_timerange','render_timerange','extra_material_refs','track_render_index','responsive_layout','source'},'Unexpected filter segment fields')
        require(segment['track_render_index']==len(source['tracks']) and segment['extra_material_refs']==[]
                and segment['render_timerange']=={} and segment['responsive_layout']=={}
                and segment['source']=='segmentsourcenormal','Filter segment contract changed')
        ref=segment['material_id'];require(ref not in old_ids and ref not in new_ids and ref in indexed,'Filter nodes must be independent')
        require({k:v for k,v in indexed[ref].items() if k!='id'}==node_fields(path),'Filter identity/path/12% strength changed')
        new_ids.add(ref)
    restored=deepcopy(actual);restored['tracks'].pop()
    restored['materials']['effects']=[n for n in restored['materials']['effects'] if n['id'] not in new_ids]
    if 'effects' not in source['materials'] and not restored['materials']['effects']:del restored['materials']['effects']
    require(restored==source,'Confirmed native content changed outside new filter')
    graph_ids=[n['id'] for rows in actual['materials'].values() for n in rows]+[t['id'] for t in actual['tracks']]+[s['id'] for t in actual['tracks'] for s in t['segments']]
    require(len(graph_ids)==len(set(graph_ids)),'Duplicate native graph identity')
    return {'filter_id':RID,'filter_name':TITLE,'strength':STRENGTH,'filter_segments':len(new_ids),
            'cover_excluded':True,'confirmed_content_preserved':True,'render_acceptance':'pending'}
