"""Clone the exact confirmed live draft without editing it; append one filter.

Only canonical project files, owned Resources and generated video analysis are
copied. Account/agent databases, draft key stores and UI caches are not read.
Source capture must be stable while the editor remains free to run.
"""
from copy import deepcopy
from datetime import datetime
import importlib,os,time
from pathlib import Path,PureWindowsPath
from . import windows_filter as effect
from . import windows_filter_resource as resources
from . import windows_backend as basic
from .onboarding import runtime_context,_safe_directory
from .storage import load,save,sha,manifest,copy_file,require,component
from .platforms import host

SCHEMA='lightcut-windows-filter-copy/v1'
ROOT_FILES={'draft_content.json','draft_content.json.bak','template-2.tmp','draft_meta_info.json',
            'draft_cover.jpg','key_value.json','draft_settings','timeline_layout.json','draft_virtual_store.json'}
TIMELINE_FILES={'draft_content.json','draft_content.json.bak','template-2.tmp','template.tmp','draft_cover.jpg'}
ATTACHMENT_FILES={'attachment_action_scene.json','attachment_id_mapping.json','attachment_pc_timeline.json',
                  'attachment_plugin_draft.json','attachment_script_video.json'}
TOKEN='##_draftpath_placeholder_0E685133-18CE-45ED-8CB8-2904A212EC80_##/'

def selected(source):
    source=_safe_directory(source);files={};directories=[]
    for path in sorted(source.rglob('*')):
        rel=path.relative_to(source);parts=rel.parts
        accepted=(len(parts)==1 and parts[0] in ROOT_FILES) or parts[0] in ('Resources','video') or (
            parts[0]=='Timelines' and ((len(parts)==2 and parts[1] in ('project.json','project.json.bak')) or
            (len(parts)==3 and parts[2] in TIMELINE_FILES) or
            (len(parts)==4 and parts[2]=='common_attachment' and parts[3] in ATTACHMENT_FILES)))
        if path.is_file() and parts[0]=='Timelines' and len(parts)>3 and not accepted:
            raise ValueError('Unreviewed nonempty timeline attachment; refusing incomplete copy: '+rel.as_posix())
        if path.is_dir() and (parts[0] in ('Resources','video','Timelines')):
            _safe_directory(path);directories.append(rel.as_posix())
        elif accepted and path.is_file():
            require(not path.is_symlink() and not getattr(path.lstat(),'st_file_attributes',0)&0x400,'Linked source file')
            files[rel.as_posix()]={'size':path.stat().st_size,'sha256':sha(path)}
    require(len(files)<=5000,'Source file count limit')
    require(sum(v['size'] for v in files.values())<1024**3,'Source copy size limit')
    return {'files':files,'directories':directories}

def remap(value,ids,old_root,new_root):
    if isinstance(value,dict):return {ids.get(k,k):remap(v,ids,old_root,new_root) for k,v in value.items()}
    if isinstance(value,list):return [remap(v,ids,old_root,new_root) for v in value]
    if not isinstance(value,str):return value
    if value in ids:return ids[value]
    if value.startswith(TOKEN):
        return TOKEN+'/'.join(ids.get(p,p) for p in value[len(TOKEN):].split('/'))
    p=PureWindowsPath(value)
    if p.is_absolute() and p.is_relative_to(PureWindowsPath(old_root)):
        relative=p.relative_to(PureWindowsPath(old_root))
        return PureWindowsPath(new_root,*[ids.get(part,part) for part in relative.parts]).as_posix()
    return value

def write_copy(path,data,root):
    require(path.resolve(strict=False).is_relative_to(root.resolve()),'Output write escaped clone')
    path.parent.mkdir(parents=True,exist_ok=True)
    require(not path.is_symlink(),'Linked output')
    with path.open('wb' if path.exists() else 'xb') as f:f.write(data);f.flush();os.fsync(f.fileno())

def mirror_paths(root,tid):
    return [root/rel for rel in ('draft_content.json','template-2.tmp','draft_content.json.bak',
        f'Timelines/{tid}/draft_content.json',f'Timelines/{tid}/template-2.tmp',f'Timelines/{tid}/draft_content.json.bak')]

def build(source,resource_record,output):
    require(host()=='windows','Windows 滤镜草稿构建必须在 Windows 上执行')
    source=Path(source).resolve(strict=True);output=Path(output).resolve(strict=False)
    require(not output.exists() and not output.is_relative_to(source),'Fresh output outside source required')
    resource=resources.verify(resource_record)
    runtime_context();j=basic.engine();runtime=j.nd.validate_runtime();helper=j.nd.helper()
    require(source.parent==j.nd.DRAFT_ROOT.resolve(),'Source must be the explicitly selected live draft')
    require(not output.is_relative_to(j.nd.DRAFT_ROOT.resolve()),'Offline clone cannot write live draft root')
    before=selected(source)
    j.nd.fresh_directory(output);snapshot=output/'source-snapshot';snapshot.mkdir()
    for d in before['directories']:(snapshot/d).mkdir(parents=True,exist_ok=True)
    for rel in before['files']:copy_file(source/rel,snapshot/rel)
    require(selected(source)==before and selected(snapshot)==before,'Source changed during snapshot; retained copy is not publishable')
    original=helper._decrypt_metadata_in_memory(snapshot/'draft_content.json')
    meta=helper._decrypt_metadata_in_memory(snapshot/'draft_meta_info.json')
    project=load(snapshot/'Timelines/project.json');old_tid=original['id']
    require(project['main_timeline_id']==old_tid and len(project['timelines'])==1 and project['timelines'][0]['id']==old_tid,
            'Unreviewed multi-timeline source')
    require(j.plat.same_draft_path(meta['draft_fold_path'],source),'Source metadata path mismatch')
    require(not meta.get('cloud_draft_sync') and not meta.get('draft_is_cloud_temp_draft')
            and not meta.get('draft_is_pippit_draft'),'Cloud-linked source needs a separate copy workflow')
    for key in ('tm_draft_cloud_entry_id','tm_draft_cloud_parent_entry_id','tm_draft_cloud_space_id'):
        require(meta.get(key,-1) in (-1,0,'',None),'Cloud identity must not be duplicated')
    for rel in ('template-2.tmp',f'Timelines/{old_tid}/draft_content.json',f'Timelines/{old_tid}/template-2.tmp'):
        require(helper._decrypt_metadata_in_memory(snapshot/rel)==original,'Source active mirrors differ')
    require(not original['materials'].get('drafts'),'Nested source drafts are not supported')
    did,tid,pid=effect.uid(),effect.uid(),effect.uid()
    name='Windows高清增强12%-'+datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+did[:6]
    component(name);target=j.nd.DRAFT_ROOT/name;require(not target.exists(),'New target already exists')
    ids={meta['draft_id']:did,old_tid:tid,project['id']:pid}
    baseline=remap(original,ids,str(source),str(target))
    timeline=effect.apply(baseline,Path(resource['package']).as_posix())
    importlib.import_module('native_edit').basic_validation(timeline)
    draft=output/'draft';draft.mkdir()
    def mapped_rel(rel):
        parts=Path(rel).parts
        return Path('Timelines',tid,*parts[2:]) if len(parts)>1 and parts[:2]==('Timelines',old_tid) else Path(rel)
    for d in before['directories']:(draft/mapped_rel(d)).mkdir(parents=True,exist_ok=True)
    for rel in before['files']:copy_file(snapshot/rel,draft/mapped_rel(rel))
    # Rewrite only new-copy project identity/path structures. Existing effect
    # nodes, their values and analysis ownership IDs are deliberately retained.
    for rel in ('Timelines/project.json','Timelines/project.json.bak','timeline_layout.json','key_value.json','draft_virtual_store.json'):
        path=draft/rel
        if path.is_file():write_copy(path,j.nd.packed(remap(load(path),ids,str(source),str(target))),draft)
    legacy=draft/'Timelines'/tid/'template.tmp'
    if legacy.is_file():write_copy(legacy,j.nd.packed(remap(load(legacy),ids,str(source),str(target))),draft)
    helper._encrypt_metadata_from_memory(j.nd.packed(timeline),output/'timeline.encrypted')
    require(helper._decrypt_metadata_in_memory(output/'timeline.encrypted')==timeline,'Filter native write/read mismatch')
    for path in mirror_paths(draft,tid):write_copy(path,(output/'timeline.encrypted').read_bytes(),draft)
    new_meta=remap(meta,ids,str(source),str(target))
    now=time.time_ns()//1000
    new_meta.update(draft_id=did,draft_name=name,draft_fold_path=j.plat.draft_path_text(target),
                    draft_root_path=str(j.nd.DRAFT_ROOT),tm_draft_create=now,tm_draft_modified=now)
    new_meta['draft_timeline_materials_size_']=sum(p.stat().st_size for p in (draft/'Resources').rglob('*') if p.is_file())+(output/'timeline.encrypted').stat().st_size
    helper._encrypt_metadata_from_memory(j.nd.packed(new_meta),output/'metadata.encrypted')
    write_copy(draft/'draft_meta_info.json',(output/'metadata.encrypted').read_bytes(),draft)
    save(output/'source-timeline.json',original);save(output/'baseline.json',baseline);save(output/'timeline.json',timeline)
    save(output/'metadata.json',new_meta);save(output/'resource.json',resource);save(output/'source-manifest.json',before)
    require(selected(source)==before,'Source changed before clone completion; do not publish')
    record={'schema':SCHEMA,'copy_contract':'canonical-and-reviewed-timeline-attachments/v2',
      'status':'built-filter-copy','name':name,'target':str(target),'draft_id':did,'timeline_id':tid,
      'runtime_profile':runtime['runtime_profile'],'source':str(source),'source_draft_id':meta['draft_id'],
      'identity_map':ids,'files':manifest(draft),'directories':[p.relative_to(draft).as_posix() for p in sorted(draft.rglob('*')) if p.is_dir()],
      'inputs':{n:sha(output/n) for n in ('source-timeline.json','baseline.json','timeline.json','metadata.json','resource.json','source-manifest.json')},
      'source_snapshot_files':manifest(snapshot),'filter_id':effect.RID,'strength':.12,'full_default_style':False,
      'user_confirmed_source_effects':['beauty','adjustment'],'new_filter_render_acceptance':'pending-user',
      'ui_actions':0,'live_written':False}
    save(output/'build.json',record);result=verify(output);save(output/'verification.json',result);return result

def verify(output):
    require(host()=='windows','Windows 滤镜原生回读必须在 Windows 上执行')
    output=Path(output).resolve(strict=True);record=load(output/'build.json')
    require(record.get('copy_contract')=='canonical-and-reviewed-timeline-attachments/v2','Superseded/incomplete copy contract; do not register')
    require(record['schema']==SCHEMA and record['filter_id']==effect.RID and record['strength']==.12,'Wrong filter-copy identity')
    require(record['full_default_style'] is False and record['live_written'] is False,'Unexpected acceptance flags')
    for name,digest in record['inputs'].items():require(sha(output/name)==digest,'Frozen filter input changed: '+name)
    resource=resources.verify(output/'resource.json')
    runtime_context();j=basic.engine();j.nd.validate_runtime();helper=j.nd.helper()
    require(record['runtime_profile']==j.nd.doctor()['runtime_profile'],'Runtime profile changed')
    snapshot=output/'source-snapshot';draft=output/'draft'
    require(manifest(snapshot)==record['source_snapshot_files'],'Source snapshot changed')
    original=helper._decrypt_metadata_in_memory(snapshot/'draft_content.json')
    require(original==load(output/'source-timeline.json'),'Source snapshot native data changed')
    baseline=remap(original,record['identity_map'],record['source'],record['target'])
    require(baseline==load(output/'baseline.json'),'Confirmed content changed while rebasing draft identity')
    require(manifest(draft)==record['files'],'Filter draft bytes changed')
    require([p.relative_to(draft).as_posix() for p in sorted(draft.rglob('*')) if p.is_dir()]==record['directories'],'Filter draft directories changed')
    timeline=helper._decrypt_metadata_in_memory(draft/'draft_content.json')
    require(timeline==load(output/'timeline.json'),'Filter native readback differs')
    graph=effect.verify(baseline,timeline,Path(resource['package']).as_posix())
    importlib.import_module('native_edit').basic_validation(timeline)
    mirrors=mirror_paths(draft,record['timeline_id'])
    require(len({sha(p) for p in mirrors})==1 and len({p.stat().st_ino for p in mirrors})==6,'Six filter mirrors differ or share physical file')
    for path in mirrors:require(helper._decrypt_metadata_in_memory(path)==timeline,'Native mirror readback failed')
    meta=helper._decrypt_metadata_in_memory(draft/'draft_meta_info.json')
    require(meta==load(output/'metadata.json') and meta['draft_id']==record['draft_id'] and meta['draft_name']==record['name'],'Filter metadata changed')
    require(load(draft/'Timelines/project.json')['main_timeline_id']==record['timeline_id'],'Timeline project identity differs')
    return {'status':'filter-copy-native-readback-verified','name':record['name'],'draft':str(draft),'graph':graph,
            'source_confirmed_effects_preserved':True,'six_mirrors_verified':True,'ui_actions':0,'full_default_style':False,
            'filter_render_and_save_reopen':'pending-user','Pro_policy':'preserved; no export authorization asserted'}

def publication_record(output):
    verify(output);record=load(Path(output)/'build.json');j=basic.engine()
    require('高清增强12%' in record['name'],'Filter test label removed')
    return dict(record,files=j.files_manifest(Path(output)/'draft'))

def verify_live(output):
    record=publication_record(output);j=basic.engine();target=Path(record['target'])
    require(target.parent.resolve()==j.nd.DRAFT_ROOT.resolve() and not target.is_symlink(),'Unexpected filter target')
    require(j.files_manifest(target)==record['files'],'Registered filter bytes changed')
    expected=load(Path(output)/'build.json')['directories']
    require(all((target/rel).is_dir() for rel in expected),'Registered analysis directories missing')
    entries=load(j.nd.DRAFT_ROOT/'root_meta_info.json')['all_draft_store']
    matches=[e for e in entries if e.get('draft_id')==record['draft_id']]
    require(len(matches)==1 and j.plat.same_draft_path(matches[0]['draft_fold_path'],target),'New filter home entry missing/ambiguous')
    return {'status':'filter-test-registration-verified','name':record['name'],'draft':str(target),'live_written':True,
            'strength':.12,'full_default_style':False,'ui_actions':0,'filter_render_and_save_reopen':'pending-user'}

def register(output,audit):
    require(host()=='windows','Windows 滤镜登记必须在 Windows 上执行')
    publication_record(output)
    if basic.process_pids():return {'status':'waiting-for-editor-to-close','live_written':False,'ui_actions':0}
    j=basic.engine()
    return j.publish(Path(output),Path(audit),verify_build_fn=publication_record,verify_live_fn=verify_live)
