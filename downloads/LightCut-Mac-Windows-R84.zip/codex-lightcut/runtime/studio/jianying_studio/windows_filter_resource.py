"""Official Windows metadata/permission gate, independent of Mac assets."""
import hashlib,io,json,re,stat,zipfile
from pathlib import Path
from urllib.parse import urlencode,urlsplit
from urllib.request import Request,build_opener,HTTPRedirectHandler
from .storage import require,save,load,manifest,sha
from .onboarding import runtime_context,cache_roots,_safe_directory,resource_manifest
from .platforms import host
from .windows_filter import RID,TITLE

ENDPOINT='https://lv-pc-api.ulikecam.com/artist/v1/effect/mget_item'

class OfficialRedirect(HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        u=urlsplit(newurl)
        require(u.scheme=='https' and (u.hostname=='lv-pc-api.ulikecam.com' or (u.hostname or '').endswith('.bytecdn.com')),
                'Unexpected resource redirect host')
        return super().redirect_request(req,fp,code,msg,headers,newurl)

def validate_metadata(attr,purpose='native-draft-preview'):
    require(purpose=='native-draft-preview','This adapter does not authorize Pro export or other commercial use')
    require(attr.get('id')==RID and attr.get('effect_id')==RID and attr.get('title')==TITLE
            and attr.get('effect_type')==12,'Official filter identity differs')
    business=json.loads(attr['business_info']['json_str'])
    require(business.get('is_expired') is False,'Expired or unverified resource availability')
    paid=business.get('paid_type');vip=business.get('is_vip')
    require(paid in ('free','subscribe') and isinstance(vip,bool),'Unknown resource permission contract')
    # The Windows catalog publicly supplies a download URL. Preserve its Pro
    # policy; downloading for an editable draft is not an export authorization.
    # Never synthesize an entitlement or change the application's paid flags.
    params=json.loads(attr['sdk_extra'])['setting']['effect_adjust_params']
    require(any(p.get('effect_key')=='effects_adjust_filter' and p.get('min')==0 and p.get('max')==1 for p in params),
            'Unreviewed filter strength contract')
    require(re.fullmatch('[a-f0-9]{32}',attr.get('md5','')) is not None,'Missing official package digest')
    require(attr.get('sdk_model')==['tt_skin_seg'],'Unknown filter model dependencies')
    return business

def fetch(output):
    require(host()=='windows','Windows 滤镜资源准备必须在 Windows 上执行')
    output=Path(output).resolve();require(not output.exists(),'Resource output exists; never overwrite')
    runtime,apps=runtime_context()
    require(runtime['runtime_profile']=='jy14-headless-win-11.5.0','Unreviewed Windows runtime')
    opener=build_opener(OfficialRedirect())
    body={'app_id':3704,'items':[{'id':RID,'type':'filter'}]}
    # Windows parameters are mandatory: a generic request can report a different license.
    url=ENDPOINT+'?'+urlencode({'device_platform':'windows','app_version':runtime['app_version'].rsplit('.',1)[0],'aid':3704})
    request=Request(url,data=json.dumps(body).encode(),headers={'Content-Type':'application/json','User-Agent':'LightCut-Windows-Development/1.0'})
    with opener.open(request,timeout=20) as response:raw=response.read(4_000_001)
    require(len(raw)<=4_000_000,'Metadata response too large')
    response=json.loads(raw);require(str(response.get('ret'))=='0','Official Windows metadata request failed')
    items=response['data']['effect_item_list'];require(len(items)==1,'Ambiguous filter metadata')
    attr=items[0]['common_attr'];business=validate_metadata(attr)
    download=attr['item_urls'][0];u=urlsplit(download)
    require(u.scheme=='https' and (u.hostname or '').endswith('.bytecdn.com'),'Unexpected official CDN')
    with opener.open(Request(download,headers={'User-Agent':'LightCut-Windows-Development/1.0'}),timeout=60) as response:
        payload=response.read(64*1024*1024+1)
    require(len(payload)<=64*1024*1024 and hashlib.md5(payload).hexdigest()==attr['md5'],'Official ZIP integrity mismatch')
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        entries=archive.infolist();require(len(entries)<=5000 and sum(i.file_size for i in entries)<=256*1024*1024,'Resource size limit')
        seen=set()
        for item in entries:
            name=item.filename.rstrip('/')
            require(name and '\\' not in name and ':' not in name and not name.startswith('/')
                    and all(p not in ('','.','..') for p in name.split('/')),'Unsafe archive path')
            require(stat.S_IFMT(item.external_attr>>16)!=stat.S_IFLNK,'Linked archive resource')
            require(name.casefold() not in seen,'Case-insensitive archive collision');seen.add(name.casefold())
        require(archive.testzip() is None,'ZIP CRC mismatch')
        output.mkdir(parents=True);package=output/'package';package.mkdir()
        archive.extractall(package)
    cfg=load(package/'config.json')
    require(isinstance(cfg.get('effect',{}).get('Link'),list),'Unknown native filter package format')
    for link in cfg['effect']['Link']:
        relative=link.get('path','').rstrip('/')
        require(relative and ':' not in relative and '\\' not in relative and not relative.startswith('/')
                and '..' not in relative.split('/'),'Unsafe filter child reference')
        require((package/relative).exists(),'Missing filter sub-resource')
    candidates=list((apps[0]/'Resources/models/skin_seg').glob('tt_skin_seg*.model'))
    candidates+=list((cache_roots('windows')[0]/'effect/model').glob('tt_skin_seg*.model'))
    require(candidates,'Windows tt_skin_seg dependency unavailable')
    models=[]
    for p in candidates:
        _safe_directory(p.parent);require(not p.is_symlink(),'Linked model')
        models.append({'path':str(p),'size':p.stat().st_size,'sha256':sha(p)})
    record={'schema':'lightcut-windows-official-filter/v1','identity':{k:attr[k] for k in ('id','effect_id','title','effect_type','md5')},
      'metadata_endpoint':ENDPOINT,'platform':'windows','runtime':runtime,'metadata_response_sha256':hashlib.sha256(raw).hexdigest(),
      'archive_sha256':hashlib.sha256(payload).hexdigest(),'business':{'is_vip':business['is_vip'],'paid_type':business['paid_type'],'is_expired':False},
      'entitlement_basis':'not-asserted-editor-enforces-official-policy','purpose':'native-draft-preview',
      'package':str(package),'files':manifest(package),'models':models,'sdk_model':'tt_skin_seg',
      'parameter':{'key':'effects_adjust_filter','min':0,'max':1,'requested':.12},
      'model_execution':'not-tested','render_acceptance':'pending','account_credentials_used':False}
    save(output/'resource.json',record);return record

def record_contract(record):
    require(record['schema']=='lightcut-windows-official-filter/v1' and record['platform']=='windows','Not a Windows filter contract')
    identity=record['identity']
    require(identity.get('id')==RID and identity.get('effect_id')==RID and identity.get('title')==TITLE
            and identity.get('effect_type')==12,'Filter contract changed')
    require(record.get('parameter')=={'key':'effects_adjust_filter','min':0,'max':1,'requested':.12},'Filter parameter contract changed')
    require(record['business']['is_expired'] is False and record['business'].get('paid_type') in ('free','subscribe')
            and type(record['business'].get('is_vip')) is bool,'Unknown or expired resource policy')
    require(record['purpose']=='native-draft-preview' and record['entitlement_basis']=='not-asserted-editor-enforces-official-policy',
            'Resource preparation must not assert or bypass an entitlement')
    require(record.get('sdk_model')=='tt_skin_seg' and isinstance(record.get('models'),list) and record['models'],
            'Windows model dependency record is missing')
    for model in record['models']:
        require(isinstance(model.get('path'),str) and model['path'] and type(model.get('size')) is int and model['size']>0
                and isinstance(model.get('sha256'),str) and re.fullmatch('[a-f0-9]{64}',model['sha256']), 'Invalid model evidence')
    require(isinstance(record.get('files'),dict) and record['files'],'Empty filter resource manifest')
    return record

def verify(record_path):
    require(host()=='windows','Windows 滤镜资源校验必须在 Windows 上执行')
    record=record_contract(load(record_path));runtime,_=runtime_context()
    require(record['runtime']==runtime,'Runtime changed since official resource preparation')
    package=_safe_directory(record['package'])
    require(resource_manifest(package)==record['files'],'Prepared official filter changed')
    for model in record['models']:
        path=Path(model['path']);_safe_directory(path.parent)
        require(not path.is_symlink() and path.stat().st_size==model['size'] and sha(path)==model['sha256'],'Windows model dependency changed')
    return record
