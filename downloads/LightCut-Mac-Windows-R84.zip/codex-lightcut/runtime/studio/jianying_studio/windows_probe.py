"""Read-only Windows evidence collector. No application launch or draft writes."""
import ctypes
import os
from pathlib import Path
import sys

from .storage import require, sha


def file_version(path):
    require(sys.platform == 'win32', 'Windows version API requires Windows')
    version = ctypes.WinDLL('version', use_last_error=True)
    version.GetFileVersionInfoSizeW.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_uint32)]
    version.GetFileVersionInfoSizeW.restype = ctypes.c_uint32
    version.GetFileVersionInfoW.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p]
    version.VerQueryValueW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(ctypes.c_uint32)]
    ignored = ctypes.c_uint32()
    size = version.GetFileVersionInfoSizeW(str(path), ctypes.byref(ignored))
    if not size: return None
    buffer = ctypes.create_string_buffer(size)
    require(version.GetFileVersionInfoW(str(path), 0, size, buffer), 'Cannot read executable version')
    address, length = ctypes.c_void_p(), ctypes.c_uint32()
    require(version.VerQueryValueW(buffer, '\\', ctypes.byref(address), ctypes.byref(length)), 'Missing fixed file version')
    require(length.value >= 52, 'Truncated version record')
    words = ctypes.cast(address, ctypes.POINTER(ctypes.c_uint32 * 13)).contents
    require(words[0] == 0xFEEF04BD, 'Unexpected version record')
    ms, ls = words[2], words[3]
    return '.'.join(str(x) for x in (ms >> 16, ms & 65535, ls >> 16, ls & 65535))


def collect(app_path=None, draft_root=None):
    require(sys.platform == 'win32', 'Run this evidence collector on Windows')
    # Same pinned, read-only discovery module used by doctor and native loading.
    # Importing it does not load the Jianying DLL.
    from .windows_backend import _imports
    _imports()
    import windows_platform as platform
    applications, checks = [], []
    selection = None
    try:
        selected = platform.discover_app_bundle()
        require(selected is not None, 'No selected Jianying installation; set JY14_APP_BUNDLE or pilot --app-dir')
        selection = platform.inspect(selected)
        exe = Path(app_path) if app_path else selection.directory / platform.EDITOR_IMAGE
        require(exe.name.lower() == platform.EDITOR_IMAGE.lower() and exe.is_file() and not exe.is_symlink(),
                'Selected Jianying executable is missing or not a regular executable')
        require(exe.parent.resolve(strict=True) == selection.directory,
                'Explicit executable differs from doctor selection; select the same JY14_APP_BUNDLE')
        version = file_version(exe)
        library = selection.directory / platform.ENGINE_LIBRARY
        applications.append({'path': str(exe), 'version': version, 'sha256': sha(exe),
                             'libraries': [{'name': library.name, 'size': library.stat().st_size,
                                            'sha256': selection.library_sha256}]})
        checks.extend([{'check': 'installation reviewed', 'ok': platform.review_status(selection)['reviewed']},
                       {'check': 'executable version matches selected installation',
                        'ok': version == selection.version + '.' + selection.build}])
        require(platform.inspect(selected) == selection, 'Installation changed during evidence collection')
    except (ValueError, OSError) as exc:
        checks.append({'check': 'selected installation evidence', 'ok': False, 'detail': str(exc)})
    root = Path(draft_root) if draft_root else platform.draft_root()
    index = root / 'root_meta_info.json'
    return {'schema': 'jianying-studio-windows-evidence/v1', 'applications': applications,
            'status': 'complete' if applications and checks and all(c['ok'] for c in checks) else 'incomplete',
            'checks': checks, 'selected_installation': str(selection.directory) if selection else None,
            'native_library_loaded': False,
            'draft_root_candidate': str(root), 'index_exists': index.is_file(),
            'index_size': index.stat().st_size if index.is_file() else None,
            'native_draft_support': 'experimental-basic-drafts-pending-real-machine-validation', 'ui_actions': 0, 'draft_writes': 0,
            'credentials_read': False, 'project_contents_collected': False}
