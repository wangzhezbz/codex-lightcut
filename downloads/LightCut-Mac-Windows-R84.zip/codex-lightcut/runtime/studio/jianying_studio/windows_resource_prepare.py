"""Selected Windows beauty resources in LightCut-owned storage, never editor cache.

Exact reviewed package bytes and identities are mandatory. This module does not
install models, assert paid entitlements or operate the editor.
"""
import hashlib
import io
import json
from pathlib import Path
import re
import stat
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler
import uuid
import zipfile

from .storage import load, save, sha, require
from .platforms import host
from .onboarding import runtime_context, cache_roots, _safe_directory
from . import windows_effect_resources as local
from .windows_filter_resource import ENDPOINT

CATALOG = Path(__file__).resolve().parents[1]/'resources/windows-downloads-11.5.0.json'
PIN = 'dccc4aa89f142f74b2a646e3e84dd18b46c2da421078b938b9aeb48ea71bc6b6'
SCHEMA = 'lightcut-windows-prepared-effects/v1'
ARCHIVES = CATALOG.with_name('windows-beauty-archives-11.5.0.json')
ARCHIVES_PIN = '6eb21791e14357b9fb2d43e9733d0bacd6a2da914a4634a2139477879ecaa2b0'


def archive_spec(key):
    require(sha(ARCHIVES)==ARCHIVES_PIN, 'Reviewed beauty archive catalog changed')
    return load(ARCHIVES)['resources'][key]


def beauty_url_allowed(url):
    value=urlsplit(url)
    return (value.scheme=='https' and not value.username and not value.password and value.port in (None,443)
            and ((value.hostname or '').endswith('.bytecdn.com')
                 or re.fullmatch(r'p\d+-artist-file-sign\.byteimg\.com',value.hostname or '') is not None))


class BeautyRedirect(HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        value=urlsplit(newurl)
        api=(value.scheme=='https' and value.hostname=='lv-pc-api.ulikecam.com' and not value.username
             and not value.password and value.port in (None,443))
        require(api or beauty_url_allowed(newurl), 'Unexpected beauty resource redirect')
        return super().redirect_request(req,fp,code,msg,headers,newurl)


def catalogs():
    require(sha(CATALOG) == PIN and sha(local.CATALOG) == local.CATALOG_SHA256, 'Windows resource catalog changed')
    return load(local.CATALOG), load(CATALOG)


def private_root():
    from .preferences import home_dir
    return home_dir()/'resources/windows-beauty'


def policy(attr, spec):
    require(all(attr.get(k) == spec[k] for k in ('id','effect_id','title','effect_type','md5','sdk_model')),
            'Official beauty package identity or dependencies changed')
    business = json.loads(attr['business_info']['json_str'])
    require(business.get('is_expired') is False and type(business.get('is_vip')) is bool
            and business.get('paid_type') in ('free','subscribe'), 'Unknown or expired official resource policy')
    return {k:business[k] for k in ('is_vip','paid_type','is_expired')}


def metadata(spec, runtime):
    opener = build_opener(BeautyRedirect())
    url = ENDPOINT+'?'+urlencode({'device_platform':'windows','app_version':runtime['app_version'].rsplit('.',1)[0],'aid':3704})
    request = Request(url, data=json.dumps({'app_id':3704,'items':[{'id':spec['id'],'type':'beauty'}]}).encode(),
                      headers={'Content-Type':'application/json','User-Agent':'LightCut-Windows-Development/1.0'})
    with opener.open(request, timeout=20) as response: raw=response.read(4_000_001)
    require(len(raw)<=4_000_000, 'Official metadata too large')
    result=json.loads(raw)
    require(str(result.get('ret'))=='0', 'Official beauty metadata request failed')
    items=result['data']['effect_item_list'];require(len(items)==1, 'Ambiguous beauty metadata')
    attr=items[0]['common_attr'];business=policy(attr,spec)
    urls=attr.get('item_urls');require(isinstance(urls,list) and urls, 'Missing official download URL')
    url=urls[0]
    require(beauty_url_allowed(url), 'Unexpected beauty resource host')
    return url, business, hashlib.sha256(raw).hexdigest()


def extract_checked(payload, output, spec, *, reviewed_archive=None):
    """Validate entire ZIP and exact reviewed file set before creating output."""
    require(len(payload)<=64*1024*1024, 'Beauty archive too large')
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        entries=archive.infolist();require(len(entries)<=5000 and sum(i.file_size for i in entries)<=256*1024*1024,
                                         'Beauty archive exceeds limits')
        seen=set();files={}
        for item in entries:
            name=item.filename.rstrip('/')
            require(name and '\\' not in name and ':' not in name and not name.startswith('/')
                    and all(p not in ('','.','..') and not p.endswith(('.', ' ')) for p in name.split('/')), 'Unsafe beauty ZIP path')
            require(stat.S_IFMT(item.external_attr>>16)!=stat.S_IFLNK and not item.flag_bits & 1, 'Linked/encrypted resource')
            require(name.casefold() not in seen, 'Beauty archive path collision');seen.add(name.casefold())
            if not item.is_dir():
                data=archive.read(item);files[name]={'size':len(data),'sha256':hashlib.sha256(data).hexdigest()}
        if reviewed_archive is None:
            require(files==spec['files'], 'Official beauty ZIP differs from reviewed Windows bytes')
        else:
            require(hashlib.sha256(payload).hexdigest()==reviewed_archive['archive_sha256']
                    and files==reviewed_archive['files'], 'Official beauty archive changed')
            omitted=set(reviewed_archive['omitted_metadata'])
            require(omitted==set(files)-set(spec['files'])
                    and all(n.startswith('__MACOSX/') or Path(n).name=='.DS_Store' for n in omitted),
                    'Unreviewed extra beauty archive files')
            require({n:v for n,v in files.items() if n not in omitted}==spec['files'],
                    'Native beauty bytes differ from reviewed Windows cache')
        if output is None: return files  # Static inspection; no extraction or installation.
        output=Path(output);require(not output.exists(), 'Never overwrite resource output')
        output.mkdir(parents=True)
        _safe_directory(output)
        # Only reviewed native files are created; known packaging metadata is
        # validated above but never written. No cache cleanup/deletion needed.
        for name in spec['files']: archive.extract(name,output)
    local.validate_package(output,spec)


def download(key, spec, identity, runtime, root):
    require(host()=='windows', 'Windows beauty downloads require Windows')
    url,business,response_sha=metadata(identity,runtime)
    with build_opener(BeautyRedirect()).open(Request(url,headers={'User-Agent':'LightCut-Windows-Development/1.0'}), timeout=60) as response:
        payload=response.read(64*1024*1024+1)
    require(len(payload)<=64*1024*1024 and hashlib.md5(payload).hexdigest()==identity['md5'], 'Official beauty archive digest mismatch')
    reviewed=archive_spec(key)
    require(reviewed['archive_md5']==identity['md5'], 'Beauty archive catalog identity mismatch')
    output=Path(root)/key/uuid.uuid4().hex
    extract_checked(payload,output/'package',spec,reviewed_archive=reviewed)
    record={'schema':'lightcut-windows-beauty-download/v1','key':key,'identity':identity,'runtime':runtime,
            'package':str(output/'package'),'business':business,'catalog_sha256':local.CATALOG_SHA256,
            'download_catalog_sha256':PIN,'metadata_response_sha256':response_sha,
            'archive_sha256':hashlib.sha256(payload).hexdigest(),
            'archive_catalog_sha256':ARCHIVES_PIN,
            'entitlement_basis':'not-asserted-editor-enforces-official-policy'}
    save(output/'resource.json',record)
    return output/'package', output/'resource.json'


def verify_download(path, key, spec, identity, runtime):
    path=Path(path);_safe_directory(path.parent)
    require(not path.is_symlink() and not getattr(path.lstat(),'st_file_attributes',0)&0x400, 'Linked resource receipt')
    r=load(path)
    require(r['schema']=='lightcut-windows-beauty-download/v1' and r['key']==key and r['identity']==identity
            and r['runtime']==runtime and r['catalog_sha256']==local.CATALOG_SHA256 and r['download_catalog_sha256']==PIN,
            'Prepared beauty receipt mismatch')
    reviewed=archive_spec(key)
    require(r.get('archive_catalog_sha256')==ARCHIVES_PIN and r.get('archive_sha256')==reviewed['archive_sha256']
            and identity['md5']==reviewed['archive_md5'], 'Prepared beauty archive evidence changed')
    require(r['business'].get('is_expired') is False and type(r['business'].get('is_vip')) is bool
            and r['business'].get('paid_type') in ('free','subscribe')
            and r['entitlement_basis']=='not-asserted-editor-enforces-official-policy', 'Invalid beauty policy record')
    package=path.parent/'package'
    require(Path(r['package']).resolve()==package.resolve(), 'Resource receipt escapes its package')
    local.validate_package(package,spec)
    return package


def model_inventory(applications):
    """Bounded filename/hash evidence only; no downloads or execution of model code."""
    roots=[applications[0]/'Resources/models', *(r/'effect/model' for r in cache_roots('windows'))]
    found=[];count=0
    for root in roots:
        if not root.is_dir(): continue
        _safe_directory(root)
        for path in root.rglob('*'):
            count+=1;require(count<=20000, 'Model inventory limit exceeded')
            require(not path.is_symlink() and not getattr(path.lstat(),'st_file_attributes',0)&0x400, 'Linked model tree')
            if path.is_file() and path.suffix.lower() in ('.model','.bin'):
                found.append(path)
    return found


def model_matches(name, path):
    # tt_face_extra must never satisfy tt_face. Only explicit version suffixes.
    return path.stem == name or re.fullmatch(re.escape(name)+r'_(?:v?\d|fp\d|size\d|md5[a-f0-9]).*',path.stem) is not None


def models_for(required, candidates):
    models=[];missing=[]
    for name in sorted(required):
        # Deliberately no guessed aliases: unknown SDK model mappings stay explicit.
        matches=[p for p in candidates if model_matches(name,p)]
        if not matches:missing.append(name)
        else:
            for p in matches:
                require(p.stat().st_size>0, 'Empty model file')
                models.append({'sdk_model':name,'path':str(p),'size':p.stat().st_size,'sha256':sha(p)})
    return models,missing


def prepare(scope, *, allow_download=False, root=None, ignore_effect_cache=False):
    require(host()=='windows', 'Windows resources must be prepared on Windows')
    from .windows_effects import SCOPES, BEAUTY
    require(scope in SCOPES, 'Unknown selected effect scope')
    catalog, downloads=catalogs();runtime,apps=runtime_context()
    require(runtime['app_version']==catalog['app_version'] and runtime['library_sha256']==catalog['library_sha256'],
            'Unreviewed Windows runtime')
    required=({n[2] for n in BEAUTY} if 'beauty' in scope else set()) | ({'adjust'} if 'adjustment' in scope else set())
    if 'beauty' in scope:
        seen={(c['resource_id'],c['name']) for p in catalog['control_identity_evidence'] for c in p['controls']}
        require(all((n[1],n[0]) in seen for n in BEAUTY), 'Reviewed control identity missing')
    root=Path(root) if root else private_root()
    if root.exists():_safe_directory(root)
    report={'schema':SCHEMA,'scope':scope,'runtime':runtime,'catalog_sha256':local.CATALOG_SHA256,'download_catalog_sha256':PIN,
            'status':'needs-attention','bindings':{},'sources':{},'checks':[],'blockers':[], 'downloads':0,
            'models':[], 'ignore_effect_cache':ignore_effect_cache,'ui_actions':0,'editor_cache_written':False,
            'provenance':'reviewed-Windows-catalog-and-exact-package-bytes','model_execution':'not-tested'}
    required_models=set()
    for key in sorted(required):
        spec=catalog['resources'][key]
        if spec['scope']=='cache':required_models.update(downloads['resources'][key]['sdk_model'] or [])
        try:
            # Managed downloads must also be used by real delivery when an
            # editor cache exists. Receipts and bytes are verified before use.
            package=None
            if spec['scope']=='cache':
                for receipt in sorted((root/key).glob('*/resource.json'))[-20:]:
                    try:
                        package=verify_download(receipt,key,spec,downloads['resources'][key],runtime)
                        source={'kind':'private-download','receipt':str(receipt)};break
                    except (ValueError,OSError,KeyError):continue
            if package is None:
                roots=([apps[0]/'Resources'] if spec['scope']=='application' else ([] if ignore_effect_cache else cache_roots('windows')))
                candidates=[r/spec['relative'] for r in roots if (r/spec['relative']).is_dir()]
                require(len(candidates)<=1, 'Ambiguous local Windows effect')
                source={'kind':'application' if spec['scope']=='application' else 'editor-cache'}
                if candidates:
                    package=candidates[0];local.validate_package(package,spec)
                else:
                    require(spec['scope']=='cache', 'Missing reviewed application adjustment resource')
                    require(allow_download, 'Missing reviewed beauty resource; automatic preparation required')
                    package,receipt=download(key,spec,downloads['resources'][key],runtime,root)
                    source={'kind':'private-download','receipt':str(receipt)};report['downloads']+=1
            report['bindings'][key]=package.as_posix();report['sources'][key]=source
            report['checks'].append({'resource':key,'status':'matched','files':len(spec['files']),'hashes_verified':True})
        except (ValueError,OSError,KeyError,zipfile.BadZipFile) as error:
            report['checks'].append({'resource':key,'status':'unavailable'})
            report['blockers'].append({'code':'windows-effect-unavailable','resource':key,'message':str(error),'owner':'resource-adapter'})
    report['models'],missing=models_for(required_models,model_inventory(apps)) if required_models else ([],[])
    report['missing_model_mappings']=missing
    if missing:report['blockers'].append({'code':'windows-model-unavailable','models':missing,'owner':'resource-adapter',
                                         'message':'缺少可验证的美颜模型或模型名称映射；效果包已保留，不会静默省略美颜'})
    if not report['blockers']:report['status']='ready-for-build'
    return report


def verify(record):
    require(host()=='windows' and record['schema']==SCHEMA and record['status']=='ready-for-build', 'Prepared effect profile unavailable')
    catalog,downloads=catalogs();runtime,apps=runtime_context()
    require(record['runtime']==runtime and record['catalog_sha256']==local.CATALOG_SHA256 and record['download_catalog_sha256']==PIN,
            'Prepared effect runtime/catalog changed')
    from .windows_effects import SCOPES, BEAUTY
    scope=record['scope'];require(scope in SCOPES,'Invalid prepared scope')
    keys=({n[2] for n in BEAUTY} if 'beauty' in scope else set()) | ({'adjust'} if 'adjustment' in scope else set())
    require(set(record['bindings'])==set(record['sources'])==keys, 'Prepared effect selection changed')
    for key in keys:
        spec=catalog['resources'][key];source=record['sources'][key];path=Path(record['bindings'][key])
        if source['kind']=='private-download':
            require(spec['scope']=='cache','Cannot download application adjustment resources')
            checked=verify_download(source['receipt'],key,spec,downloads['resources'][key],runtime)
            require(checked.resolve()==path.resolve(), 'Prepared effect binding changed')
        else:
            roots=[apps[0]/'Resources'] if spec['scope']=='application' else cache_roots('windows')
            require(any(path.resolve()==(r/spec['relative']).resolve() for r in roots), 'Local effect locator changed')
            local.validate_package(path,spec)
    required={m for k in keys if k in downloads['resources'] for m in (downloads['resources'][k]['sdk_model'] or [])}
    require({m['sdk_model'] for m in record['models']}==required, 'Missing SDK model evidence')
    candidates={p.resolve() for p in model_inventory(apps)}
    for model in record['models']:
        p=Path(model['path'])
        require(p.resolve() in candidates and model_matches(model['sdk_model'],p)
                and p.stat().st_size==model['size'] and sha(p)==model['sha256'], 'Prepared model changed')
    return record
