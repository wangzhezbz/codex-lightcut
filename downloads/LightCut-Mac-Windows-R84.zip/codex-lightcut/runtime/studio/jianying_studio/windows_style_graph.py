"""Compose reviewed Windows effect shapes using the user's selected values.

No Mac profile, donor draft, rendering or editor calls. Reuses strict independent
Windows graph verifiers after checking and normalizing only requested values.
"""
from copy import deepcopy
from . import windows_effects as w, windows_filter as f
from .project import style_check, number
from .storage import require


def scopes(style):
    style_check(style)
    require(not style.get('subtitle_shadow'), 'Windows 字幕阴影尚未适配；请求会保留，不会静默关闭')
    return '-'.join(k for k in ('beauty', 'adjustment') if style.get(k, {}).get('enabled'))


def selected_values(style):
    beauty = {r[0]: style.get('beauty', {}).get('values', {}).get(r[0], r[3]) for r in w.BEAUTY}
    adjust = {r[0]: style.get('adjustment', {}).get('values', {}).get(r[0], r[1]) for r in w.ADJUST}
    orange = dict(hue=0, saturation=12, lightness=14)
    orange.update(style.get('adjustment', {}).get('orange_hsl', {}))
    return beauty, adjust, orange


def filter_title(strength):
    return '高清增强 ' + format(strength * 100, '.8g') + '%'


def values(doc, base, style, *, normalize=False):
    scope = scopes(style)
    beauty, adjust, orange = selected_values(style)
    idx = w.index(doc)
    old = w.index(base)
    if 'beauty' in scope:
        for seg, original in zip(doc['tracks'][0]['segments'], base['tracks'][0]['segments']):
            if old[original['material_id']].get('type') != 'video': continue
            refs = seg['extra_material_refs'][len(original['extra_material_refs']):]
            require(len(refs) == len(w.BEAUTY), 'Missing selected beauty nodes')
            for ref, control in zip(refs, w.BEAUTY):
                node = idx[ref]
                requested = beauty[control[0]]
                if normalize: require(node.get('value') == requested, 'Selected beauty value differs: ' + control[0])
                node['value'] = control[3] if normalize else requested
    if 'adjustment' in scope:
        track = doc['tracks'][len(base['tracks'])]
        for seg in track['segments']:
            require(len(seg['extra_material_refs']) == 6, 'Missing selected adjustment nodes')
            for ref, control in zip(seg['extra_material_refs'][:5], w.ADJUST):
                node = idx[ref]
                if normalize: require(node.get('value') == adjust[control[0]], 'Selected adjustment value differs')
                node['value'] = control[1] if normalize else adjust[control[0]]
            node = idx[seg['extra_material_refs'][5]]
            for key, default in (('hue', 0), ('saturation', 12), ('lightness', 14)):
                if normalize: require(node.get(key) == orange[key], 'Selected HSL value differs')
                node[key] = default if normalize else orange[key]


def apply(base, style, bindings, filter_path=None):
    scope = scopes(style)
    result = w.apply(base, scope, bindings) if scope else deepcopy(base)
    values(result, base, style)
    if style.get('filter', {}).get('enabled'):
        result = f.apply(result, filter_path)
        strength = style['filter'].get('strength', .12)
        result['tracks'][-1]['name'] = filter_title(strength)
        idx = w.index(result)
        for seg in result['tracks'][-1]['segments']: idx[seg['material_id']]['value'] = strength
    verify(base, result, style, bindings, filter_path)
    return result


def verify(base, actual, style, bindings, filter_path=None):
    scope = scopes(style)
    middle = deepcopy(actual)
    filter_count = 0
    if style.get('filter', {}).get('enabled'):
        strength = style['filter'].get('strength', .12)
        number(strength, 'Filter strength', 0, 1)
        track = middle['tracks'][-1]
        require(track.get('name') == filter_title(strength), 'Selected filter label differs')
        idx = w.index(middle)
        refs = [s['material_id'] for s in track['segments']]
        require(len(refs) == len(set(refs)), 'Shared filter owner')
        normalized = deepcopy(middle); normal_idx = w.index(normalized)
        normalized['tracks'][-1]['name'] = '高清增强 12%'
        for ref in refs:
            require(idx[ref].get('value') == strength, 'Selected filter strength differs')
            normal_idx[ref]['value'] = .12
        middle['tracks'].pop()
        middle['materials']['effects'] = [n for n in middle['materials']['effects'] if n['id'] not in refs]
        if 'effects' not in base['materials'] and not middle['materials']['effects']: del middle['materials']['effects']
        f.verify(middle, normalized, filter_path)
        filter_count = len(refs)
    values(middle, base, style, normalize=True)
    if scope:
        checked = w.verify(base, middle, scope, bindings)
    else:
        require(middle == base, 'Unrequested timeline mutation')
        checked = {'beauty_nodes': 0, 'adjustment_segments': 0, 'base_preserved': True, 'images_excluded': True}
    # Never classify the new integrated path as accepted because component tests passed.
    return dict(checked, filter_segments=filter_count, selected_values_verified=True,
                whole_pipeline_acceptance='pending-Windows-test')
