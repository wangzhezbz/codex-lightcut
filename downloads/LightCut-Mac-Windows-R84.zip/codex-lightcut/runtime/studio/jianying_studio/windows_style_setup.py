"""Selected Windows effects preflight for an explicit integrated pilot.

The stable setup path remains unchanged. Prepare only requested resources;
filter bytes are downloaded from the reviewed official path on Windows only.
"""
from copy import deepcopy
from pathlib import Path
import uuid
from .storage import load, require, save
from .platforms import host
from .preferences import home_dir, digest
from . import windows_effect_resources as effects, windows_filter_resource as filt
from .windows_style_graph import scopes

SCHEMA = 'lightcut-windows-style-profile/v1'
BASIC_STYLE = {'schema': 'jianying-studio-style/v1', 'name': '基础无效果'}


def cached_filter(root=None, *, allow_download=False, activity=None):
    root = Path(root) if root else home_dir() / 'resources/windows-hd-enhance'
    if root.exists():
        from .onboarding import _safe_directory
        _safe_directory(root)
        candidates = sorted(root.glob('*/resource.json'), key=lambda p: p.stat().st_mtime, reverse=True)[:20]
        for candidate in candidates:
            try: return filt.verify(candidate)
            except (OSError, ValueError, KeyError): pass
    require(allow_download, '缺少已校验的 Windows 高清增强资源；需要准备官方资源')
    if activity is not None: activity['download_attempts'] = 1
    record = filt.fetch(root / uuid.uuid4().hex)
    if activity is not None: activity['downloads'] = 1
    return record


def prepare(style, *, allow_download=False, resource_root=None, managed_resources=False,
            beauty_root=None, ignore_effect_cache=False):
    require(host() == 'windows', 'Windows 联合风格试运行必须在 Windows 上执行')
    from .onboarding import prepare as basic_prepare
    scope = scopes(style)  # Unsupported requests fail BEFORE network or writing.
    report, _ = basic_prepare(style=BASIC_STYLE)
    report.update(style=style['name'], pipeline='windows-style-pilot', production_ready=False,
                  acceptance={'components': 'user-confirmed-on-tested-Windows', 'integrated_pipeline': 'pending-real-machine'})
    if report['status'] != 'ready-for-build': return report, None
    try:
        if managed_resources and scope:
            from . import windows_resource_prepare as resources
            effect_record = resources.prepare(scope, allow_download=allow_download, root=beauty_root,
                                              ignore_effect_cache=ignore_effect_cache)
            report.update(pipeline='windows-selected-resources-preview', resource_preparation=effect_record)
            report['beauty_downloads'] = effect_record['downloads']
            if effect_record['status'] != 'ready-for-build':
                report['status'] = 'needs-attention'
                report['blockers'].extend(effect_record['blockers'])
                return report, None
            bindings = effect_record['bindings']
        else:
            bindings, effect_record = effects.bind(scope) if scope else ({}, None)
        filter_record = cached_filter(resource_root, allow_download=allow_download, activity=report) if style.get('filter', {}).get('enabled') else None
        profile = {'schema': SCHEMA, 'style_sha256': digest(style), 'runtime': report['runtime'],
                   'scope': scope, 'bindings': bindings, 'effects_record': effect_record, 'filter_record': filter_record}
        report['resources'] = (effect_record or {}).get('checks', []) + ([{'resource':'高清增强','status':'matched','source':'official-Windows'}] if filter_record else [])
        report['required_resources'] = report['matched_resources'] = len(report['resources'])
        return report, profile
    except (ValueError, OSError, KeyError) as error:
        report['status'] = 'needs-attention'
        report['blockers'].append({'code':'windows-selected-resource-unavailable','owner':'resource-adapter','message':str(error)})
        return report, None


def verify_profile(profile, style, *, filter_record_path=None):
    require(host() == 'windows', 'Windows 联合风格必须在 Windows 上校验')
    require(profile.get('schema') == SCHEMA and profile.get('style_sha256') == digest(style), 'Windows profile belongs to other choices')
    scope = scopes(style)
    require(profile['scope'] == scope, 'Selected scope changed')
    from .onboarding import runtime_context
    runtime, _ = runtime_context()
    require(profile['runtime'] == runtime, 'Selected Windows runtime changed')
    if scope:
        from . import windows_resource_prepare as resources
        if profile['effects_record'].get('schema') == resources.SCHEMA:
            record = resources.verify(profile['effects_record'])
            require(record['scope'] == scope and record['bindings'] == profile['bindings'], 'Prepared resources belong to other choices')
        else:
            bindings, record = effects.bind(scope)
            require(bindings == profile['bindings'] and record == profile['effects_record'], 'Selected Windows beauty/color resources changed')
    else: require(profile['bindings'] == {} and profile['effects_record'] is None, 'Unrequested effect resources')
    if style.get('filter', {}).get('enabled'):
        require(filter_record_path is not None, 'Missing filter evidence file')
        require(filt.verify(filter_record_path) == profile['filter_record'], 'Selected filter resource changed')
    else: require(profile['filter_record'] is None, 'Unrequested filter resource')
    return profile
