#!/usr/bin/env python3
"""Private Windows R5 regression runner, using isolated QA choices, not user defaults.

Input is an existing PORTABLE sample project, never a live Jianying draft.
Creates two new projects using the normal preference -> deliver -> queue path.
"""
import argparse,json,sys,time
from pathlib import Path
from jianying_studio import preferences as pref,preference_project as pp,delivery,windows_backend
from jianying_studio.project import validate
from jianying_studio.platforms import host
from jianying_studio.storage import load,save,sha,copy_file,require,asset_path


def install_engine(source):
    target=windows_backend.BACKEND
    if target.exists():windows_backend.verify_sources();return
    source=Path(source).resolve(strict=True)
    lock=source/'STUDIO_SOURCE_LOCK.json'
    require(sha(lock)==windows_backend.PIN,'Existing Windows engine source lock differs')
    files=load(lock)['files']
    for relative,expected in files.items():
        p=asset_path(source,relative)
        require(sha(p)==expected,'Existing Windows engine file differs: '+relative)
    for relative in files:copy_file(asset_path(source,relative),target/relative)
    copy_file(lock,target/'STUDIO_SOURCE_LOCK.json')
    windows_backend.verify_sources()


def qa_session(source,project,root,variant):
    kinds=[t['type'] for t in project['tracks']]
    require(kinds==['video','audio','text'],'R5 runner expects the existing three-track portable acceptance sample')
    first=project['tracks'][0]['segments'][0]
    cover_id=first['asset'] if project['assets'][first['asset']]['kind']=='image' else None
    music_ids={s['asset'] for s in project['tracks'][1]['segments']}
    require(len(music_ids)==1,'R5 sample must have one BGM source')
    music_id=next(iter(music_ids));music_path=asset_path(source,project['assets'][music_id]['path'])
    music_clips=project['tracks'][1]['segments']
    frame=round(min(s.get('start_us',0) for s in music_clips)*project['canvas']['fps']/1e6)
    s=pref.start(root)
    choices=pref.recommendations()
    choices['cover']['mode']='image' if cover_id else 'none'
    if cover_id:choices['cover']['asset']=pref.asset(asset_path(source,project['assets'][cover_id]['path']))
    choices['effects']['subtitle_shadow']=False  # Explicit QA scope; never edit the user's saved preference.
    choices['music'].update(mode='file',asset=pref.asset(music_path),gain_db=0,start_frame=frame)
    choices['editing'].update(pace='basic',speech_gain_db=None)
    if variant=='custom':
        choices['effects']['beauty']['enabled']=False
        choices['effects']['filter']['strength']=.2
        choices['effects']['adjustment']['values']['brightness']=.05
        choices['music']['mode']='none'
    s=pref.update(s['session'],s['revision'],choices)
    s=pref.confirm(s['session'],s['revision'],scope='once')
    if cover_id:
        s=pref.cover_review(s['session'],s['revision'],image=choices['cover']['asset']['path'])
        s=pref.cover_review(s['session'],s['revision'],approve=True)
    roles=pp.bindings_template(s['session'],s['revision'],source)
    roles.update(cover_segment=0 if cover_id else None,music_tracks=[1],caption_tracks=[2],
                 editing_applied={'pace':'basic','aspect':'source'})
    return s,roles


def main():
    parser=argparse.ArgumentParser(description='Windows联合风格私人回归，不打开剪映、不使用旧草稿')
    parser.add_argument('--project',required=True,type=Path)
    parser.add_argument('--out',required=True,type=Path)
    parser.add_argument('--engine-from',type=Path)
    parser.add_argument('--register',action='store_true')
    args=parser.parse_args()
    try:
        require(host()=='windows','R5原生回归必须在 Windows 执行')
        source=args.project.resolve(strict=True);out=args.out.resolve()
        require(not out.exists() and not out.is_relative_to(source),'Use a new result directory outside the sample')
        project=load(source/'project.json');validate(project,source)
        if args.engine_from:install_engine(args.engine_from)
        else:windows_backend.verify_sources()
        out.mkdir(parents=True)
        report={'schema':'lightcut-r5-pilot/v1','status':'running','cases':{},'ui_actions':0,
          'source_project_json_sha256':sha(source/'project.json'),'source_draft_required':False,
          'qa_preferences':'isolated synthetic test choices; not real user defaults',
          'subtitle_shadow':'explicitly excluded from QA scope; unsupported requests remain blocked',
          'registration_requested':args.register,'visual_acceptance':'pending-user'}
        save(out/'request.json',report)
        for name in ('natural','custom'):
            t=time.perf_counter()
            s,roles=qa_session(source,project,out/name/'qa-preferences',name)
            save(out/name/'roles.json',roles)
            result=delivery.deliver(source,out/name/'delivery',session=s['session'],revision=s['revision'],bindings=roles,
                                    windows_style_pilot=True,register=args.register)
            report['cases'][name]={'elapsed_seconds':time.perf_counter()-t,'result':result}
            save(out/'progress.json',report,replace=(out/'progress.json').exists())
            if result['status']=='needs-attention':
                report['status']='needs-attention';save(out/'result.json',report);print(json.dumps(report,ensure_ascii=False,indent=2));return 2
        require(sha(source/'project.json')==report['source_project_json_sha256'],'Original portable project changed')
        validate(project,source)
        report['status']='registration-queued' if args.register else 'built-offline'
        report['source_unchanged']=True
        save(out/'result.json',report);print(json.dumps(report,ensure_ascii=False,indent=2));return 0
    except (ValueError,OSError,KeyError,RuntimeError) as error:
        print(json.dumps({'status':'failed','error':str(error),'ui_actions':0},ensure_ascii=False),file=sys.stderr);return 2

if __name__=='__main__':raise SystemExit(main())
