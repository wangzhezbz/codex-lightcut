"""Windows resource cold-cache regression, without deleting caches or editing drafts."""
import argparse,json,os,platform,sys,time,zipfile
from pathlib import Path
from jianying_studio.platforms import host
from jianying_studio.storage import load,save,sha,require
from jianying_studio import windows_resource_prepare as resources
from jianying_studio.windows_style_setup import cached_filter


def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--engine-from',type=Path)
    args=p.parse_args();require(host()=='windows','R6 resource regression must run on Windows')
    out=args.out.resolve();require(not out.exists(),'Use a new result directory')
    out.mkdir(parents=True)
    os.environ['LIGHTCUT_DATA_HOME']=str(out/'private-data')
    result={'schema':'lightcut-r6-resource-pilot/v1','status':'running','python':platform.python_version(),
            'host':host(),'ui_actions':0,'drafts_written':False,'existing_cache_deleted':False,
            'scenario':'Ignore existing effect packages; retain installed application and existing model files. Not a clean OS install.',
            'source_files':{n:sha(Path(__file__).parent/'jianying_studio'/n) for n in ('jobs.py','windows_resource_prepare.py','windows_style_setup.py','release.py')}}
    start=time.perf_counter()
    try:
        if args.engine_from:
            from attach_engine import attach
            result['engine']=attach(args.engine_from)
        cold=resources.prepare('beauty-adjustment',allow_download=True,ignore_effect_cache=True)
        save(out/'cold-resources.json',cold)
        warm=resources.prepare('beauty-adjustment',allow_download=False,ignore_effect_cache=True)
        save(out/'warm-resources.json',warm)
        complete=set(cold['bindings'])=={'adjust','eye','face','skin','small','smooth','teeth','white'}
        result.update(cold_status=cold['status'],warm_status=warm['status'],cold_downloads=cold['downloads'],warm_downloads=warm['downloads'],
                      bindings_complete=complete, private_bindings_reused=complete and cold['bindings']==warm['bindings'],
                      missing_model_mappings=warm['missing_model_mappings'])
        runtime,apps=resources.runtime_context()
        inventory=resources.model_inventory(apps)
        # Names and hashes only, not proprietary model contents or account data.
        save(out/'model-inventory.json',{'files':[{'name':m.name,'parent':m.parent.name,'size':m.stat().st_size,'sha256':sha(m)} for m in inventory]})
        filter_activity={};filt=cached_filter(allow_download=True,activity=filter_activity)
        save(out/'filter-resource.json',filt)
        result['filter_downloads']=filter_activity.get('downloads',0)
        if warm['status']=='ready-for-build':resources.verify(warm)
        result['status']='resource-check-passed' if cold['status']==warm['status']=='ready-for-build' and warm['downloads']==0 and result['private_bindings_reused'] else 'needs-attention'
        result['native_build_tested']=False
    except Exception as error:
        result.update(status='needs-attention',error_type=type(error).__name__,message=str(error))
    result['seconds']=time.perf_counter()-start;save(out/'result.json',result)
    files=[f for f in out.iterdir() if f.is_file() and f.suffix=='.json']
    save(out/'RESULTS_SHA256.json',{'files':{f.name:{'size':f.stat().st_size,'sha256':sha(f)} for f in files}})
    archive=out/'LightCut-R6-Windows-Resources-Results.zip'
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for file in [*files,out/'RESULTS_SHA256.json']:z.write(file,file.name)
    print(json.dumps({'status':result['status'],'return_zip':str(archive),'ui_actions':0},ensure_ascii=False))
    return 0 if result['status']=='resource-check-passed' else 2


if __name__=='__main__':raise SystemExit(main())
