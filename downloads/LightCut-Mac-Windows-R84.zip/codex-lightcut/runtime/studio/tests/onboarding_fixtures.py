from pathlib import Path
import uuid
from jianying_studio import project
from jianying_studio.storage import load, save, sha
HERE = Path(__file__).resolve().parent

def fixture():
    root = HERE / 'artifacts' / uuid.uuid4().hex
    (root / 'assets').mkdir(parents=True)
    for name in ('video.mp4', 'audio.wav', 'image.png'):
        (root / 'assets' / name).write_bytes(('test-' + name).encode())
    assets = {kind: {'path': 'assets/' + name, 'sha256': sha(root / 'assets' / name),
                     'size': (root / 'assets' / name).stat().st_size, 'kind': kind}
              for kind, name in [('video', 'video.mp4'), ('audio', 'audio.wav'), ('image', 'image.png')]}
    p = {'schema': project.SCHEMA, 'name': '兼容测试', 'canvas': {'width': 1080, 'height': 1920, 'fps': 30},
         'assets': assets, 'style': load(HERE.parent / 'presets/基础无效果.json'), 'tracks': [
             {'type': 'video', 'name': '主视频', 'segments': [{'asset': 'video', 'start_us': 0, 'duration_us': 4000000}]},
             {'type': 'audio', 'name': '音乐', 'segments': [{'asset': 'audio', 'start_us': 0, 'duration_us': 4000000}]},
             {'type': 'text', 'name': '字幕', 'segments': [{'text': '你好 Windows 与 Mac', 'start_us': 500000, 'duration_us': 1000000}]}]}
    save(root / 'project.json', p)
    return root, p

