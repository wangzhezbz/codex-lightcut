from copy import deepcopy
from pathlib import Path
import sys
import unittest
import uuid
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from jianying_studio.caption_timing import map_captions, expand_plan
from jianying_studio import project
from jianying_studio.storage import load, save


def clip(a, duration, start, speed=1, source='source.mp4'):
    return dict(source=source, source_start_us=a, source_duration_us=round(duration*speed),
                start_us=start, duration_us=duration, speed=speed)


def cue(a, b, text='你好', source='source.mp4'):
    return dict(source=source, start_us=a, duration_us=b-a, text=text)


class CaptionTimingTests(unittest.TestCase):
    def test_cover_cut_and_speed_use_absolute_endpoints(self):
        clips=[clip(0,33333,0,source='cover.jpg'),clip(1000000,1000000,33333,1.05),
               clip(4000000,2000000,1033333,1.05)]
        out,report=map_captions(clips,[cue(1525000,2050000),cue(4525000,5050000)])
        self.assertEqual([(x['start_us'],x['duration_us']) for x in out],[(533333,500000),(1533333,500000)])
        self.assertFalse(report['speech_alignment_verified'])

    def test_deleted_sentence_removed_not_shifted_to_next_clip(self):
        out,r=map_captions([clip(0,1000000,0),clip(3000000,1000000,1000000)],
                           [cue(1000000,3000000,'删除'),cue(3100000,3500000,'保留')])
        self.assertEqual([x['text'] for x in out],['保留'])
        self.assertEqual(out[0]['start_us'],1100000)
        self.assertEqual(r['removed_cues'],[0])

    def test_cross_cut_sentence_never_duplicated(self):
        with self.assertRaisesRegex(ValueError,'跨剪切边界'):
            map_captions([clip(0,1000000,0),clip(2000000,1000000,1000000)],
                         [cue(500000,2500000,'前半句后半句')])

    def test_partial_word_at_edge_requires_alignment(self):
        with self.assertRaisesRegex(ValueError,'跨剪切边界'):
            map_captions([clip(100,100,0)],[cue(50,150)])

    def test_word_cues_preserve_only_retained_text(self):
        out,_=map_captions([clip(0,100,0),clip(200,100,100)],
                          [cue(0,100,'前'),cue(100,200,'重复'),cue(200,300,'后')])
        self.assertEqual([(x['text'],x['start_us']) for x in out],[('前',0),('后',100)])

    def test_reordered_and_repeated_footage(self):
        out,_=map_captions([clip(200,100,0),clip(0,100,100),clip(200,100,200)],
                          [cue(0,100,'一'),cue(200,300,'二')])
        self.assertEqual([x['text'] for x in out],['二','一','二'])

    def test_multiple_sources_and_windows_paths(self):
        source=r'C:\Videos\口播.mp4'
        out,_=map_captions([clip(0,100,0,source=source)],[cue(10,90,source=source)])
        self.assertEqual(out[0]['start_us'],10)
        with self.assertRaisesRegex(ValueError,'does not match'):
            map_captions([clip(0,100,0)],[cue(10,90,source='other.mp4')])

    def test_overlap_and_invalid_timing_rejected(self):
        with self.assertRaisesRegex(ValueError,'overlap'):
            map_captions([clip(0,100,0)],[cue(0,70),cue(60,100)])
        with self.assertRaisesRegex(ValueError,'mismatch'):
            map_captions([dict(clip(0,100,0),speed=2)],[cue(0,70)])

    def test_input_unchanged_and_legacy_plan_unchanged(self):
        clips=[clip(0,100,0)];cues=[cue(0,100)];before=deepcopy((clips,cues))
        map_captions(clips,cues);self.assertEqual((clips,cues),before)
        plan={'tracks':[{'type':'video','segments':clips}]}
        self.assertEqual(expand_plan(plan),(plan,None))

    def test_import_plan_consumes_source_captions_before_both_backends(self):
        root=Path(__file__).parent/'artifacts'/('caption-'+uuid.uuid4().hex)
        root.mkdir(parents=True)
        source=root/'source.mp4';source.write_bytes(b'fixture')
        plan={'schema':'jy14-headless-plan/v1','name':'字幕回归','canvas':{'width':1080,'height':1920,'fps':30},
              'tracks':[{'type':'video','segments':[clip(1000,1000,0,source=str(source))]}],
              'source_captions':{'segments':[cue(1100,1500,source=str(source))]}}
        save(root/'plan.json',plan)
        style=load(Path(__file__).parents[1]/'presets/基础无效果.json')
        p=project.import_plan(root/'plan.json',root/'project',style)
        self.assertEqual(p['tracks'][1]['segments'][0]['start_us'],100)
        native=project.compile_plan(p,root/'project')
        self.assertNotIn('source_captions',native)
        self.assertTrue((root/'project/caption-timing.json').exists())

if __name__=='__main__':unittest.main()
