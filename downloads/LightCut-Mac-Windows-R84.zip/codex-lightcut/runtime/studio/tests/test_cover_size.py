import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from jianying_studio import cover_size, preferences, ending

class CoverSizeTests(unittest.TestCase):
    def test_actual_asset_dimensions_and_wrong_video_aspect(self):
        root=Path(tempfile.mkdtemp(prefix='lightcut-cover-size-'))
        for width,height in ((1080,1464),(1080,1920)):
            p=root/f'{width}-{height}.png';p.write_bytes(ending.black_png(width,height))
            if height==1464:self.assertEqual(cover_size.verify(p,{'width':1080,'height':1464}),{'width':1080,'height':1464})
            else:
                with self.assertRaisesRegex(ValueError,'封面尺寸不符'):cover_size.verify(p,{'width':1080,'height':1464})

    def test_invalid_and_legacy_sizes(self):
        for size in ({'width':True,'height':1464},{'width':1080},{'width':0,'height':1464}):
            with self.assertRaises(ValueError):cover_size.validate_size(size)
        with patch.object(cover_size.subprocess,'run') as run:
            cover_size.verify('legacy.png',None);run.assert_not_called()

    def test_size_choice_persisted_and_enforced_at_review(self):
        root=Path(tempfile.mkdtemp(prefix='lightcut-cover-choice-'))
        state=preferences.start(root/'preferences')
        state=preferences.update(state['session'],state['revision'],{'cover':{'size':{'width':1080,'height':1464}}},recommended=['cover'])
        with patch.object(cover_size,'verify',side_effect=ValueError('封面尺寸不符')):
            p=root/'wrong.png';p.write_bytes(ending.black_png(1080,1920))
            with self.assertRaisesRegex(ValueError,'封面尺寸不符'):
                preferences.cover_review(state['session'],state['revision'],image=p,title='标题')
        self.assertEqual(preferences.read(state['session'])['choices']['cover']['size'],{'width':1080,'height':1464})
