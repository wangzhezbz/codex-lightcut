from copy import deepcopy
from pathlib import Path
import sys
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from jianying_studio import ending, operations, preferences, preference_project
from jianying_studio.storage import load, save
from jianying_studio.project import validate
from onboarding_fixtures import fixture


class EndingTests(unittest.TestCase):
    def test_default_fade_is_editable_preserves_audio_and_finishes_on_last_frame(self):
        root,p=fixture();before=deepcopy(p)
        q=ending.apply(p,root,300)
        self.assertEqual(p,before)
        self.assertEqual(q['tracks'][:-1],p['tracks'])
        self.assertEqual(validate(q,root)['duration_us'],4000000)
        s=q['tracks'][-1]['segments'][0]
        self.assertEqual(s['start_us'],3700000)
        self.assertEqual(s['duration_us'],300000)
        self.assertEqual(s['keyframes']['opacity'],[{'at_us':0,'value':0},{'at_us':266667,'value':1}])
        self.assertEqual(s['volume'],0)

    def test_reapply_and_change_duration_does_not_stack_two_endings(self):
        root,p=fixture();q=ending.apply(p,root,300)
        self.assertEqual(ending.apply(q,root,300),q)
        revised=ending.apply(q,root,600)
        self.assertEqual(len(ending.fade_tracks(revised)),1)
        self.assertEqual(revised['tracks'][-1]['segments'][0]['duration_us'],600000)
        self.assertEqual(revised['tracks'][:-1],p['tracks'])

    def test_zero_disables_recognized_ending_and_preserves_other_overlays(self):
        root,p=fixture();p['tracks'].append({'type':'video','name':'用户贴图','segments':[
            {'asset':'image','start_us':3500000,'duration_us':500000}]})
        q=ending.apply(ending.apply(p,root,300),root,0)
        self.assertEqual(q['tracks'],p['tracks'])

    def test_legacy_mac_ending_is_replaced_once(self):
        root,p=fixture();old=operations.add_end_fade(p,'image')
        q=ending.apply(old,root,300)
        self.assertEqual(len(q['tracks']),len(old['tracks']))
        self.assertEqual(q['tracks'][-1]['name'],ending.NAME)

    def test_all_supported_frame_rates_and_short_clip(self):
        for fps in (24,25,30,50,60):
            root,p=fixture();p['canvas']['fps']=fps
            q=ending.apply(p,root,300);s=q['tracks'][-1]['segments'][0]
            self.assertGreater(s['keyframes']['opacity'][-1]['at_us'],0)
            self.assertAlmostEqual(s['keyframes']['opacity'][-1]['at_us']+1e6/fps,s['duration_us'],delta=1)
        root,p=fixture();p['tracks']=p['tracks'][:1];p['tracks'][0]['segments'][0]['duration_us']=66667
        q=ending.apply(p,root,300)
        self.assertEqual(q['tracks'][-1]['segments'][0]['duration_us'],66667)

    def test_native_missing_or_changed_alpha_is_rejected(self):
        root,p=fixture();q=ending.apply(p,root,300);s=q['tracks'][-1]['segments'][0]
        timeline={'tracks':[{} for _ in q['tracks']]}
        timeline['tracks'][-1]={'type':'video','segments':[{'volume':0,'clip':{'alpha':0},
            'target_timerange':{'start':s['start_us'],'duration':s['duration_us']},
            'common_keyframes':[{'property_type':'KFTypeAlpha','keyframe_list':[
                {'time_offset':p['at_us'],'values':[p['value']]} for p in s['keyframes']['opacity']]}]}]}
        self.assertEqual(ending.verify_native(q,timeline)['tracks'],1)
        broken=deepcopy(timeline);broken['tracks'][-1]['segments'][0]['common_keyframes']=[]
        with self.assertRaisesRegex(ValueError,'关键帧缺失'):ending.verify_native(q,broken)
        broken=deepcopy(timeline);broken['tracks'][-1]['segments'][0]['common_keyframes'][0]['keyframe_list'][-1]['values']=[.8]
        with self.assertRaisesRegex(ValueError,'关键帧改变'):ending.verify_native(q,broken)

    def test_confirmed_preferences_wire_fade_and_preserve_legacy_sessions(self):
        root,p=fixture();s=preferences.start(root/'prefs')
        s=preferences.update(s['session'],s['revision'],{'cover':{'mode':'none'}},recommended=preferences.GROUPS)
        s=preferences.confirm(s['session'],s['revision'],scope='once')
        roles=preference_project.bindings_template(s['session'],s['revision'],root)
        roles.update(music_tracks=[1],caption_tracks=[2],editing_applied={'pace':'natural','aspect':'source'})
        out=root.parent/(root.name+'-ending')
        result=preference_project.apply(s['session'],s['revision'],root,out,roles)
        q=load(out/'project.json');self.assertEqual(len(ending.fade_tracks(q)),1)
        self.assertEqual(result['choices']['editing']['end_fade_ms'],300)
        # Pre-R7.1 serialized choices remain valid and retain their old behavior.
        state=preferences.read(s['session']);state['choices']['editing'].pop('end_fade_ms')
        state['confirmed_digest']=preferences.digest(state['choices'])
        save(Path(s['session'])/f"r{state['revision']:08d}.json",state,replace=True)
        roles=preference_project.bindings_template(s['session'],s['revision'],root)
        roles.update(music_tracks=[1],caption_tracks=[2],editing_applied={'pace':'natural','aspect':'source'})
        oldout=root.parent/(root.name+'-legacy')
        preference_project.apply(s['session'],s['revision'],root,oldout,roles)
        self.assertFalse(ending.fade_tracks(load(oldout/'project.json')))

    def test_fade_value_rejects_invalid_types_and_range(self):
        for value in (-1,3001,True,.3):
            choice=preferences.recommendations()['editing'];choice['end_fade_ms']=value
            with self.assertRaises(ValueError):preferences.validate_group('editing',choice)


if __name__=='__main__':unittest.main()
