import struct
import unittest
from pathlib import Path
from uuid import uuid4
from jianying_studio import preferences as p
from jianying_studio.font_identity import names, verify


class FontIdentityTests(unittest.TestCase):
    def font(self, name):
        root = Path(__file__).parent / 'artifacts' / ('font-' + uuid4().hex)
        root.mkdir(parents=True)
        raw = name.encode('utf-16-be')
        table = struct.pack('>3H', 0, 1, 18) + struct.pack('>6H', 3, 1, 0x804, 1, len(raw), 0) + raw
        # A minimal SFNT name-table fixture, not a renderable font.
        font = root / 'misleading-name.ttf'
        font.write_bytes(struct.pack('>I4H', 0x10000, 1, 0, 0, 0) + struct.pack('>4s3I', b'name', 0, 28, len(table)) + table)
        return font

    def test_real_internal_name_is_used(self):
        font = self.font('凌丝体')
        self.assertEqual(names(font), ['凌丝体'])
        verify({'enabled': True, 'font_name': '凌丝体', 'font': p.asset(font)})

    def test_system_substitution_rejected(self):
        with self.assertRaisesRegex(ValueError, '不匹配'):
            verify({'enabled': True, 'font_name': '凌丝体', 'font': p.asset(self.font('Source Han Sans CN Medium'))})

    def test_missing_font_blocks_delivery(self):
        with self.assertRaisesRegex(ValueError, '缺少指定字体'):
            verify(p.recommendations()['editing']['captions'])

    def test_explicit_other_font_and_disabled_captions(self):
        verify({'enabled': True, 'font_name': 'Other', 'font': p.asset(self.font('Other'))})
        verify({'enabled': False, 'font_name': '凌丝体'})
        verify({'enabled': True, 'font_name': None})

    def test_execution_enforces_font(self):
        root = self.font('Other').parent
        s = p.start(root / 'preferences')
        choices = p.recommendations()
        choices['cover']['mode'] = 'none'
        s = p.update(s['session'], s['revision'], choices)
        s = p.confirm(s['session'], s['revision'], scope='once')
        with self.assertRaisesRegex(ValueError, '缺少指定字体'):
            p.execution(s['session'], s['revision'])

if __name__ == '__main__': unittest.main()
