from copy import deepcopy
import sys
from pathlib import Path
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from jianying_studio import gain_bridge, project
from test_portable import fixture

class SpeechGainTests(unittest.TestCase):
    def test_static_native_gain_and_bounds(self):
        root, p = fixture()
        s = p['tracks'][0]['segments'][0]
        s['volume'] = 5.6234130859375
        project.validate(p, root)
        s['volume'] = 5.624
        with self.assertRaises(ValueError): project.validate(p, root)
        s['volume'] = 1
        p['tracks'][1]['segments'][0]['volume'] = 5.6234130859375
        with self.assertRaises(ValueError): project.validate(p, root)

    def test_stage_restore_verify_and_timing_guard(self):
        root, p = fixture()
        p['tracks'][0]['segments'][0]['volume'] = 5.6234130859375
        plan = project.compile_plan(p, root)
        frozen = deepcopy(plan)
        base = gain_bridge.stage(plan)
        self.assertEqual(plan, frozen)
        self.assertEqual(base['tracks'][0]['segments'][0]['volume'], 4)
        native = {'tracks': [{'type': 'video', 'segments': [{'volume': 4,
                  'target_timerange': {'start': 0, 'duration': 4000000},
                  'source_timerange': {'start': 0, 'duration': 4000000}}]}]}
        with self.assertRaises(ValueError): gain_bridge.apply_or_verify(native, plan)
        result = gain_bridge.apply_or_verify(native, plan, apply=True)
        self.assertEqual(result, gain_bridge.apply_or_verify(native, plan))
        native['tracks'][0]['segments'][0]['source_timerange']['start'] = 100
        with self.assertRaises(ValueError): gain_bridge.apply_or_verify(native, plan)

    def test_automated_gain_stays_bounded(self):
        root, p = fixture()
        p['tracks'][0]['segments'][0]['keyframes'] = {'volume': [
            {'at_us': 0, 'value': 1}, {'at_us': 4000000, 'value': 5.6234130859375}]}
        with self.assertRaises(ValueError): project.validate(p, root)
