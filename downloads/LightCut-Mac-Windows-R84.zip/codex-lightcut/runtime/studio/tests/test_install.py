"""Installer failure/re-entry contracts; network and processes are explicit fakes."""
import argparse
from contextlib import nullcontext
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest
import uuid
from unittest.mock import Mock, patch

STUDIO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(STUDIO))
PLUGIN = next(p for p in (STUDIO.parent / 'plugins/codex-lightcut', STUDIO.parent.parent)
              if (p / 'install/bootstrap.py').is_file())
spec = importlib.util.spec_from_file_location('lightcut_install_test_module', PLUGIN / 'install/bootstrap.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
from jianying_studio import local_asr
import attach_engine


class Response(io.BytesIO):
    def __init__(self, data, status=200, headers=None):
        super().__init__(data); self.status=status; self.headers=headers or {}
    def geturl(self): return 'https://example.test/asset'


class InstallerTests(unittest.TestCase):
    def root(self):
        p=STUDIO/'tests/artifacts'/('install-'+uuid.uuid4().hex)/'中文 space'
        p.mkdir(parents=True); return p

    def item(self, data=b'valid-asset'):
        return {'url':'https://example.test/asset','size':len(data),'sha256':hashlib.sha256(data).hexdigest()}

    def test_checked_cache_makes_no_network_request(self):
        p=self.root()/'asset';p.write_bytes(b'valid-asset'); net=Mock()
        self.assertEqual(b.download(self.item(),p,net),'reused');net.assert_not_called()

    def test_interrupted_transfer_resumes_correct_range(self):
        p=self.root()/'asset';p.with_name('asset.part').write_bytes(b'valid')
        net=Mock(return_value=Response(b'-asset',206,{'Content-Range':'bytes 5-10/11'}))
        self.assertEqual(b.download(self.item(),p,net),'resumed')
        self.assertEqual(net.call_args.args[0].get_header('Range'),'bytes=5-')
        self.assertEqual(p.read_bytes(),b'valid-asset')

    def test_server_ignoring_range_restarts_without_duplicate_bytes(self):
        p=self.root()/'asset';p.with_name('asset.part').write_bytes(b'valid')
        self.assertEqual(b.download(self.item(),p,lambda *a,**k:Response(b'valid-asset')),'downloaded')
        self.assertEqual(p.read_bytes(),b'valid-asset')

    def test_complete_partial_is_verified_without_network(self):
        p=self.root()/'asset';p.with_name('asset.part').write_bytes(b'valid-asset');net=Mock()
        self.assertEqual(b.download(self.item(),p,net),'resumed');net.assert_not_called()

    def test_checksum_failure_never_publishes_and_preserves_download(self):
        p=self.root()/'asset'
        with self.assertRaisesRegex(ValueError,'未完成'):
            b.download(self.item(),p,lambda *a,**k:Response(b'invaliddata'))
        self.assertFalse(p.exists());self.assertTrue(list(p.parent.glob('asset.part*')))

    def test_tampered_installed_binary_is_preserved_and_repaired(self):
        p=self.root()/'asset';p.write_bytes(b'old-bad')
        b.download(self.item(),p,lambda *a,**k:Response(b'valid-asset'))
        self.assertEqual(p.read_bytes(),b'valid-asset')
        self.assertEqual(next(p.parent.glob('asset.invalid-*')).read_bytes(),b'old-bad')

    def test_wrong_content_range_rejected(self):
        p=self.root()/'asset';p.with_name('asset.part').write_bytes(b'valid')
        with self.assertRaisesRegex(ValueError,'续传范围'):
            b.download(self.item(),p,lambda *a,**k:Response(b'-asset',206,{'Content-Range':'bytes 4-10/11'}))
        self.assertFalse(p.exists())

    def test_install_lock_releases_after_exception(self):
        root=self.root()
        with self.assertRaisesRegex(RuntimeError,'fixture'):
            with b.installation_lock(root): raise RuntimeError('fixture')
        with b.installation_lock(root): pass
        self.assertTrue((root/'install.lock').is_file())

    def test_missing_engine_cannot_be_reported_as_ready(self):
        root=self.root(); runtime=root/'package/runtime';(runtime/'studio').mkdir(parents=True)
        def fake_run(argv, log, **kwargs):
            if str(argv[1]) == 'venv':
                envdir=Path(argv[-1]);(envdir/'bin').mkdir(parents=True);(envdir/'bin/python').write_bytes(b'fake')
            return 'fake-version'
        def fake_download(item, path):
            Path(path).parent.mkdir(parents=True,exist_ok=True);Path(path).write_bytes(b'fake');return 'fake-download'
        native=subprocess.CompletedProcess([],0,b'{"status":"ready-for-build","blockers":[]}',b'')
        args=argparse.Namespace(uv='fake-uv',with_asr=False,engine_from=None)
        # The shim uses POSIX layout in this fixture; Windows has its real test entry.
        with patch.object(b,'home',return_value=root), patch.object(b,'platform_key',return_value='darwin-arm64'), \
             patch.object(b.sys,'platform','darwin'), patch.object(b,'runtime_root',return_value=runtime), \
             patch.object(b,'installation_lock',return_value=nullcontext()), \
             patch.object(b,'run',side_effect=fake_run),patch.object(b,'download',side_effect=fake_download), \
             patch.object(b.subprocess,'run',return_value=native):
            result=b.prepare(args)
        self.assertEqual(result['status'],'needs-attention')
        self.assertTrue(result['environment_ready']);self.assertFalse(result['native_ready'])
        self.assertEqual(result['blockers'][0]['code'],'native-engine-missing')
        self.assertTrue((root/'environment/runtime.json').is_file())

    def test_model_manifest_covers_required_files_and_pins(self):
        lock=b.read(PLUGIN/'install/dependencies.json')
        self.assertEqual(set(lock['platforms']),{'darwin-arm64','darwin-x86_64','win32-amd64'})
        self.assertEqual(set(lock['asr_model']['files']),{'config.json','model.bin','tokenizer.json','vocabulary.txt'})
        for item in lock['asr_model']['files'].values():
            self.assertIn(lock['asr_model']['revision'],item['url']);self.assertEqual(len(item['sha256']),64)

    def test_asr_repetition_is_review_not_automatic_deletion(self):
        segments=[{'start':0,'end':1,'text':'这是一段重复语音需要复核'},
                  {'start':1,'end':2,'text':'这是一段重复语音需要复核'}]
        self.assertEqual(local_asr.review_flags(segments)[0]['code'],'repeated-phrase-review')
        self.assertEqual(len(segments),2)

    def test_asr_missing_model_is_actionable_without_network(self):
        root=self.root();source=root/'source.wav';source.write_bytes(b'test')
        with patch.dict(os.environ,{},clear=True),self.assertRaisesRegex(ValueError,'with-asr'):
            local_asr.transcribe(source,root/'result')
        self.assertFalse((root/'result').exists())

    def engine_fixture(self):
        root=self.root();source=root/'source';source.mkdir()
        (source/'one.py').write_bytes(b'one');(source/'two.py').write_bytes(b'two')
        lock={'files':{p.name:b.digest(p) for p in source.iterdir()}}
        studio=root/'installed/studio';(studio/'resources').mkdir(parents=True)
        descriptor=studio/'resources/mac-runtime-source-lock.json';b.write(descriptor,lock)
        return source,studio,descriptor,root/'installed/upstream/jianying-headless'

    def test_partial_engine_copy_resumes_without_replacing_valid_files(self):
        source,studio,descriptor,target=self.engine_fixture();target.mkdir(parents=True)
        (target/'one.py').write_bytes(b'one');before=(target/'one.py').stat().st_mtime_ns
        with patch.object(attach_engine,'__file__',str(studio/'attach_engine.py')), \
             patch.object(attach_engine,'host',return_value='macos'),patch.object(attach_engine,'MAC_PIN',b.digest(descriptor)):
            result=attach_engine.attach(source)
            self.assertEqual(result['status'],'resumed-existing-reviewed-engine')
            self.assertEqual(result['copied_files'],1)
            self.assertEqual(attach_engine.attach(source)['status'],'already-attached')
        self.assertEqual((target/'one.py').stat().st_mtime_ns,before)

    def test_changed_engine_is_not_overwritten(self):
        source,studio,descriptor,target=self.engine_fixture();target.mkdir(parents=True)
        (target/'one.py').write_bytes(b'manual-change')
        with patch.object(attach_engine,'__file__',str(studio/'attach_engine.py')), \
             patch.object(attach_engine,'host',return_value='macos'),patch.object(attach_engine,'MAC_PIN',b.digest(descriptor)), \
             self.assertRaisesRegex(ValueError,'refusing overwrite'):
            attach_engine.attach(source)
        self.assertEqual((target/'one.py').read_bytes(),b'manual-change')

    def test_engine_receipt_reuses_only_matching_platform_and_explicit_overrides(self):
        root=self.root();runtime=root/'new-program';environment=root/'environment'
        source=root/'old-program/upstream/jianying-headless';source.mkdir(parents=True)
        b.write(environment/'engine-source.json',{'schema':'lightcut-engine-source/v1','platform':'darwin-arm64','source':str(source.absolute())})
        actual,kind=b.engine_source(None,runtime,environment,'darwin-arm64')
        self.assertEqual(actual,source.absolute());self.assertEqual(kind,'previous-verified-install')
        with self.assertRaisesRegex(ValueError,'平台不匹配'): b.engine_source(None,runtime,environment,'win32-amd64')
        explicit=root/'explicit'
        self.assertEqual(b.engine_source(explicit,runtime,environment,'win32-amd64')[1],'explicit')
        installed=runtime/'upstream/jianying-headless';installed.mkdir(parents=True)
        self.assertEqual(b.engine_source(None,runtime,environment,'darwin-arm64'),(installed,'current-package'))

    def test_engine_receipt_rejects_relative_source_and_never_searches_drives(self):
        root=self.root();runtime=root/'new';environment=root/'env'
        self.assertEqual(b.engine_source(None,runtime,environment,'win32-amd64')[1],'missing')
        b.write(environment/'engine-source.json',{'schema':'lightcut-engine-source/v1','platform':'win32-amd64','source':'../old'})
        with self.assertRaisesRegex(ValueError,'记录无效'): b.engine_source(None,runtime,environment,'win32-amd64')

    @unittest.skipUnless(sys.platform == 'win32', 'Requires actual Windows PowerShell 5.1')
    def test_windows_launcher_module_resolution_and_stderr_logging(self):
        shell=Path(os.environ['SystemRoot'])/'System32/WindowsPowerShell/v1.0/powershell.exe'
        result=subprocess.run([str(shell),'-NoLogo','-NoProfile','-ExecutionPolicy','Bypass',
            '-File',str(PLUGIN/'install/test-windows-bootstrap.ps1'),
            '-Python',sys.executable,'-TestRoot',str(self.root())],
            stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60,
            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        self.assertEqual(result.returncode,0,result.stderr.decode('utf-8',errors='replace'))
        self.assertIn(b'WINDOWS_BOOTSTRAP_REGRESSION_PASSED',result.stdout)


if __name__=='__main__':unittest.main()
