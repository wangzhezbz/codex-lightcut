from pathlib import Path
from contextlib import contextmanager
import errno
import os
import subprocess
import sys
import unittest
from unittest.mock import Mock, patch
import uuid

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from jianying_studio.jobs import work, _publication_lock
from jianying_studio.storage import load, save


class PublicationJobTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(__file__).parent / 'artifacts' / ('job-' + uuid.uuid4().hex)
        self.root.mkdir(parents=True)
        self.backend = Mock()
        self.backend.publish.return_value = {'status': 'created'}
        for target, value in [('jianying_studio.native_backend.current', self.backend),
                              ('jianying_studio.jobs.process_pids', []),
                              ('jianying_studio.jobs._lock_path', self.root/'shared.lock')]:
            p = patch(target, return_value=value); p.start(); self.addCleanup(p.stop)
        p = patch('jianying_studio.jobs.background_priority');p.start();self.addCleanup(p.stop)

    def job(self):
        root = self.root / ('queue-' + uuid.uuid4().hex);root.mkdir()
        save(root / 'request.json', {'build': str(root / 'fake-build'), 'timeout_seconds': 60})
        save(root / 'state.json', {'status': 'queued'})
        return root

    def test_cancelled_wait_never_publishes(self):
        root = self.job(); save(root / 'cancel.request', {'cancel': True})
        with patch('jianying_studio.jobs.process_pids', return_value=[123]): result = work(root)
        self.assertEqual(result['status'], 'cancelled'); self.backend.publish.assert_not_called()

    def test_changed_build_stops_before_registration(self):
        root = self.job(); self.backend.verify.side_effect = ValueError('Draft files changed')
        with self.assertRaises(ValueError): work(root)
        self.backend.publish.assert_not_called(); self.assertEqual(load(root / 'state.json')['status'], 'failed')

    def test_closed_editor_commits_once(self):
        self.assertEqual(work(self.job())['status'], 'registered'); self.backend.publish.assert_called_once()

    def test_reopened_editor_not_reported_as_success(self):
        self.backend.publish.return_value = {'status':'waiting-for-editor-to-close'}
        self.assertEqual(work(self.job())['status'], 'deferred-editor-reopened')

    @contextmanager
    def held_slot(self):
        yield lambda: False

    def test_busy_slot_waits_then_publishes_once(self):
        root = self.job()
        lock = _publication_lock(); acquire = lock.__enter__(); self.assertTrue(acquire())
        released = False
        def release(_):
            nonlocal released
            self.assertEqual(load(root/'state.json')['status'], 'waiting-for-publication-slot')
            self.assertFalse((root/'audit').exists());self.backend.publish.assert_not_called()
            lock.__exit__(None,None,None);released = True
        try:
            with patch('jianying_studio.jobs.time.sleep', side_effect=release): result=work(root)
        finally:
            if not released: lock.__exit__(None,None,None)
        self.assertEqual(result['status'],'registered');self.backend.publish.assert_called_once()

    def test_cancel_while_slot_busy(self):
        root = self.job()
        with patch('jianying_studio.jobs._publication_lock', self.held_slot), \
             patch('jianying_studio.jobs.time.sleep', side_effect=lambda _:save(root/'cancel.request',{})):
            self.assertEqual(work(root)['status'],'cancelled')
        self.backend.publish.assert_not_called()

    def test_timeout_while_slot_busy(self):
        root = self.job()
        with patch('jianying_studio.jobs._publication_lock', self.held_slot), \
             patch('jianying_studio.jobs.time.monotonic', side_effect=[0,0,61]), \
             patch('jianying_studio.jobs.time.sleep'):
            self.assertEqual(work(root)['status'],'waiting-timeout')
        self.backend.publish.assert_not_called()

    def test_preferences_change_while_slot_busy(self):
        root = self.job();request=load(root/'request.json');request['preference_guard']={'session':'fake','revision':5}
        save(root/'request.json',request,replace=True)
        with patch('jianying_studio.preferences.execution'), \
             patch('jianying_studio.preferences.read',side_effect=[{},ValueError('new revision')]), \
             patch('jianying_studio.jobs._publication_lock',self.held_slot),patch('jianying_studio.jobs.time.sleep'):
            self.assertEqual(work(root)['status'],'superseded-preferences')
        self.backend.publish.assert_not_called()

    def test_editor_rechecked_after_slot_acquisition(self):
        with patch('jianying_studio.jobs.process_pids',side_effect=[[],[123],[123],[],[]]), \
             patch('jianying_studio.jobs.time.sleep'):
            self.assertEqual(work(self.job())['status'],'registered')
        self.backend.publish.assert_called_once()

    def test_transaction_error_is_not_retried_and_releases_slot(self):
        root=self.job();self.backend.publish.side_effect=ValueError('transaction failed after possible writes')
        with self.assertRaises(ValueError):work(root)
        self.backend.publish.assert_called_once()
        self.assertEqual(load(root/'state.json')['status'],'failed')
        with _publication_lock() as acquire:self.assertTrue(acquire())

    def child_attempt(self, *, crash=False):
        script = '''import os, sys
from pathlib import Path
sys.path.insert(0, sys.argv[1])
from jianying_studio import jobs
jobs._lock_path=lambda:Path(sys.argv[2])
with jobs._publication_lock() as acquire:
    success=acquire()
    print(int(success), flush=True)
    if sys.argv[3]=='crash' and success: os._exit(19)
'''
        return subprocess.run([sys.executable,'-c',script,str(Path(__file__).resolve().parents[1]),
                              str(self.root/'shared.lock'),'crash' if crash else 'normal'],
                              capture_output=True,text=True,timeout=15)

    def test_other_process_excluded_then_acquires(self):
        with _publication_lock() as acquire:
            self.assertTrue(acquire());result=self.child_attempt()
            self.assertEqual((result.returncode,result.stdout.strip()),(0,'0'),result.stderr)
        result=self.child_attempt()
        self.assertEqual((result.returncode,result.stdout.strip()),(0,'1'),result.stderr)

    def test_crashed_owner_releases_os_lock(self):
        result=self.child_attempt(crash=True)
        self.assertEqual((result.returncode,result.stdout.strip()),(19,'1'),result.stderr)
        with _publication_lock() as acquire:self.assertTrue(acquire())

    def test_windows_lock_adapter_busy_then_release(self):
        fake=Mock(LK_NBLCK=2,LK_UNLCK=0)
        fake.locking.side_effect=[OSError(errno.EACCES,'busy'),None,None]
        with patch('jianying_studio.jobs.sys.platform','win32'),patch.dict(sys.modules,msvcrt=fake):
            with _publication_lock() as acquire:
                self.assertFalse(acquire());self.assertTrue(acquire())
        self.assertEqual([c.args[1:] for c in fake.locking.call_args_list],[(2,1),(2,1),(0,1)])

    def test_unexpected_lock_error_not_retried(self):
        fake=Mock(LK_NBLCK=2,LK_UNLCK=0)
        fake.locking.side_effect=OSError(errno.EBADF,'invalid handle')
        with patch('jianying_studio.jobs.sys.platform','win32'),patch.dict(sys.modules,msvcrt=fake):
            with _publication_lock() as acquire:
                with self.assertRaises(OSError): acquire()
        fake.locking.assert_called_once()


if __name__ == '__main__': unittest.main()
