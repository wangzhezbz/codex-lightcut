from pathlib import Path
import shutil
import subprocess
import sys
import unittest
import uuid

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from jianying_studio.media import prepare, probe, recipe_check
from jianying_studio.storage import sha


@unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'), 'ffmpeg/ffprobe not installed')
class MediaIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = Path(__file__).parent / 'artifacts' / ('media-' + uuid.uuid4().hex)
        cls.root.mkdir(parents=True)
        cls.source = cls.root / '源视频 空格.mp4'
        subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-nostdin', '-n', '-f', 'lavfi',
                        '-i', 'testsrc2=size=320x180:rate=30', '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=48000',
                        '-t', '2', '-c:v', 'libx264', '-threads', '2', '-c:a', 'aac', str(cls.source)], check=True,
                       creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        cls.original_sha = sha(cls.source)

    def test_crop_mirror_and_cache_are_real_media_operations(self):
        recipe = {'schema': 'jianying-studio-media/v1', 'kind': 'video',
                  'crop': {'x': 0, 'y': 0, 'width': 160, 'height': 180}, 'mirror_x': True,
                  'width': 160, 'height': 180, 'fps': 30}
        a = prepare(self.source, recipe, self.root / 'video-cache')
        stream = next(s for s in probe(a['output'])['streams'] if s['codec_type'] == 'video')
        self.assertEqual((stream['width'], stream['height']), (160, 180))
        self.assertFalse(a['cached'])
        b = prepare(self.source, recipe, self.root / 'video-cache')
        self.assertTrue(b['cached']); self.assertEqual(a['sha256'], b['sha256'])
        self.assertEqual(sha(self.source), self.original_sha)
        # Independently compare first decoded frame to the intended filter;
        # lossy output permits a small per-channel error, never an identity test.
        command = ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-i']
        expected = subprocess.check_output(command + [str(self.source), '-vf', 'crop=160:180:0:0,hflip', '-frames:v', '1', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'])
        actual = subprocess.check_output(command + [a['output'], '-frames:v', '1', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'])
        self.assertEqual(len(expected), len(actual))
        self.assertLess(sum(abs(x-y) for x,y in zip(expected, actual)) / len(actual), 7)

    def test_audio_processing_keeps_duration_and_source(self):
        recipe = {'schema': 'jianying-studio-media/v1', 'kind': 'audio', 'denoise': True,
                  'loudness_lufs': -16, 'fade_in_ms': 100, 'fade_out_ms': 200}
        a = prepare(self.source, recipe, self.root / 'audio-cache')
        data = probe(a['output']); self.assertEqual(len(data['streams']), 1)
        self.assertEqual(data['streams'][0]['codec_type'], 'audio')
        self.assertAlmostEqual(float(data['format']['duration']), 2, delta=.1)
        self.assertEqual(sha(self.source), self.original_sha)

    def test_tampered_cache_rejected(self):
        recipe = {'schema': 'jianying-studio-media/v1', 'kind': 'audio', 'gain_db': -3}
        a = prepare(self.source, recipe, self.root / 'tamper-cache')
        with Path(a['output']).open('ab') as stream: stream.write(b'tampered')
        with self.assertRaisesRegex(ValueError, 'Cached media changed'):
            prepare(self.source, recipe, self.root / 'tamper-cache')

    def test_crop_outside_source_rejected(self):
        recipe = {'schema': 'jianying-studio-media/v1', 'kind': 'video', 'crop': {'x': 300, 'y': 0, 'width': 160, 'height': 180}}
        with self.assertRaisesRegex(ValueError, 'Crop outside'):
            prepare(self.source, recipe, self.root / 'invalid-cache')


class RecipeTests(unittest.TestCase):
    def test_filter_expression_injection_rejected(self):
        recipe = {'schema': 'jianying-studio-media/v1', 'kind': 'video', 'crop': {'x': '0;evil', 'y': 0, 'width': 160, 'height': 180}}
        with self.assertRaises(ValueError): recipe_check(recipe)

    def test_audio_recipe_cannot_silently_ignore_crop(self):
        with self.assertRaises(ValueError):
            recipe_check({'schema': 'jianying-studio-media/v1', 'kind': 'audio', 'mirror_x': True})


if __name__ == '__main__': unittest.main()
