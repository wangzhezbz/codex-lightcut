from copy import deepcopy
import contextlib, io, json, os
from pathlib import Path
import sys, unittest, uuid
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from jianying_studio import onboarding as o, cli, native_style
from jianying_studio.storage import manifest, load
from onboarding_fixtures import fixture

class SetupTests(unittest.TestCase):
    def resource_fixture(self):
        root=Path(__file__).parent/'artifacts'/('onboarding-'+uuid.uuid4().hex)
        asset=root/'fresh-user/Cache/effect/123/hash'
        asset.mkdir(parents=True);(asset/'config.json').write_text('{"effect":1}')
        recipe={'resources':{'one':{'scope':'cache','relative':'effect/123/hash','files':manifest(asset)}},
                'supported_profiles':{'macos':['mac-reviewed'],'windows':[]},
                'profile':{'path':'lightcut-resource://one','catalog':{}}}
        return root,asset,recipe

    def test_fresh_user_resource_binding_without_donor_or_old_profile(self):
        root,asset,r=self.resource_fixture()
        bindings,checks=o.resolve_resources(r,[root/'fresh-user/Cache'],[])
        p=o.bind_profile(r,bindings,'macos','mac-reviewed')
        self.assertEqual(p['path'],str(asset));self.assertEqual(checks[0]['status'],'matched')
        self.assertFalse((root/'local/profiles').exists())

    def test_windows_cannot_become_ready_using_mac_resources(self):
        root,asset,r=self.resource_fixture()
        b,_=o.resolve_resources(r,[root/'fresh-user/Cache'],[])
        with self.assertRaisesRegex(ValueError,'尚未适配'):o.bind_profile(r,b,'windows','win-reviewed')

    def test_resource_tamper_and_missing_are_distinct(self):
        root,asset,r=self.resource_fixture();(asset/'config.json').write_text('changed')
        b,c=o.resolve_resources(r,[root/'fresh-user/Cache'],[])
        self.assertEqual(b,{});self.assertEqual(c[0]['status'],'different')
        b,c=o.resolve_resources(r,[root/'other-user/Cache'],[])
        self.assertEqual(c[0]['status'],'missing')

    def test_variants_are_reported_never_substituted(self):
        root,asset,r=self.resource_fixture();r['resources']['one']['relative']='effect/123/different'
        b,c=o.resolve_resources(r,[root/'fresh-user/Cache'],[])
        self.assertEqual(b,{});self.assertEqual(c[0]['alternatives'],['hash'])

    @unittest.skipIf(os.name=='nt','Symlink creation requires special Windows rights')
    def test_symlink_resource_rejected(self):
        root,asset,r=self.resource_fixture();linked=root/'linked';linked.symlink_to(root/'fresh-user/Cache',target_is_directory=True)
        b,c=o.resolve_resources(r,[linked],[])
        self.assertEqual(b,{});self.assertEqual(c[0]['status'],'different')

    def test_resource_path_escape_rejected(self):
        root,asset,r=self.resource_fixture()
        for path in ('../outside','C:/outside','/outside','effect\\outside'):
            r['resources']['one']['relative']=path
            with self.assertRaisesRegex(ValueError,'Unsafe'):o.resolve_resources(r,[root],[])

    def test_recipe_has_no_user_path_entitlement_or_saved_preset(self):
        recipe=load(o.RECIPE);raw=json.dumps(recipe,ensure_ascii=False)
        for unwanted in ('/Users/','C:\\\\Users','material_is_purchased','is_favorite','requestId'):
            self.assertNotIn(unwanted,raw)
        self.assertEqual(recipe['profile']['catalog'],{})
        self.assertEqual(recipe['profile']['beauty_video']['beauty_face_preset_infos'],[])

    def test_default_import_style_not_basic(self):
        with patch.object(cli,'import_plan',return_value={}) as importer, patch.object(cli,'validate',return_value={}), contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(cli.main(['import-plan','--plan','source.json','--out','fresh']),0)
        self.assertEqual(importer.call_args.args[2],load(o.DEFAULT_STYLE))

    def test_setup_failed_exit_code(self):
        with patch.object(o,'prepare',return_value=({'status':'needs-attention'},None)),contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(cli.main(['setup']),2)

    def test_deliver_blocked_before_asset_copy_and_backend_build(self):
        from jianying_studio import delivery
        root,p=fixture();out=root.parent/('delivery-'+uuid.uuid4().hex)
        report={'status':'needs-attention','blockers':[{'code':'style-adapter-pending'}]}
        with patch.object(delivery,'prepare',return_value=(report,None)),patch.object(delivery,'package_project') as package:
            result=delivery.deliver(root,out)
        self.assertFalse(result['draft_created']);package.assert_not_called()
        self.assertTrue((out/'setup.json').is_file());self.assertEqual(load(root/'project.json'),p)

    def test_deliver_needs_attention_exits_nonzero(self):
        from jianying_studio import delivery
        with patch.object(delivery,'deliver',return_value={'status':'needs-attention'}),contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(cli.main(['deliver','--project','x','--out','y']),2)

    def test_video_intervals_exclude_cover_inserted_photo_and_tail(self):
        doc={'materials':{'videos':[{'id':'v','type':'video'},{'id':'p','type':'photo'}]},'tracks':[{'segments':[
            {'material_id':m,'target_timerange':{'start':s,'duration':d}}
            for m,s,d in [('p',0,1),('v',1,5),('v',6,4),('p',10,3),('v',13,7),('p',20,1)]]}]}
        self.assertEqual(native_style.video_ranges(doc),[{'start':1,'duration':9},{'start':13,'duration':7}])

if __name__=='__main__':unittest.main()
