from copy import deepcopy
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
import uuid

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from jianying_studio import native_style, operations, project
from jianying_studio.storage import asset_path, component, load, save, sha
from jianying_studio.mac_backend import engine

HERE = Path(__file__).resolve().parent


def fixture():
    root = HERE / 'artifacts' / uuid.uuid4().hex
    (root / 'assets').mkdir(parents=True)
    for name in ('video.mp4', 'audio.wav', 'image.png'):
        (root / 'assets' / name).write_bytes(('test-' + name).encode())
    assets = {kind: {'path': 'assets/' + name, 'sha256': sha(root / 'assets' / name),
                     'size': (root / 'assets' / name).stat().st_size, 'kind': kind}
              for kind, name in [('video', 'video.mp4'), ('audio', 'audio.wav'), ('image', 'image.png')]}
    p = {'schema': project.SCHEMA, 'name': '兼容测试', 'canvas': {'width': 1080, 'height': 1920, 'fps': 30},
         'assets': assets, 'style': load(HERE.parent / 'presets/基础无效果.json'), 'tracks': [
             {'type': 'video', 'name': '主视频', 'segments': [{'asset': 'video', 'start_us': 0, 'duration_us': 4000000}]},
             {'type': 'audio', 'name': '音乐', 'segments': [{'asset': 'audio', 'start_us': 0, 'duration_us': 4000000}]},
             {'type': 'text', 'name': '字幕', 'segments': [{'text': '你好 Windows 与 Mac', 'start_us': 500000, 'duration_us': 1000000}]}]}
    save(root / 'project.json', p)
    return root, p


class PortableTests(unittest.TestCase):
    def test_move_project_preserves_relative_assets_and_resolves_new_root(self):
        root, p = fixture(); destination = root.parent / uuid.uuid4().hex
        project.package_project(root, destination)
        a, b = project.compile_plan(p, root), project.compile_plan(load(destination / 'project.json'), destination)
        self.assertNotEqual(a['tracks'][0]['segments'][0]['source'], b['tracks'][0]['segments'][0]['source'])
        self.assertEqual(sha(a['tracks'][0]['segments'][0]['source']), sha(b['tracks'][0]['segments'][0]['source']))
        self.assertNotIn(str(root), json.dumps(load(destination / 'project.json')))

    def test_windows_reserved_and_path_injection_rejected(self):
        for name in ('CON', 'nul.txt', 'LPT1', 'A:B', 'file.', 'file ', '../draft', 'x\\y'):
            with self.subTest(name=name), self.assertRaises(ValueError): component(name)

    def test_absolute_and_parent_asset_paths_rejected(self):
        root, p = fixture()
        for name in ('../outside.mp4', '/tmp/foo', 'C:/Users/foo.mp4', '\\\\server\\share', 'assets/../../foo'):
            with self.subTest(name=name), self.assertRaises(ValueError): asset_path(root, name)

    def test_modified_media_rejected(self):
        root, p = fixture(); (root / 'assets/video.mp4').write_bytes(b'X' * p['assets']['video']['size'])
        with self.assertRaisesRegex(ValueError, 'bytes changed'): project.validate(p, root)

    def test_unknown_effect_not_silently_dropped(self):
        root, p = fixture(); p['tracks'][0]['segments'][0]['magic_effect'] = 'anything'
        with self.assertRaisesRegex(ValueError, 'unsupported fields'): project.validate(p, root)

    def test_retime_requires_consistent_source_duration(self):
        _, p = fixture(); p['tracks'][0]['segments'][0]['speed'] = 2
        with self.assertRaisesRegex(ValueError, 'timing mismatch'): project.validate(p)

    def test_unverified_trimmed_keyframes_blocked(self):
        _, p = fixture(); s = p['tracks'][0]['segments'][0]
        s['source_start_us'] = 1000000
        s['keyframes'] = {'scale': [{'at_us': 0, 'value': 1}, {'at_us': 2000000, 'value': 1.2}]}
        with self.assertRaisesRegex(ValueError, 'not verified'): project.validate(p)

    def test_overlay_outside_main_rejected(self):
        _, p = fixture(); p['tracks'][2]['segments'][0]['duration_us'] = 5000000
        with self.assertRaisesRegex(ValueError, 'exceeds'): project.validate(p)

    def test_dissolve_requires_even_frames(self):
        _, p = fixture(); segments = p['tracks'][0]['segments']; segments[0]['duration_us'] = 2000000
        segments.append({'asset': 'video', 'start_us': 2000000, 'duration_us': 2000000})
        segments[0]['transition_out'] = {'name': 'dissolve', 'duration_us': 500000}
        with self.assertRaisesRegex(ValueError, 'even'): project.validate(p)
        segments[0]['transition_out']['duration_us'] = 400000
        project.validate(p)

    def test_ducking_preserves_timeline_and_restores_volume(self):
        _, p = fixture(); q = operations.duck_music(p, 1, [[1000000, 2000000]], gain=.2)
        self.assertEqual(p['tracks'][0], q['tracks'][0]); self.assertEqual(p['tracks'][2], q['tracks'][2])
        points = q['tracks'][1]['segments'][0]['keyframes']['volume']
        values = {v['at_us']: v['value'] for v in points}
        self.assertEqual(values[0], 1); self.assertEqual(values[1000000], .2); self.assertEqual(values[2000000], .2)
        self.assertEqual(values[2240000], 1); self.assertEqual(values[4000000], 1)
        self.assertNotIn('keyframes', p['tracks'][1]['segments'][0])

    def test_ducking_merged_speech_does_not_pump_between_words(self):
        _, p = fixture(); q = operations.duck_music(p, 1, [[1000000, 1500000], [1550000, 2000000]], gain=.2)
        times = {x['at_us'] for x in q['tracks'][1]['segments'][0]['keyframes']['volume']}
        self.assertNotIn(1500000, times); self.assertNotIn(1550000, times)

    def test_ducking_refuses_existing_animation(self):
        _, p = fixture(); q = operations.duck_music(p, 1, [[1000000, 2000000]])
        with self.assertRaisesRegex(ValueError, 'overwrite'): operations.duck_music(q, 1, [[1000000, 2000000]])

    def test_cover_shifts_subtitles_and_music_together(self):
        _, p = fixture(); q = operations.prepend_cover(p, 'image', 33333)
        self.assertEqual(project.validate(q)['duration_us'], 4033333)
        self.assertEqual(q['tracks'][1]['segments'][0]['start_us'], 33333)
        self.assertEqual(q['tracks'][2]['segments'][0]['start_us'], 533333)

    def test_end_fade_preserves_cut_and_duration(self):
        _, p = fixture(); q = operations.add_end_fade(p, 'image')
        self.assertEqual(q['tracks'][:3], p['tracks'])
        self.assertEqual(q['tracks'][-1]['segments'][0]['start_us'], 3700000)
        self.assertEqual(project.validate(q)['duration_us'], 4000000)

    def test_windows_does_not_load_or_execute_mac_backend(self):
        with patch('jianying_studio.mac_backend.host', return_value='windows'):
            with self.assertRaisesRegex(ValueError, 'Windows draft backend is not adapted'): engine()

    def test_invalid_beauty_parameter_rejected(self):
        style = load(HERE.parent / 'presets/口播清晰自然.json'); style['beauty']['values']['磨皮'] = 8
        with self.assertRaises(ValueError): project.style_check(style)


class NativeStyleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        p = HERE.parents[1] / 'upstream/jianying-headless/work/jev-background-effects-20260921'
        if not p.exists(): raise unittest.SkipTest('Private native captures absent; portable tests still run')
        cls.profile = native_style.capture(load(p / 'snapshots/1-timeline.json'), load(p / 'snapshots/beauty-preset.json'), load(p / 'snapshots/adjust-preset.json'))
        # A plain native build is read from the earlier frozen encrypted output's readable sibling.
        doc = load(p / 'verified-shared-build/timeline.json')
        cls.base = deepcopy(doc)
        beauty_ids = {n['id'] for n in cls.base['materials']['effects'] if n['type'] in ('figure', 'makeup_root')}
        cls.base['tracks'] = [t for t in cls.base['tracks'] if t['type'] not in ('filter', 'adjust')]
        cls.base['materials']['effects'] = []
        original = cls.base['materials']['videos'][0]
        cls.base['materials']['videos'] = []
        for s in cls.base['tracks'][0]['segments']:
            v = deepcopy(original); v['id'] = native_style.uid(); s['material_id'] = v['id']
            for key in cls.profile['beauty_video']: v.pop(key, None)
            cls.base['materials']['videos'].append(v)
            s['extra_material_refs'] = [r for r in s['extra_material_refs'] if r not in beauty_ids]
        cls.style = load(HERE.parent / 'presets/口播清晰自然.json')

    def test_every_clip_has_independent_beauty(self):
        t = native_style.apply(self.base, self.style, self.profile)
        result = native_style.verify_ownership(t, True)
        self.assertEqual(result['video_owners'], 7); self.assertEqual(result['beauty_nodes'], 91)
        self.assertEqual(len({n['algorithm_artifact_path'] for n in t['materials']['effects'] if n.get('algorithm_artifact_path')}), 7)

    def test_custom_strength_does_not_claim_saved_preset_identity(self):
        style = deepcopy(self.style); style['beauty']['values']['磨皮'] = .12
        t = native_style.apply(self.base, style, self.profile)
        for v in t['materials']['videos']: self.assertEqual(v['beauty_face_preset_infos'], [])
        for n in t['materials']['effects']:
            if n.get('name') == '磨皮': self.assertEqual(n['value'], .12)

    def test_disabled_beauty_does_not_leak_into_output(self):
        style = deepcopy(self.style); style['beauty']['enabled'] = False
        t = native_style.apply(self.base, style, self.profile)
        self.assertEqual(native_style.verify_ownership(t, False)['beauty_nodes'], 0)

    def test_shared_node_regression_rejected(self):
        t = native_style.apply(self.base, self.style, self.profile)
        segs = t['tracks'][0]['segments']; idx = native_style.index(t)
        a = next(r for r in segs[0]['extra_material_refs'] if idx[r][1].get('name') == '磨皮')
        b = next(r for r in segs[1]['extra_material_refs'] if idx[r][1].get('name') == '磨皮')
        segs[1]['extra_material_refs'] = [a if r == b else r for r in segs[1]['extra_material_refs']]
        with self.assertRaisesRegex(ValueError, 'Shared mutable'): native_style.verify_ownership(t, True)


if __name__ == '__main__': unittest.main()
