from copy import deepcopy
import contextlib
import io
import json
from pathlib import Path
import sys
import unittest
import uuid
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from jianying_studio import preferences as p, preference_project as pp, project, delivery, cli
from jianying_studio.storage import load, save, sha
from jianying_studio.audio_quality import project_digest
from onboarding_fixtures import fixture


class PreferencesTests(unittest.TestCase):
    def root(self):
        root = Path(__file__).parent / 'artifacts' / ('preferences-' + uuid.uuid4().hex)
        root.mkdir(parents=True)
        return root

    def session(self, patch_values=None, cover='none'):
        status = p.start(self.root())
        choices = p.recommendations()
        # These legacy tests explicitly retain their fixture project font.
        choices['editing']['captions']['font_name'] = None
        choices['cover']['mode'] = cover
        status = p.update(status['session'], status['revision'], p.merge(choices, patch_values or {}))
        return p.confirm(status['session'], status['revision'], scope='once')

    def bindings(self, state, root, source):
        b = pp.bindings_template(state['session'], state['revision'], root)
        b.update(music_tracks=[1], caption_tracks=[2],
                 editing_applied={k: state['choices']['editing'][k] for k in ('pace', 'aspect')})
        return b

    def test_first_run_recommendation_is_not_confirmation(self):
        status = p.start(self.root())
        self.assertEqual(status['pending_groups'], list(p.GROUPS))
        self.assertEqual(len(p.catalog()['cover_styles']), 5)
        with self.assertRaises(ValueError): p.confirm(status['session'], 1, scope='once')
        s = p.update(status['session'], 1, {}, recommended=p.GROUPS)
        self.assertEqual(s['status'], 'needs-confirmation')
        self.assertFalse(s['can_deliver'])

    def test_partial_updates_preserve_other_settings_and_invalidate_confirmation(self):
        s = self.session()
        self.assertTrue(s['can_deliver'])
        changed = p.update(s['session'], s['revision'], {'effects': {'beauty': {'enabled': False}}})
        self.assertFalse(changed['confirmed'])
        self.assertEqual(changed['choices']['music'], s['choices']['music'])
        self.assertEqual(changed['choices']['effects']['filter'], s['choices']['effects']['filter'])
        with self.assertRaises(ValueError): p.execution(s['session'], s['revision'])
        with self.assertRaises(ValueError): p.confirm(s['session'], s['revision'], scope='once')

    def test_defaults_are_explicit_and_do_not_retain_per_video_title_or_image(self):
        root = self.root(); s = p.start(root)
        s = p.update(s['session'], 1, {'cover': {'mode': 'none', 'title': '本次标题'}}, recommended=p.GROUPS)
        s = p.confirm(s['session'], s['revision'], scope='once')
        self.assertIsNone(p.defaults(root))
        s = p.confirm(s['session'], s['revision'], scope='defaults')
        default = p.defaults(root)
        self.assertEqual(default['choices']['cover']['title'], '')
        s = p.update(s['session'], s['revision'], {'effects': {'beauty': {'enabled': False}}})
        p.confirm(s['session'], s['revision'], scope='once')
        self.assertTrue(p.start(root)['choices']['effects']['beauty']['enabled'])

    def test_stale_task_cannot_overwrite_new_defaults(self):
        root = self.root(); first = p.start(root); second = p.start(root)
        for s in (first, second):
            p.update(s['session'], 1, {'cover': {'mode': 'none'}}, recommended=p.GROUPS)
        p.confirm(first['session'], 2, scope='defaults')
        with self.assertRaisesRegex(ValueError, '其他任务'): p.confirm(second['session'], 2, scope='defaults')
        self.assertFalse(p.status(second['session'])['confirmed'])

    def test_music_requires_real_selection_and_explicit_reuse(self):
        root = self.root(); music = root / '我的音乐.wav'; music.write_bytes(b'music')
        s = p.start(root)
        s = p.update(s['session'], 1, {'cover': {'mode': 'none'}, 'music': {'mode': 'file'}}, recommended=p.GROUPS)
        with self.assertRaisesRegex(ValueError, '真实音乐'): p.confirm(s['session'], s['revision'], scope='once')
        s = p.update(s['session'], s['revision'], {'music': {'asset': p.asset(music)}})
        s = p.confirm(s['session'], s['revision'], scope='defaults')
        self.assertIn('music', p.start(root)['pending_groups'])
        s = p.update(s['session'], s['revision'], {'music': {'remember_asset': True}})
        p.confirm(s['session'], s['revision'], scope='defaults')
        self.assertNotIn('music', p.start(root)['pending_groups'])

    def test_generated_cover_requires_actual_separate_approval_and_detects_changes(self):
        s = self.session(cover='generate')
        self.assertEqual(s['status'], 'needs-cover-review')
        image = self.root() / '封面.png'; image.write_bytes(b'preview-one')
        with self.assertRaises(ValueError): p.cover_review(s['session'], s['revision'], approve=True)
        with self.assertRaises(ValueError): p.cover_review(s['session'], s['revision'], image=image, approve=True)
        s = p.cover_review(s['session'], s['revision'], image=image, title='真实标题')
        self.assertFalse(s['can_deliver'])
        s = p.cover_review(s['session'], s['revision'], approve=True)
        self.assertTrue(s['can_deliver'])
        image.write_bytes(b'preview-two')
        with self.assertRaisesRegex(ValueError, '变化'): p.execution(s['session'], s['revision'])

    def test_changed_cover_style_invalidates_image_approval(self):
        s = self.session(cover='generate'); image = self.root() / 'image.png'; image.write_bytes(b'image')
        s = p.cover_review(s['session'], s['revision'], image=image, title='标题')
        s = p.cover_review(s['session'], s['revision'], approve=True)
        s = p.update(s['session'], s['revision'], {'cover': {'style': 'minimal'}})
        s = p.confirm(s['session'], s['revision'], scope='once')
        self.assertIsNone(s['cover_review']); self.assertFalse(s['can_deliver'])

    def test_cover_can_be_approved_early_without_confirming_other_groups(self):
        s=p.start(self.root());s=p.update(s['session'],s['revision'],{},recommended=['cover'])
        image=self.root()/'early.png';image.write_bytes(b'early cover')
        s=p.cover_review(s['session'],s['revision'],image=image,title='本次主题')
        s=p.cover_review(s['session'],s['revision'],approve=True)
        self.assertTrue(s['cover_review']['approved']);self.assertFalse(s['confirmed']);self.assertFalse(s['can_deliver'])
        self.assertEqual(s['pending_groups'],['effects','music','editing'])
        with self.assertRaises(ValueError):p.execution(s['session'],s['revision'])
        approved=deepcopy(s['cover_review'])
        s=p.update(s['session'],s['revision'],{'editing': {'captions': {'font_name': None}}},recommended=['effects','music','editing'])
        self.assertEqual(s['cover_review'],approved);self.assertFalse(s['can_deliver'])
        s=p.confirm(s['session'],s['revision'],scope='once')
        self.assertTrue(s['can_deliver']);p.execution(s['session'],s['revision'])

    def test_early_review_still_rejects_missing_cover_and_unselected_image(self):
        s=p.start(self.root());image=self.root()/'early.png';image.write_bytes(b'image')
        with self.assertRaises(ValueError):p.cover_review(s['session'],s['revision'],image=image)
        s=p.update(s['session'],s['revision'],{'cover':{'mode':'image','asset':p.asset(image)}})
        other=self.root()/'other.png';other.write_bytes(b'other')
        with self.assertRaisesRegex(ValueError,'不一致'):p.cover_review(s['session'],s['revision'],image=other)
        s=p.cover_review(s['session'],s['revision'],image=image)
        image.write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'变化'):p.cover_review(s['session'],s['revision'],approve=True)

    def test_defaults_keep_only_explicit_style_notes_not_current_topic(self):
        root=self.root();s=p.start(root)
        s=p.update(s['session'],s['revision'],{'cover':{'instructions':'本条视频讲工具测评',
            'style_instructions':'以后偏蓝色，不要卡通','title':'当前标题'}},recommended=p.GROUPS)
        s=p.confirm(s['session'],s['revision'],scope='defaults')
        saved=p.defaults(root);next_session=p.start(root)
        for choices in (saved['choices'],next_session['choices']):
            self.assertEqual(choices['cover']['instructions'],'')
            self.assertEqual(choices['cover']['style_instructions'],'以后偏蓝色，不要卡通')
            self.assertEqual(choices['cover']['title'],'')
        self.assertEqual(s['choices']['cover']['instructions'],'本条视频讲工具测评')
        self.assertEqual(s['choices']['cover']['title'],'当前标题')

    def test_legacy_topic_is_not_reused_or_silently_migrated_on_disk(self):
        root=self.root();choices=p.recommendations();choices['cover']['instructions']='旧视频主题'
        choices['cover'].pop('style_instructions')
        file=root/'defaults/r00000001.json'
        save(file,{'schema':p.SCHEMA,'kind':'defaults','revision':1,'choices':choices})
        before=file.read_bytes();s=p.start(root)
        self.assertEqual(s['choices']['cover']['instructions'],'')
        self.assertEqual(s['choices']['cover']['style_instructions'],'')
        self.assertEqual(file.read_bytes(),before)
        self.assertEqual(s['choices']['effects'],choices['effects'])

    def test_user_title_cannot_be_silently_changed(self):
        s = self.session({'cover': {'title_policy': 'user', 'title': '我的标题'}}, cover='generate')
        image = self.root() / 'image.png'; image.write_bytes(b'image')
        with self.assertRaisesRegex(ValueError, '不一致'):
            p.cover_review(s['session'], s['revision'], image=image, title='换了标题')

    def test_invalid_values_and_unknown_fields_fail_without_writing_revision(self):
        s = self.session()
        for patch_value in ({'music': {'gain_db': float('nan')}}, {'effects': {'beauty': {'values': {'瘦脸': 2}}}},
                            {'editing': {'captions': {'y': -5}}}, {'cover': {'style': 'invented'}}, {'unknown': {}},
                            {'editing': {'captions': {'fake': True}}}):
            with self.assertRaises(ValueError): p.update(s['session'], s['revision'], patch_value)
            self.assertEqual(p.read(s['session'])['revision'], s['revision'])

    def test_platform_data_locations(self):
        with patch.dict('os.environ', {'LIGHTCUT_DATA_HOME': ''}, clear=True), patch.object(p.sys, 'platform', 'win32'), patch.object(p.Path, 'home', return_value=Path('/test/home')):
            self.assertEqual(p.home_dir(), Path('/test/home/AppData/Local/CodexLightCut'))
        with patch.dict('os.environ', {'LIGHTCUT_DATA_HOME': ''}, clear=True), patch.object(p.sys, 'platform', 'darwin'), patch.object(p.Path, 'home', return_value=Path('/test/home')):
            self.assertEqual(p.home_dir(), Path('/test/home/Library/Application Support/CodexLightCut'))

    def test_real_project_effects_caption_changes_and_removing_only_bgm(self):
        root, source = fixture()
        source['tracks'].append({'type': 'audio', 'name': '独立音效', 'segments': deepcopy(source['tracks'][1]['segments'])})
        save(root/'project.json', source, replace=True)
        original = (root/'project.json').read_bytes()
        s = self.session({'effects': {'beauty': {'enabled': False}}, 'editing': {'captions': {'y': -.4}}})
        result = pp.apply(s['session'], s['revision'], root, self.root()/'new', self.bindings(s, root, source))
        revised = load(Path(result['project'])/'project.json')
        self.assertEqual((root/'project.json').read_bytes(), original)
        self.assertFalse(revised['style']['beauty']['enabled'])
        self.assertTrue(revised['style']['filter']['enabled'])
        self.assertNotIn('音乐', [t['name'] for t in revised['tracks']])
        self.assertIn('独立音效', [t['name'] for t in revised['tracks']])
        self.assertEqual(revised['tracks'][1]['segments'][0]['y'], -.4)
        project.validate(revised, result['project'])

    def test_music_selection_gain_and_mismatch(self):
        root, source = fixture()
        s = self.session({'music': {'mode': 'file', 'asset': p.asset(root/'assets/audio.wav'), 'gain_db': -10, 'start_frame': 0},
                          'editing': {'speech_gain_db': 15}})
        bindings = self.bindings(s, root, source)
        configured, _ = pp.configured(s['session'], s['revision'], root, bindings)
        self.assertAlmostEqual(configured['tracks'][1]['segments'][0]['volume'], 10**(-10/20))
        self.assertEqual(configured['tracks'][0]['segments'][0]['volume'], 5.6234130859375)
        configured['tracks'][1]['segments'][0]['volume'] = 1
        with self.assertRaisesRegex(ValueError, 'confirmed volume'): project.validate(configured)
        other = self.root()/'different.wav'; other.write_bytes(b'other')
        s = p.update(s['session'], s['revision'], {'music': {'asset': p.asset(other)}})
        s = p.confirm(s['session'], s['revision'], scope='once')
        bindings = self.bindings(s, root, source)
        with self.assertRaisesRegex(ValueError, '曲目不一致'): pp.configured(s['session'], s['revision'], root, bindings)

    def test_wrong_role_digest_or_old_choices_and_unplanned_editing_rejected(self):
        root, source = fixture(); s = self.session(); b = self.bindings(s, root, source)
        for change in ({'project_sha256': '0'*64}, {'choices_sha256': '0'*64}, {'editing_applied': None}, {'music_tracks': [0]}):
            with self.assertRaises(ValueError): pp.configured(s['session'], s['revision'], root, dict(b, **change))

    def test_all_effects_off_and_no_captions_produce_basic_style(self):
        root, source = fixture()
        s = self.session({'effects': {k: {'enabled': False} for k in ('beauty','filter','adjustment')},
                          'editing': {'captions': {'enabled': False}}})
        revised, _ = pp.configured(s['session'], s['revision'], root, self.bindings(s, root, source))
        self.assertIsNone(revised['style']['native_profile'])
        self.assertFalse(revised['style']['subtitle_shadow'])
        self.assertEqual(len(revised['tracks']), 1)

    def test_selected_font_is_copied_and_original_assets_untouched(self):
        root, source = fixture(); font=self.root()/'user.ttf'; font.write_bytes(b'font')
        s = self.session({'editing': {'captions': {'font': p.asset(font)}}})
        result = pp.apply(s['session'], s['revision'], root, self.root()/'new', self.bindings(s, root, source))
        revised=load(Path(result['project'])/'project.json')
        font_id=revised['tracks'][1]['segments'][0]['font_asset']
        self.assertEqual(sha(Path(result['project'])/revised['assets'][font_id]['path']), sha(font))
        self.assertNotIn(font_id, load(root/'project.json')['assets'])

    def test_selected_cover_must_be_bound_and_match(self):
        root, source=fixture()
        s=self.session({'cover': {'asset': p.asset(root/'assets/image.png')}}, cover='image')
        s=p.cover_review(s['session'], s['revision'], image=root/'assets/image.png')
        s=p.cover_review(s['session'], s['revision'], approve=True)
        b=self.bindings(s,root,source)
        with self.assertRaisesRegex(ValueError,'首片段'): pp.configured(s['session'],s['revision'],root,b)
        b['cover_segment']=0
        with self.assertRaisesRegex(ValueError,'已确认的图片'): pp.configured(s['session'],s['revision'],root,b)
        source['tracks'][0]['segments'].insert(0, {'asset':'image','start_us':0,'duration_us':33333,'volume':0})
        source['tracks'][0]['segments'][1]['start_us']=33333
        save(root/'project.json',source,replace=True)
        b=self.bindings(s,root,source);b['cover_segment']=0
        pp.configured(s['session'],s['revision'],root,b)

    def test_release_resources_prepare_after_confirmation_with_selected_effects_only(self):
        root,source=fixture();s=self.session({'effects':{'beauty':{'enabled':False}}})
        bindings=self.bindings(s,root,source)
        with patch('jianying_studio.release.prepare',return_value=({'status':'needs-attention','blockers':[{'code':'fixture-resource-failure'}]},None)) as prepare:
            result=delivery.deliver(root,self.root()/'blocked',session=s['session'],revision=s['revision'],bindings=bindings,release_preview=True)
            self.assertEqual(result['stage'],'setup');self.assertFalse(result['draft_created'])
            self.assertTrue(prepare.call_args.kwargs['allow_download'])
            self.assertFalse(prepare.call_args.args[0]['beauty']['enabled'])
            self.assertTrue(prepare.call_args.args[0]['filter']['enabled'])
        pending=p.update(s['session'],s['revision'],{'effects':{'filter':{'enabled':False}}})
        with patch('jianying_studio.release.prepare') as prepare:
            with self.assertRaises(ValueError):
                delivery.deliver(root,self.root()/'unconfirmed',session=pending['session'],revision=pending['revision'],bindings=bindings,release_preview=True)
            prepare.assert_not_called()

    def test_deliver_uses_confirmed_style_not_default(self):
        root, source = fixture()
        s=self.session({'effects': {'beauty': {'enabled': False}}, 'editing': {'captions': {'y': -.3}}})
        backend=Mock()
        backend.build.return_value={'name':'新草稿','acceptance':{'render':'not-checked'}}
        with patch.object(delivery,'prepare',return_value=({'status':'ready-for-build'},None)) as setup, \
             patch('jianying_studio.quality.inspect',return_value={'errors':[]}), \
             patch('jianying_studio.audio_quality.audit'), patch('jianying_studio.native_backend.current',return_value=backend):
            result=delivery.deliver(root,self.root()/'delivery',session=s['session'],revision=s['revision'],bindings=self.bindings(s,root,source))
        self.assertFalse(setup.call_args.kwargs['style']['beauty']['enabled'])
        built_project=load(backend.build.call_args.args[0]/'project.json')
        self.assertFalse(built_project['style']['beauty']['enabled'])
        self.assertEqual(built_project['tracks'][1]['segments'][0]['y'], -.3)
        self.assertEqual(result['preference_revision'],s['revision'])
        self.assertEqual(load(Path(result['creative_settings']))['project_sha256'], project_digest(built_project))
        self.assertEqual(load(root/'project.json'),source)

    def test_unconfirmed_delivery_cannot_copy_or_build(self):
        root,source=fixture();s=p.start(self.root())
        with patch.object(delivery,'prepare') as setup, patch.object(delivery,'package_project') as copy:
            with self.assertRaises(ValueError): delivery.deliver(root,self.root()/'blocked',session=s['session'],revision=1,bindings={})
        setup.assert_not_called();copy.assert_not_called()

    def test_cli_round_trip_with_unicode_paths_and_stale_rejection(self):
        root=self.root()/'中文 空格'; output=io.StringIO()
        with contextlib.redirect_stdout(output): self.assertEqual(cli.main(['preferences-start','--home',str(root)]),0)
        s=json.loads(output.getvalue())
        with contextlib.redirect_stdout(io.StringIO()): self.assertEqual(cli.main(['preferences-update','--session',s['session'],'--revision','1','--recommended',*p.GROUPS]),0)
        with contextlib.redirect_stderr(io.StringIO()): self.assertEqual(cli.main(['preferences-confirm','--session',s['session'],'--revision','1','--scope','once']),2)

    def test_saving_defaults_preserves_manual_title_preference(self):
        s = self.session({'cover': {'title_policy': 'user', 'title': '本次标题'}}, cover='generate')
        p.confirm(s['session'], s['revision'], scope='defaults')
        root = Path(s['session']).parents[1]
        next_session = p.start(root)
        self.assertEqual(next_session['choices']['cover']['title_policy'], 'user')
        self.assertIn('cover', next_session['pending_groups'])

    def test_waiting_publication_stops_after_preferences_change(self):
        from jianying_studio import jobs
        s = self.session(); root = self.root()
        save(root/'request.json', {'build':str(root/'build'), 'timeout_seconds':60,
             'preference_guard':{'session':s['session'],'revision':s['revision']}})
        save(root/'state.json', {'status':'queued'})
        backend = Mock()
        def changed(_):
            p.update(s['session'], s['revision'], {'music': {'gain_db': -5}})
        with patch('jianying_studio.native_backend.current',return_value=backend), \
             patch.object(jobs,'process_pids',return_value=[123]), patch.object(jobs,'background_priority'), \
             patch.object(jobs.time,'sleep',side_effect=changed):
            result = jobs.work(root)
        self.assertEqual(result['status'],'superseded-preferences')
        backend.publish.assert_not_called()


if __name__ == '__main__': unittest.main()
