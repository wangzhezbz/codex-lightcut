from copy import deepcopy
import json
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import unittest
from unittest.mock import patch
import uuid
import zlib

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from jianying_studio.audio_quality import audit, gain_at, project_digest, refine, render_reference, tail_metrics
from jianying_studio.quality import inspect
from jianying_studio.storage import load, sha
from test_portable import fixture


class QualityGateTests(unittest.TestCase):
    def test_caption_crossing_edit_is_flagged_but_touching_edge_is_not(self):
        root,p=fixture()
        p['tracks'][0]['segments']=[
            {'asset':'video','start_us':0,'duration_us':1000000},
            {'asset':'video','start_us':1000000,'source_start_us':3000000,'duration_us':3000000}]
        with patch('jianying_studio.quality.probe',return_value=self.source()):
            result=inspect(p,root)
        alerts=[x for x in result['warnings'] if x['code']=='caption-crosses-edit']
        self.assertEqual(alerts[0]['cuts_us'],[1000000])
        p['tracks'][2]['segments'][0]['duration_us']=500000
        with patch('jianying_studio.quality.probe',return_value=self.source()):
            result=inspect(p,root)
        self.assertNotIn('caption-crosses-edit',[x['code'] for x in result['warnings']])

    def test_native_caption_check_preserves_beauty_settings(self):
        root,p=fixture();p['style']=load(Path(__file__).parents[1]/'presets/口播清晰自然.json')
        p['style']['filter']['enabled']=False;p['style']['adjustment']['enabled']=False
        p['tracks'][2]['segments'][0]['y']=-0.551507430997877
        nodes=[{'id':name,'name':name,'value':value,'type':'figure'}
               for name,value in p['style']['beauty']['values'].items()]
        timeline={'tracks':[
            {'type':'video','segments':[{'material_id':'video','extra_material_refs':[n['id'] for n in nodes]}]},
            {'type':'text','segments':[{'clip':{'transform':{'x':0,'y':-0.551507430997877}}}]}],
            'materials':{'videos':[{'id':'video','type':'video'}],'effects':nodes}}
        build=root/'caption-and-beauty';build.mkdir()
        (build/'project.json').write_text(json.dumps(p));(build/'timeline.json').write_text(json.dumps(timeline))
        (build/'build.json').write_text(json.dumps({'timeline_sha256':sha(build/'timeline.json')}))
        with patch('jianying_studio.quality.probe',return_value=self.source()):r=inspect(p,root,build=build)
        self.assertNotIn('native-effects',[x['code'] for x in r['errors']])
        self.assertIn('native-beauty-bindings-and-effect-coverage',[x['code'] for x in r['checks']])

    def test_rejected_low_caption_position_fails(self):
        root,p=fixture();p['style']=load(Path(__file__).parents[1]/'presets/口播清晰自然.json')
        p['tracks'][2]['segments'][0]['y']=-.8
        with patch('jianying_studio.quality.probe',return_value=self.source()):r=inspect(p,root)
        self.assertIn('caption-fixed-position',[x['code'] for x in r['errors']])

    def test_donor_caption_position_passes_position_gate(self):
        root,p=fixture();p['style']=load(Path(__file__).parents[1]/'presets/口播清晰自然.json')
        p['tracks'][2]['segments'][0]['y']=-0.551507430997877
        with patch('jianying_studio.quality.probe',return_value=self.source()):r=inspect(p,root)
        self.assertNotIn('caption-fixed-position',[x['code'] for x in r['errors']])
        self.assertIn('caption-fixed-position',[x['code'] for x in r['checks']])

    def test_caption_animation_cannot_hide_a_later_low_position(self):
        root,p=fixture();p['style']=load(Path(__file__).parents[1]/'presets/口播清晰自然.json')
        s=p['tracks'][2]['segments'][0];s['y']=-0.551507430997877
        s['keyframes']={'y':[{'at_us':0,'value':s['y']},{'at_us':500000,'value':-.8}]}
        with patch('jianying_studio.quality.probe',return_value=self.source()):r=inspect(p,root)
        self.assertIn('caption-fixed-position',[x['code'] for x in r['errors']])

    def source(self):
        return {'streams':[{'codec_type':'video','width':1080,'height':1920,'duration':'10'},
                           {'codec_type':'audio','duration':'10'}], 'format':{'duration':'10'}}

    def test_stale_audio_measurement_rejected(self):
        root,p=fixture()
        with patch('jianying_studio.quality.probe',return_value=self.source()):
            r=inspect(p,root,audio_report={'project_sha256':'wrong'})
        self.assertIn('stale-audio-audit',[x['code'] for x in r['errors']])

    def test_source_trim_past_media_rejected(self):
        root,p=fixture();p['tracks'][0]['segments'][0]['source_start_us']=9000000
        with patch('jianying_studio.quality.probe',return_value=self.source()):r=inspect(p,root)
        self.assertIn('source-trim-outside-media',[x['code'] for x in r['errors']])

    def test_explicit_multiline_caption_fails(self):
        root,p=fixture();p['tracks'][2]['segments'][0]['text']='第一行\n第二行'
        with patch('jianying_studio.quality.probe',return_value=self.source()):r=inspect(p,root)
        self.assertIn('multiline-caption',[x['code'] for x in r['errors']])

    def test_clipping_mix_fails_gate(self):
        root,p=fixture()
        a={'project_sha256':project_digest(p),'reference':'test-reference','cut_boundaries':[],
           'measurements':{'mix':{'true_peak_dbtp':.2},'voice':{'integrated_lufs':-16},'music':{'integrated_lufs':-30}}}
        with patch('jianying_studio.quality.probe',return_value=self.source()):r=inspect(p,root,audio_report=a)
        self.assertIn('mix-headroom',[x['code'] for x in r['errors']])

    def test_missing_native_beauty_is_not_hidden_by_valid_parameters(self):
        root,p=fixture();p['style']=load(Path(__file__).parents[1]/'presets/口播清晰自然.json')
        build=root/'fake-build';build.mkdir()
        timeline={'tracks':[{'segments':[{'material_id':'video','extra_material_refs':[]}]}],
                  'materials':{'videos':[{'id':'video','type':'video'}]}}
        (build/'project.json').write_text(json.dumps(p));(build/'timeline.json').write_text(json.dumps(timeline))
        (build/'build.json').write_text(json.dumps({'timeline_sha256':sha(build/'timeline.json')}))
        with patch('jianying_studio.quality.probe',return_value=self.source()):r=inspect(p,root,build=build)
        self.assertIn('native-effects',[x['code'] for x in r['errors']])

    def test_refine_never_changes_cuts_or_text(self):
        root,p=fixture()
        report={'project_sha256':project_digest(p),'measurements':{'voice':{'integrated_lufs':-10,'true_peak_dbtp':0}},
                'voice_clips':[{'segment':0,'rms_dbfs':-12}]}
        revised,changes=refine(p,report)
        before=deepcopy(p['tracks'][0]);after=deepcopy(revised['tracks'][0])
        before['segments'][0].pop('volume',None);after['segments'][0].pop('volume',None)
        self.assertEqual(before,after);self.assertEqual(p['tracks'][2],revised['tracks'][2])
        music=revised['tracks'][1]['segments'][0]
        self.assertEqual(gain_at(music,0),0);self.assertEqual(gain_at(music,4000000),0)
        self.assertFalse(changes['cuts_changed'])

    def test_quiet_tail_is_not_a_claim_of_complete_words(self):
        result=tail_metrics([.1]*48000+[0]*9600)
        self.assertEqual(result['quiet_tail_ms'],200)
        self.assertEqual(result['semantic_completion'],'not-established-by-silence')


@unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'),'ffmpeg required')
class AudioReferenceRegressionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root=Path(__file__).parent/'artifacts'/('audio-qa-'+uuid.uuid4().hex);cls.root.mkdir(parents=True)
        video=cls.root/'tone.mp4';image=cls.root/'cover.png'
        subprocess.run(['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-n','-f','lavfi','-i','color=c=black:s=160x90:r=30',
                        '-f','lavfi','-i','sine=frequency=440:sample_rate=48000','-t','4','-c:v','libx264','-threads','2',
                        '-c:a','aac',str(video)],check=True,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        def chunk(t,d):return struct.pack('!I',len(d))+t+d+struct.pack('!I',zlib.crc32(t+d)&0xffffffff)
        image.write_bytes(b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('!IIBBBBB',2,2,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(bytes(14)))+chunk(b'IEND',b''))
        assets={k:{'path':f.name,'kind':k,'size':f.stat().st_size,'sha256':sha(f)} for k,f in [('video',video),('image',image)]}
        cls.project={'schema':'jianying-studio-project/v1','name':'延迟混音回归','canvas':{'width':1080,'height':1920,'fps':30},
                     'assets':assets,'style':load(Path(__file__).parents[1]/'presets/基础无效果.json'),
                     'tracks':[{'type':'video','segments':[{'asset':'image','duration_us':33333,'volume':0},
                        {'asset':'video','start_us':33333,'duration_us':1000000,'source_start_us':200000,'source_duration_us':1050000,'speed':1.05},
                        {'asset':'video','start_us':1033333,'duration_us':1000000,'source_start_us':2200000,'source_duration_us':1050000,'speed':1.05}]}]}

    def test_delayed_retimed_multi_clip_output_is_bounded_and_audible(self):
        from jianying_studio.audio_quality import pcm,RATE
        output=self.root/'voice.wav';render_reference(self.project,self.root,output,'voice')
        self.assertLess(output.stat().st_size,900000)
        samples=pcm(output);self.assertAlmostEqual(len(samples)/RATE,2.033333,delta=1/RATE)
        self.assertLess(max(abs(v) for v in samples[:1400]),.001)
        self.assertGreater(max(abs(v) for v in samples[4800:48000]),.05)
        self.assertGreater(max(abs(v) for v in samples[60000:90000]),.05)

    def test_even_filter_failure_cannot_write_unbounded_data(self):
        import jianying_studio.audio_quality as aq
        args=[]
        def capture(command,**kw):args.extend(command);raise ValueError('simulated filter failure')
        with patch.object(aq,'run',side_effect=capture):
            with self.assertRaises(ValueError):render_reference(self.project,self.root,self.root/'failure.wav','voice')
        self.assertIn('-fs',args);self.assertLess(int(args[args.index('-fs')+1]),900000)
        self.assertEqual(args[args.index('-t')+1],'2.033333')
        self.assertNotIn(',apad,',args[args.index('-filter_complex')+1])


if __name__=='__main__':unittest.main()
