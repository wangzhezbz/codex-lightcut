from copy import deepcopy
import hashlib,io,json
from pathlib import Path
import sys,unittest,uuid,zipfile
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from jianying_studio import windows_resource_prepare as r, windows_effect_resources as local, windows_style_setup as setup
from jianying_studio import release, onboarding
from jianying_studio.storage import load,save,manifest


class ResourcePreparationTests(unittest.TestCase):
    def setUp(self):
        self.root=Path(__file__).parent/'artifacts'/('resources-'+uuid.uuid4().hex);self.root.mkdir(parents=True)
        self.cache=self.root/'editor-cache';self.cache.mkdir()
        self.app=self.root/'app';self.app.mkdir()
        self.private=self.root/'private'
        self.catalog,self.downloads=r.catalogs()
        self.runtime={'app_version':self.catalog['app_version'],'library_sha256':self.catalog['library_sha256']}
        self.payload={}
        self.archives={}
        for key,spec in self.catalog['resources'].items():
            fixture=self.root/'fixtures'/key;save(fixture/'config.json',{'effect':{'Link':[{'path':'content'}]}})
            (fixture/'content').mkdir();(fixture/'content/data.txt').write_text('fixture effect control')
            spec['files']=manifest(fixture);spec['semantic_tokens']={'content/data.txt':['fixture effect control']}
            stream=io.BytesIO()
            with zipfile.ZipFile(stream,'w') as z:
                for file in fixture.rglob('*'):
                    if file.is_file():z.write(file,file.relative_to(fixture).as_posix())
            self.payload[key]=stream.getvalue()
            self.archives[key]={'archive_sha256':hashlib.sha256(self.payload[key]).hexdigest(),
                                'files':spec['files'],'omitted_metadata':[]}
            if key in self.downloads['resources']:
                self.downloads['resources'][key]['sdk_model']=[]
                self.archives[key]['archive_md5']=self.downloads['resources'][key]['md5']
        for target,value in [('host','windows'),('runtime_context',(self.runtime,[self.app])),('cache_roots',[self.cache]),
                             ('catalogs',(self.catalog,self.downloads))]:
            p=patch.object(r,target,return_value=value);p.start();self.addCleanup(p.stop)
        p=patch.object(r,'archive_spec',side_effect=lambda key:self.archives[key]);p.start();self.addCleanup(p.stop)
        self.install('adjust',self.app/'Resources')

    def install(self,key,root):
        dest=root/self.catalog['resources'][key]['relative']
        r.extract_checked(self.payload[key],dest,self.catalog['resources'][key]);return dest

    def fake_download(self,key,spec,identity,runtime,root):
        folder=Path(root)/key/uuid.uuid4().hex
        r.extract_checked(self.payload[key],folder/'package',spec)
        record={'schema':'lightcut-windows-beauty-download/v1','key':key,'identity':identity,'runtime':runtime,
          'package':str(folder/'package'),'catalog_sha256':local.CATALOG_SHA256,'download_catalog_sha256':r.PIN,
          'archive_catalog_sha256':r.ARCHIVES_PIN,'archive_sha256':self.archives[key]['archive_sha256'],
          'business':{'is_vip':False,'paid_type':'free','is_expired':False},
          'entitlement_basis':'not-asserted-editor-enforces-official-policy'}
        save(folder/'resource.json',record);return folder/'package',folder/'resource.json'

    def test_cold_prepare_then_warm_reuse_and_verify(self):
        before=manifest(self.cache)
        with patch.object(r,'download',side_effect=self.fake_download) as download:
            record=r.prepare('beauty-adjustment',root=self.private,allow_download=True,ignore_effect_cache=True)
            self.assertEqual(record['status'],'ready-for-build');self.assertEqual(download.call_count,7)
            self.assertEqual(r.verify(record),record)
        with patch.object(r,'download') as download:
            again=r.prepare('beauty-adjustment',root=self.private)
            self.assertEqual(again['status'],'ready-for-build');self.assertEqual(again['downloads'],0);download.assert_not_called()
        self.assertEqual(manifest(self.cache),before)

    def test_offline_missing_reports_each_selected_resource_without_writes(self):
        with patch.object(r,'download') as download:
            result=r.prepare('beauty',root=self.private)
        self.assertEqual(len(result['blockers']),7);download.assert_not_called();self.assertFalse(self.private.exists())

    def test_adjustment_only_needs_no_beauty_or_models(self):
        with patch.object(r,'download') as download,patch.object(r,'model_inventory') as models:
            result=r.prepare('adjustment',root=self.private,allow_download=True)
        self.assertEqual(result['status'],'ready-for-build');self.assertEqual(set(result['bindings']),{'adjust'})
        download.assert_not_called();models.assert_not_called()

    def test_local_valid_resources_do_not_download(self):
        for key in self.downloads['resources']:self.install(key,self.cache)
        with patch.object(r,'download') as download:result=r.prepare('beauty',root=self.private,allow_download=True)
        self.assertEqual(result['status'],'ready-for-build');download.assert_not_called()
        self.assertEqual({s['kind'] for s in result['sources'].values()},{'editor-cache'})

    def test_managed_private_resources_win_when_editor_cache_also_exists(self):
        for key in self.downloads['resources']:self.install(key,self.cache)
        with patch.object(r,'download',side_effect=self.fake_download):
            cold=r.prepare('beauty-adjustment',root=self.private,allow_download=True,ignore_effect_cache=True)
        before_cache=manifest(self.cache);before_private=manifest(self.private)
        with patch.object(r,'download') as download:
            actual=r.prepare('beauty-adjustment',root=self.private,allow_download=True)
        download.assert_not_called();self.assertEqual(actual['status'],'ready-for-build')
        self.assertEqual(actual['bindings'],cold['bindings']);self.assertEqual(actual['sources'],cold['sources'])
        r.verify(actual)
        self.assertEqual(manifest(self.cache),before_cache);self.assertEqual(manifest(self.private),before_private)

    def test_corrupt_private_package_falls_back_only_to_valid_editor_cache(self):
        for key in self.downloads['resources']:self.install(key,self.cache)
        with patch.object(r,'download',side_effect=self.fake_download):
            cold=r.prepare('beauty',root=self.private,allow_download=True,ignore_effect_cache=True)
        (Path(cold['bindings']['smooth'])/'content/data.txt').write_text('changed')
        with patch.object(r,'download') as download:
            actual=r.prepare('beauty',root=self.private,allow_download=True)
        download.assert_not_called();self.assertEqual(actual['status'],'ready-for-build')
        self.assertEqual(actual['sources']['smooth']['kind'],'editor-cache')
        self.assertEqual(sum(v['kind']=='private-download' for v in actual['sources'].values()),6)
        r.verify(actual)
        (self.cache/self.catalog['resources']['smooth']['relative']/'content/data.txt').write_text('also changed')
        with patch.object(r,'download') as download:
            failed=r.prepare('beauty',root=self.private,allow_download=True)
        download.assert_not_called();self.assertEqual(failed['status'],'needs-attention')
        self.assertNotIn('smooth',failed['bindings'])

    def test_managed_style_profile_preserves_private_resource_bindings(self):
        for key in self.downloads['resources']:self.install(key,self.cache)
        with patch.object(r,'download',side_effect=self.fake_download):
            cold=r.prepare('beauty-adjustment',root=self.private,allow_download=True,ignore_effect_cache=True)
        style=load(onboarding.DEFAULT_STYLE);style['subtitle_shadow']=False;style['filter']['enabled']=False
        with patch.object(release,'host',return_value='windows'),patch.object(setup,'host',return_value='windows'), \
             patch.object(r,'private_root',return_value=self.private), \
             patch.object(onboarding,'prepare',return_value=({'status':'ready-for-build','runtime':self.runtime,'blockers':[]},None)), \
             patch.object(r,'download') as download:
            report,profile=release.prepare(style,allow_download=True)
        download.assert_not_called();self.assertEqual(report['status'],'ready-for-build')
        self.assertEqual(profile['bindings'],cold['bindings'])
        self.assertEqual(profile['effects_record']['sources'],cold['sources'])

    def test_corrupt_local_resource_not_silently_replaced(self):
        for key in self.downloads['resources']:self.install(key,self.cache)
        (self.cache/self.catalog['resources']['smooth']['relative']/'content/data.txt').write_text('bad')
        with patch.object(r,'download') as download:result=r.prepare('beauty',root=self.private,allow_download=True)
        self.assertEqual(result['status'],'needs-attention');download.assert_not_called()
        self.assertEqual(result['blockers'][0]['resource'],'smooth')

    def test_cold_test_ignores_existing_cache_without_deleting_it(self):
        for key in self.downloads['resources']:self.install(key,self.cache)
        before=manifest(self.cache)
        with patch.object(r,'download',side_effect=self.fake_download) as download:
            result=r.prepare('beauty',root=self.private,allow_download=True,ignore_effect_cache=True)
        self.assertEqual(result['downloads'],7);self.assertEqual(manifest(self.cache),before)

    def test_missing_model_blocks_even_when_packages_present(self):
        self.downloads['resources']['smooth']['sdk_model']=['tt_fixture']
        with patch.object(r,'download',side_effect=self.fake_download):result=r.prepare('beauty',root=self.private,allow_download=True)
        self.assertEqual(result['missing_model_mappings'],['tt_fixture']);self.assertEqual(result['status'],'needs-attention')
        self.assertEqual(len(result['bindings']),7)

    def test_models_verified_and_tampering_rejected(self):
        self.downloads['resources']['smooth']['sdk_model']=['tt_fixture']
        model=self.app/'Resources/models/test/tt_fixture_v1.model';model.parent.mkdir(parents=True);model.write_bytes(b'fixture')
        with patch.object(r,'download',side_effect=self.fake_download):record=r.prepare('beauty',root=self.private,allow_download=True)
        self.assertEqual(record['status'],'ready-for-build');r.verify(record)
        model.write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'model changed'):r.verify(record)

    def test_extra_model_does_not_satisfy_base_model(self):
        path=self.root/'tt_face_extra_v1.model';path.write_bytes(b'fixture')
        models,missing=r.models_for({'tt_face','tt_face_extra'},[path])
        self.assertEqual(missing,['tt_face']);self.assertEqual([m['sdk_model'] for m in models],['tt_face_extra'])

    def test_receipt_escape_and_effect_tampering_rejected(self):
        with patch.object(r,'download',side_effect=self.fake_download):record=r.prepare('beauty',root=self.private,allow_download=True)
        changed=deepcopy(record);changed['bindings']['smooth']=str(self.root/'other')
        with self.assertRaises(ValueError):r.verify(changed)
        (Path(record['bindings']['smooth'])/'content/data.txt').write_text('changed')
        with self.assertRaises(ValueError):r.verify(record)

    def test_unknown_runtime_stops_before_network(self):
        self.runtime['app_version']='12.0'
        with patch.object(r,'download') as download:
            with self.assertRaises(ValueError):r.prepare('beauty',allow_download=True)
        download.assert_not_called()

    def test_archive_traversal_extra_file_and_collision_rejected_before_write(self):
        for names in (['../outside'],['content/data.txt','CONTENT/data.txt'],['config.json','extra']):
            stream=io.BytesIO()
            with zipfile.ZipFile(stream,'w') as z:
                for name in names:z.writestr(name,'fixture')
            dest=self.root/uuid.uuid4().hex
            with self.assertRaises(ValueError):r.extract_checked(stream.getvalue(),dest,self.catalog['resources']['smooth'])
            self.assertFalse(dest.exists())

    def metadata_archive(self):
        spec=self.catalog['resources']['smooth'];stream=io.BytesIO()
        with zipfile.ZipFile(io.BytesIO(self.payload['smooth'])) as original,zipfile.ZipFile(stream,'w') as z:
            for name in spec['files']:z.writestr(name,original.read(name))
            z.writestr('__MACOSX/._config.json',b'fixture metadata');z.writestr('.DS_Store',b'fixture metadata')
        payload=stream.getvalue()
        with zipfile.ZipFile(io.BytesIO(payload)) as z:
            files={n:{'size':len(z.read(n)),'sha256':hashlib.sha256(z.read(n)).hexdigest()} for n in z.namelist()}
        reviewed={'archive_sha256':hashlib.sha256(payload).hexdigest(),'archive_md5':hashlib.md5(payload).hexdigest(),
                  'files':files,'omitted_metadata':['__MACOSX/._config.json','.DS_Store']}
        return payload,spec,reviewed

    def test_exact_reviewed_metadata_is_not_extracted(self):
        payload,spec,reviewed=self.metadata_archive();out=self.root/'selected'
        r.extract_checked(payload,out,spec,reviewed_archive=reviewed)
        self.assertEqual(manifest(out),spec['files']);self.assertFalse((out/'__MACOSX').exists())
        self.assertEqual(r.extract_checked(payload,None,spec,reviewed_archive=reviewed),reviewed['files'])

    def test_changed_or_unreviewed_metadata_is_not_ignored(self):
        payload,spec,reviewed=self.metadata_archive()
        for mode in ('zip-sha','file-sha','allowlist'):
            altered=deepcopy(reviewed)
            if mode=='zip-sha':altered['archive_sha256']='0'*64
            elif mode=='file-sha':altered['files']['.DS_Store']['sha256']='0'*64
            else:altered['omitted_metadata'].append('config.json')
            out=self.root/mode
            with self.assertRaises(ValueError):r.extract_checked(payload,out,spec,reviewed_archive=altered)
            self.assertFalse(out.exists())

    def test_actual_download_path_with_reviewed_metadata_and_receipt(self):
        payload,spec,reviewed=self.metadata_archive();self.archives['smooth']=reviewed
        identity=deepcopy(self.downloads['resources']['smooth']);identity['md5']=reviewed['archive_md5']
        from unittest.mock import Mock
        opener=Mock();opener.open.return_value=io.BytesIO(payload)
        business={'is_vip':True,'paid_type':'subscribe','is_expired':False}
        with patch.object(r,'metadata',return_value=('https://p6-artist-file-sign.byteimg.com/item',business,'a'*64)), \
             patch.object(r,'build_opener',return_value=opener):
            package,receipt=r.download('smooth',spec,identity,self.runtime,self.private)
        self.assertEqual(r.verify_download(receipt,'smooth',spec,identity,self.runtime),package)
        self.assertEqual(load(receipt)['business'],business)

    def test_reviewed_cdn_hosts_and_redirects(self):
        good=['https://p6-artist-file-sign.byteimg.com/item','https://p26-artist-file-sign.byteimg.com/item',
              'https://lf26-faceu-file-sign.bytecdn.com/item']
        bad=['http://p6-artist-file-sign.byteimg.com/item','https://arbitrary.byteimg.com/item',
             'https://p6-artist-file-sign.byteimg.com.evil.test/item','https://byteimg.com/item',
             'https://x@p6-artist-file-sign.byteimg.com/item','https://p6-artist-file-sign.byteimg.com:444/item']
        from urllib.request import Request
        req=Request(good[0])
        for url in good:
            self.assertTrue(r.beauty_url_allowed(url))
            self.assertEqual(r.BeautyRedirect().redirect_request(req,None,302,'',{},url).full_url,url)
        for url in bad:
            self.assertFalse(r.beauty_url_allowed(url))
            with self.assertRaises(ValueError):r.BeautyRedirect().redirect_request(req,None,302,'',{},url)

    def test_policy_preserved_and_changed_identity_refused(self):
        spec=self.downloads['resources']['smooth'];attr=deepcopy(spec)
        attr['business_info']={'json_str':json.dumps({'is_vip':True,'paid_type':'subscribe','is_expired':False})}
        self.assertEqual(r.policy(attr,spec),{'is_vip':True,'paid_type':'subscribe','is_expired':False})
        for key,value in [('sdk_model',['unknown']),('effect_id','unknown'),('md5','0'*32)]:
            changed=deepcopy(attr);changed[key]=value
            with self.assertRaises(ValueError):r.policy(changed,spec)
        attr['business_info']['json_str']=json.dumps({'is_vip':True,'paid_type':'subscribe','is_expired':True})
        with self.assertRaises(ValueError):r.policy(attr,spec)

    def test_wrong_platform_cannot_download(self):
        with patch.object(r,'host',return_value='macos'),patch.object(r,'metadata') as metadata:
            with self.assertRaises(ValueError):r.download('x',{}, {},{},self.private)
        metadata.assert_not_called()

    def test_profile_verifier_uses_prepared_resources(self):
        with patch.object(r,'download',side_effect=self.fake_download):record=r.prepare('beauty-adjustment',root=self.private,allow_download=True)
        style=load(onboarding.DEFAULT_STYLE);style['subtitle_shadow']=False;style['filter']['enabled']=False
        from jianying_studio.preferences import digest
        profile={'schema':setup.SCHEMA,'style_sha256':digest(style),'scope':'beauty-adjustment','runtime':self.runtime,
                 'bindings':record['bindings'],'effects_record':record,'filter_record':None}
        with patch.object(setup,'host',return_value='windows'),patch.object(onboarding,'runtime_context',return_value=(self.runtime,[self.app])):
            self.assertEqual(setup.verify_profile(profile,style),profile)


class UnifiedReleaseTests(unittest.TestCase):
    def test_windows_recommendation_is_disclosed_without_changing_saved_choices(self):
        from jianying_studio import preferences as p
        root=Path(__file__).parent/'artifacts'/('defaults-'+uuid.uuid4().hex)
        choices=p.recommendations();choices['effects']['subtitle_shadow']=True;choices['cover']['mode']='none'
        state=p.start(root);state=p.update(state['session'],state['revision'],choices)
        p.confirm(state['session'],state['revision'],scope='defaults')
        with patch.object(p.sys,'platform','win32'):
            catalog=p.catalog();saved=p.start(root)
        self.assertFalse(catalog['recommended']['effects']['subtitle_shadow'])
        self.assertIn('不含',catalog['platform_notice'])
        self.assertTrue(p.read(saved['session'])['choices']['effects']['subtitle_shadow'])

    def test_windows_routes_selected_resources_without_changing_style(self):
        style=load(onboarding.DEFAULT_STYLE);style['subtitle_shadow']=False;before=deepcopy(style)
        with patch.object(release,'host',return_value='windows'),patch.object(setup,'prepare',return_value=({'status':'ready-for-build'},None)) as prepare:
            release.prepare(style,allow_download=True)
        prepare.assert_called_once_with(style,allow_download=True,managed_resources=True);self.assertEqual(style,before)

    def test_windows_shadow_remains_selected_and_blocks_before_network(self):
        style=load(onboarding.DEFAULT_STYLE)
        with patch.object(release,'host',return_value='windows'),patch.object(setup,'prepare') as prepare:
            report,profile=release.prepare(style,allow_download=True)
        self.assertEqual(report['status'],'needs-attention');self.assertTrue(style['subtitle_shadow']);prepare.assert_not_called()

    def test_mac_keeps_existing_adapter(self):
        style=load(onboarding.DEFAULT_STYLE)
        with patch.object(release,'host',return_value='macos'),patch.object(onboarding,'prepare',return_value=({'status':'ready-for-build'},None)) as prepare:
            release.prepare(style)
        prepare.assert_called_once_with(style=style)


if __name__=='__main__':unittest.main()
