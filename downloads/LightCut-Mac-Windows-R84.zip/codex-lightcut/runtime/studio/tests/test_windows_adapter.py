from pathlib import Path
from copy import deepcopy
import contextlib,io,sys,unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from jianying_studio import cli,native_backend,windows_backend
from jianying_studio.storage import load
from test_portable import fixture

class WindowsAdapterTests(unittest.TestCase):
    def test_requested_beauty_is_rejected_not_dropped(self):
        root,p=fixture();p['style']=load(Path(__file__).parents[1]/'presets/口播清晰自然.json')
        original=deepcopy(p)
        with self.assertRaisesRegex(ValueError,'not silently removed'):windows_backend.check_supported(p)
        self.assertEqual(p,original)

    def test_windows_routes_to_isolated_adapter(self):
        with patch.object(native_backend,'host',return_value='windows'):
            self.assertIs(native_backend.current(),windows_backend)

    def test_failed_readonly_doctor_exits_nonzero(self):
        with patch.object(cli,'host',return_value='windows'),patch.object(cli,'diagnose',return_value={}), \
             patch.object(windows_backend,'doctor',return_value={'checks':[{'ok':False}]}),contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(cli.main(['doctor','--native']),2)

    def test_successful_readonly_doctor(self):
        with patch.object(cli,'host',return_value='windows'),patch.object(cli,'diagnose',return_value={}), \
             patch.object(windows_backend,'doctor',return_value={'checks':[{'ok':True}]}),contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(cli.main(['doctor','--native']),0)

if __name__=='__main__':unittest.main()
