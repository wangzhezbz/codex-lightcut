"""Regression coverage: custom install without InstallLocation must be found.

Only the read-only OS registry boundary is faked; discovery/pin checks stay real.
Fixtures are retained under results; no cleanup or recursive deletion.
"""
import os
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from jianying_studio import onboarding as o


class Key:
    def __init__(self, data): self.data = data
    def __enter__(self): return self
    def __exit__(self, *args): pass


def registry(entries):
    def open_key(parent, path, *args):
        if isinstance(parent, Key): return Key(parent.data[int(path)])
        return Key(entries)
    def query(key, name):
        if name not in key.data: raise FileNotFoundError(name)
        return key.data[name], 1
    return types.SimpleNamespace(HKEY_CURRENT_USER=1, HKEY_LOCAL_MACHINE=2,
        KEY_WOW64_64KEY=256, KEY_WOW64_32KEY=512, KEY_READ=131097,
        OpenKey=open_key, QueryInfoKey=lambda key: (len(key.data), 0, 0),
        EnumKey=lambda key, i: str(i), QueryValueEx=query)


class WindowsDiscoveryTests(unittest.TestCase):
    def hints(self, entries):
        with patch.object(o.sys, 'platform', 'win32'), patch.dict(sys.modules, {'winreg': registry(entries)}):
            return o.windows_install_hints()

    def test_display_icon_fallback_when_install_location_missing(self):
        self.assertEqual(self.hints([{'DisplayName': '剪映专业版', 'DisplayIcon': r'D:\Apps Space\剪映\uninst.exe'}]),
                         [Path(r'D:\Apps Space\剪映')])

    def test_quoted_icon_and_resource_index(self):
        self.assertEqual(self.hints([{'DisplayName': 'JianyingPro', 'InstallLocation': '',
            'DisplayIcon': '"D:\\Apps Space\\剪映\\JianyingPro.exe",-2'}]), [Path(r'D:\Apps Space\剪映')])

    def test_install_location_remains_available_and_deduplicated(self):
        self.assertEqual(self.hints([{'DisplayName': '剪映', 'InstallLocation': r'D:\Apps\剪映',
                                     'DisplayIcon': r'D:\Apps\剪映\uninst.exe'}]), [Path(r'D:\Apps\剪映')])

    def test_other_apps_are_ignored(self):
        self.assertEqual(self.hints([{'DisplayName': 'Other editor', 'DisplayIcon': r'D:\Other\uninst.exe'}]), [])

    def test_icon_must_be_local_absolute_executable_not_command_or_network(self):
        for icon in ('relative.exe', r'\\server\share\editor.exe', 'https://example.invalid/editor.exe',
                     r'D:\Apps\editor.exe --unsafe', r'D:\Apps\icon.dll,0'):
            with self.subTest(icon=icon):
                self.assertEqual(self.hints([{'DisplayName': '剪映', 'DisplayIcon': icon}]), [])

    def test_environment_variable_in_icon_is_expanded(self):
        with patch.dict(os.environ, {'LIGHTCUT_TEST_INSTALL': r'D:\Portable\剪映'}):
            self.assertEqual(self.hints([{'DisplayName': '剪映', 'DisplayIcon': r'%LIGHTCUT_TEST_INSTALL%\uninst.exe'}]),
                             [Path(r'D:\Portable\剪映')])

    def test_explicit_unreviewed_installation_not_replaced_by_a_reviewed_one(self):
        from jianying_studio import windows_backend
        wp = types.SimpleNamespace(inspect=lambda p: (_ for _ in ()).throw(ValueError('explicit path rejected')))
        with patch.dict(os.environ, {'JY14_APP_BUNDLE': r'D:\Explicit\11.5.0.14471'}), \
             patch.dict(sys.modules, {'windows_platform': wp}), patch.object(windows_backend, '_imports'):
            with self.assertRaisesRegex(ValueError, 'explicit path rejected'):
                o.discover_windows_installation()


if __name__ == '__main__': unittest.main(verbosity=2)
