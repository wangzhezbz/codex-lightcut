from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import sys,unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from jianying_studio import windows_effect_registration as r
from jianying_studio.storage import load,save,manifest
from onboarding_fixtures import fixture

class RegistrationTests(unittest.TestCase):
    def prepared(self):
        root,_=fixture();(root/'draft').mkdir();save(root/'draft/content.json',{'test':True})
        record={'schema':r.effects.SCHEMA,'scope':'beauty-adjustment','name':'Windows美颜调色分项测试',
                'full_default_style':False,'files':{'portable/key':{}},'live_written':False,'registration_supported':False}
        save(root/'build.json',record);return root,record

    def test_native_manifest_conversion_keeps_frozen_record(self):
        root,record=self.prepared();j=SimpleNamespace(files_manifest=lambda path:{'native\\key':{}})
        with patch.object(r.effects,'verify'),patch.object(r.basic,'engine',return_value=j):out=r.publication_record(root)
        self.assertEqual(out['files'],{'native\\key':{}});self.assertEqual(load(root/'build.json'),record)

    def test_non_windows_never_checks_or_publishes(self):
        with patch('jianying_studio.platforms.host',return_value='macos'),patch.object(r,'publication_record') as read:
            with self.assertRaisesRegex(ValueError,'必须在 Windows'):r.register('x','y')
            read.assert_not_called()

    def test_editor_running_waits_without_publish(self):
        with patch('jianying_studio.platforms.host',return_value='windows'),patch.object(r,'publication_record'), \
             patch.object(r.basic,'process_pids',return_value=[99]),patch.object(r.basic,'engine') as engine:
            result=r.register('x','y')
            self.assertEqual(result['status'],'waiting-for-editor-to-close');self.assertFalse(result['live_written']);engine.assert_not_called()

    def test_explicit_path_uses_existing_transaction_with_both_verifiers(self):
        from unittest.mock import Mock
        j=SimpleNamespace(publish=Mock(return_value={'status':'created'}))
        with patch('jianying_studio.platforms.host',return_value='windows'),patch.object(r,'publication_record') as verifier, \
             patch.object(r.basic,'process_pids',return_value=[]),patch.object(r.basic,'engine',return_value=j):
            result=r.register('x','y')
        self.assertFalse(result['full_default_style']);self.assertIs(j.publish.call_args.kwargs['verify_build_fn'],verifier)
        self.assertIs(j.publish.call_args.kwargs['verify_live_fn'],r.verify_live)

    def test_live_registration_checks_bytes_index_and_analysis_directory(self):
        import shutil
        root,record=self.prepared();draftroot=root/'live';target=draftroot/'test';shutil.copytree(root/'draft',target)
        record.update(target=str(target),draft_id='test-id',files=manifest(target))
        save(draftroot/'root_meta_info.json',{'all_draft_store':[{'draft_id':'test-id','draft_fold_path':str(target)}]})
        save(root/'timeline.json',{'materials':{'videos':[{'id':'v','type':'video'}]},
                                  'tracks':[{'type':'video','segments':[{'material_id':'v'}]}]})
        j=SimpleNamespace(files_manifest=manifest,nd=SimpleNamespace(DRAFT_ROOT=draftroot),
                          plat=SimpleNamespace(same_draft_path=lambda a,b:Path(a)==Path(b)))
        with patch.object(r,'publication_record',return_value=record),patch.object(r.basic,'engine',return_value=j):
            with self.assertRaisesRegex(ValueError,'analysis directory missing'):r.verify_live(root)
            (target/'video/figure_algorithm/v').mkdir(parents=True)
            self.assertTrue(r.verify_live(root)['live_written'])
            save(draftroot/'root_meta_info.json',{'all_draft_store':[]},replace=True)
            with self.assertRaisesRegex(ValueError,'homepage registration'):r.verify_live(root)
            (target/'content.json').write_text('changed')
            with self.assertRaisesRegex(ValueError,'bytes differ'):r.verify_live(root)

    def test_removed_partial_label_rejected(self):
        root,record=self.prepared();record['name']='完整默认风格';save(root/'build.json',record,replace=True)
        with patch.object(r.effects,'verify'),patch.object(r.basic,'engine') as engine:
            with self.assertRaisesRegex(ValueError,'partial-test label'):r.publication_record(root)
            engine.assert_not_called()

if __name__=='__main__':unittest.main()
