from copy import deepcopy
import json
from pathlib import Path
import sys
import unittest
import uuid
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from jianying_studio import windows_effects as w
from jianying_studio.windows_effect_resources import validate_package
from jianying_studio.storage import manifest


def base():
    mats = {'videos': [{'id': 'cover', 'type': 'photo'}, {'id': 'one', 'type': 'video'},
                      {'id': 'tail', 'type': 'photo'}, {'id': 'two', 'type': 'video'}],
            'effects': [], 'texts': [{'id': 'caption', 'content': 'unchanged', 'font_size': 15}]}
    segs = [{'id': f's{i}', 'material_id': owner, 'target_timerange': {'start': start, 'duration': span},
             'extra_material_refs': [], 'volume': 5.6234130859375 if owner in ('one', 'two') else 0,
             'track_render_index': 0} for i, (owner, start, span) in enumerate(
                 [('cover', 0, 1), ('one', 1, 5), ('tail', 6, 1), ('two', 7, 5)])]
    return {'id': 'timeline', 'duration': 12, 'materials': mats,
            'tracks': [{'id': 'video-track', 'type': 'video', 'segments': segs},
                       {'id': 'music-track', 'type': 'audio', 'segments': [{'id': 'music-segment', 'volume': 1,
                         'target_timerange': {'start': 1, 'duration': 11}}]},
                       {'id': 'text-track', 'type': 'text', 'segments': []}]}


def bindings():
    return {key: 'C:/fixture/' + key for key in ('smooth', 'skin', 'eye', 'face', 'small', 'teeth', 'white', 'adjust')}


class EffectsTests(unittest.TestCase):
    def test_beauty_independent_owners_and_photo_exclusion(self):
        before = base(); after = w.apply(before, 'beauty', bindings())
        self.assertEqual(before, base())
        self.assertEqual(len(after['materials']['effects']), 20)
        refs = [s['extra_material_refs'] for s in after['tracks'][0]['segments']]
        self.assertEqual(refs[0], []); self.assertEqual(refs[2], [])
        self.assertEqual(len(refs[1]), 10); self.assertTrue(set(refs[1]).isdisjoint(refs[3]))
        self.assertEqual(after['tracks'][1:], before['tracks'][1:])
        self.assertEqual(w.verify(before, after, 'beauty', bindings())['video_owners'], 2)

    def test_adjustment_excludes_images_and_keeps_native_units(self):
        before = base(); after = w.apply(before, 'adjustment', bindings())
        self.assertEqual(after['tracks'][:3], before['tracks'])
        self.assertEqual([s['target_timerange'] for s in after['tracks'][3]['segments']],
                         [{'start': 1, 'duration': 5}, {'start': 7, 'duration': 5}])
        self.assertEqual(len(after['materials']['hsl']), 2)
        self.assertEqual(after['materials']['hsl'][0]['saturation'], 12)
        self.assertEqual(after['materials']['hsl'][0]['lightness'], 14)
        self.assertEqual(w.verify(before, after, 'adjustment', bindings())['adjustment_segments'], 2)

    def test_combined_has_both_scopes_without_filter(self):
        before = base(); after = w.apply(before, 'beauty-adjustment', bindings())
        audit = w.verify(before, after, 'beauty-adjustment', bindings())
        self.assertEqual(audit['beauty_nodes'], 20)
        self.assertEqual(audit['adjustment_segments'], 2)
        self.assertFalse(any(t['type'] == 'filter' for t in after['tracks']))

    def test_changed_gain_rejected(self):
        before = base(); after = w.apply(before, 'beauty', bindings()); after['tracks'][1]['segments'][0]['volume'] = .5
        with self.assertRaises(ValueError): w.verify(before, after, 'beauty', bindings())

    def test_changed_beauty_value_rejected(self):
        before = base(); after = w.apply(before, 'beauty', bindings()); after['materials']['effects'][0]['value'] = .99
        with self.assertRaises(ValueError): w.verify(before, after, 'beauty', bindings())

    def test_shared_effect_owner_rejected(self):
        before = base(); after = w.apply(before, 'beauty', bindings())
        after['tracks'][0]['segments'][3]['extra_material_refs'] = after['tracks'][0]['segments'][1]['extra_material_refs']
        with self.assertRaises(ValueError): w.verify(before, after, 'beauty', bindings())

    def test_tinting_cover_rejected(self):
        before = base(); after = w.apply(before, 'adjustment', bindings())
        after['tracks'][-1]['segments'][0]['target_timerange']['start'] = 0
        with self.assertRaises(ValueError): w.verify(before, after, 'adjustment', bindings())

    def test_unknown_scope_missing_binding_and_duplicate_application_rejected(self):
        with self.assertRaises(ValueError): w.apply(base(), 'full-style', bindings())
        with self.assertRaises(ValueError): w.apply(base(), 'beauty', {})
        with self.assertRaises(ValueError): w.apply(w.apply(base(), 'adjustment', bindings()), 'adjustment', bindings())

    def test_same_video_material_shared_by_two_clips_is_rejected(self):
        doc = base(); doc['tracks'][0]['segments'][3]['material_id'] = 'one'
        with self.assertRaises(ValueError): w.apply(doc, 'beauty', bindings())

    def test_hsl_in_wrong_material_bucket_rejected(self):
        before = base(); after = w.apply(before, 'adjustment', bindings())
        after['materials']['effects'].append(after['materials']['hsl'].pop())
        with self.assertRaises(ValueError): w.verify(before, after, 'adjustment', bindings())

    def test_shared_hsl_constant_identity_rejected(self):
        before = base(); after = w.apply(before, 'adjustment', bindings())
        after['materials']['hsl'][1]['constant_material_id'] = after['materials']['hsl'][0]['constant_material_id']
        with self.assertRaises(ValueError): w.verify(before, after, 'adjustment', bindings())

    def test_beauty_in_wrong_material_bucket_rejected(self):
        before = base(); after = w.apply(before, 'beauty', bindings())
        after['materials']['hsl'] = [after['materials']['effects'].pop()]
        with self.assertRaises(ValueError): w.verify(before, after, 'beauty', bindings())

    def test_unexpected_adjustment_track_flags_rejected(self):
        before = base(); after = w.apply(before, 'adjustment', bindings())
        after['tracks'][-1]['flag'] = 0
        with self.assertRaises(ValueError): w.verify(before, after, 'adjustment', bindings())


class ResourceTests(unittest.TestCase):
    def test_windows_binding_rejected_before_runtime_access_on_mac(self):
        from jianying_studio import windows_effect_resources as resources
        with patch('jianying_studio.platforms.host', return_value='macos'), patch.object(resources, 'runtime_context') as runtime:
            with self.assertRaisesRegex(ValueError, '必须在 Windows'):
                resources.bind('beauty')
            runtime.assert_not_called()

    def fixture(self):
        root = ROOT / 'results/test-fixtures' / uuid.uuid4().hex
        root.mkdir(parents=True)
        (root / 'config.json').write_text(json.dumps({'effect': {'Link': [{'path': 'Feature/', 'type': 'AmazingFeature'}]}}))
        (root / 'Feature').mkdir(); (root / 'Feature/control.lua').write_text('face_adjust_Test')
        spec = {'files': manifest(root), 'semantic_tokens': {'Feature/control.lua': ['face_adjust_Test']}}
        return root, spec

    def test_windows_resource_hash_and_semantics_both_required(self):
        root, spec = self.fixture(); validate_package(root, spec)
        (root / 'Feature/control.lua').write_text('wrong control')
        with self.assertRaises(ValueError): validate_package(root, spec)


        spec['files'] = manifest(root)
        with self.assertRaises(ValueError): validate_package(root, spec)

    def test_resource_locator_escape_rejected(self):
        root, spec = self.fixture(); spec['semantic_tokens'] = {'../outside': ['x']}
        with self.assertRaises(ValueError): validate_package(root, spec)

    def test_broken_config_resource_link_rejected(self):
        root, spec = self.fixture()
        (root / 'config.json').write_text(json.dumps({'effect': {'Link': [{'path': 'missing/', 'type': 'AmazingFeature'}]}}))
        spec['files'] = manifest(root)
        with self.assertRaises(ValueError): validate_package(root, spec)


class WriterSafetyTests(unittest.TestCase):
    def test_dotdot_output_alias_inside_source_rejected_before_binding_or_writing(self):
        from jianying_studio import windows_effect_build as writer
        from onboarding_fixtures import fixture
        source, _ = fixture()
        output = source / 'alias/../forbidden-output'
        before = manifest(source)
        with patch.object(writer, 'bind', side_effect=AssertionError('resource binding must not run')):
            with self.assertRaisesRegex(ValueError, 'inside the source'):
                writer.build(source, output, 'beauty')
        self.assertEqual(manifest(source), before)


if __name__ == '__main__': unittest.main(verbosity=2)
