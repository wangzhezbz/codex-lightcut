from copy import deepcopy
from pathlib import Path
import sys,unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from jianying_studio import windows_filter as f
from jianying_studio.windows_filter_resource import validate_metadata

def source():
    return {'id':'timeline','materials':{'videos':[{'id':'cover','type':'photo'},{'id':'v1','type':'video'},{'id':'v2','type':'video'}],
       'effects':[{'id':'beauty','type':'figure','value':.28},{'id':'adjust','type':'brightness','value':-.1}]},
       'tracks':[{'id':'v','type':'video','segments':[
          {'id':'c','material_id':'cover','target_timerange':{'start':0,'duration':1},'extra_material_refs':[]},
          {'id':'a','material_id':'v1','target_timerange':{'start':1,'duration':5},'volume':5.6234130859375,'extra_material_refs':['beauty']},
          {'id':'b','material_id':'v2','target_timerange':{'start':6,'duration':5},'volume':5.6234130859375,'extra_material_refs':[]}]},
        {'id':'audio','type':'audio','segments':[{'id':'m','volume':1}]},
        {'id':'text','type':'text','segments':[{'id':'t','text':'字幕','size':15,'y':-.551507430997877}]},
        {'id':'adj','type':'adjust','segments':[{'id':'adjseg','material_id':'adjust'}]}]}

def metadata(vip=False):
    import json
    return {'id':'7426668776491453707','effect_id':'7426668776491453707','title':'高清增强','effect_type':12,
       'md5':'a'*32,'item_urls':['https://lf.example.bytecdn.com/resource'],
       'business_info':{'json_str':json.dumps({'is_vip':vip,'is_expired':False,'paid_type':'subscribe' if vip else 'free'})},
       'sdk_extra':json.dumps({'setting':{'effect_adjust_params':[{'effect_key':'effects_adjust_filter','min':0,'max':1,'default':1}]}}),
       'sdk_model':['tt_skin_seg']}

class FilterTests(unittest.TestCase):
    def test_twelve_percent_independent_video_segments_preserve_prior_content(self):
        before=source();after=f.apply(before,'C:/isolated/filter')
        self.assertEqual(before,source());self.assertEqual(after['tracks'][:4],before['tracks'])
        track=after['tracks'][-1]
        self.assertEqual(track['type'],'filter')
        self.assertEqual([s['target_timerange'] for s in track['segments']],[{'start':1,'duration':5},{'start':6,'duration':5}])
        added=after['materials']['effects'][2:]
        self.assertEqual([n['value'] for n in added],[.12,.12])
        self.assertEqual(len({n['id'] for n in added}),2)
        self.assertEqual(f.verify(before,after,'C:/isolated/filter')['strength'],.12)

    def test_confirmed_beauty_or_audio_change_rejected(self):
        for kind in ('beauty','audio'):
            before=source();after=f.apply(before,'C:/isolated/filter')
            if kind=='beauty':after['materials']['effects'][0]['value']=.5
            else:after['tracks'][1]['segments'][0]['volume']=.5
            with self.assertRaises(ValueError):f.verify(before,after,'C:/isolated/filter')

    def test_cover_or_wrong_strength_rejected(self):
        before=source();after=f.apply(before,'C:/isolated/filter');after['tracks'][-1]['segments'][0]['target_timerange']['start']=0
        with self.assertRaises(ValueError):f.verify(before,after,'C:/isolated/filter')
        after=f.apply(before,'C:/isolated/filter');after['materials']['effects'][-1]['value']=12
        with self.assertRaises(ValueError):f.verify(before,after,'C:/isolated/filter')

    def test_duplicate_filter_is_not_silently_overwritten(self):
        after=f.apply(source(),'C:/isolated/filter')
        with self.assertRaises(ValueError):f.apply(after,'C:/isolated/filter')

    def test_wrong_identity_rejected(self):
        m=metadata();m['title']='别的滤镜'
        with self.assertRaises(ValueError):validate_metadata(m)

    def test_windows_pro_policy_preserved_and_export_not_authorized(self):
        m=metadata(True)
        with self.assertRaisesRegex(ValueError,'Pro'):validate_metadata(m,'export')
        validated=validate_metadata(m)
        self.assertTrue(validated['is_vip']);self.assertEqual(validated['paid_type'],'subscribe')

    def test_expired_or_unexpected_strength_contract_rejected(self):
        import json
        m=metadata(True);m['business_info']['json_str']=json.dumps({'is_vip':True,'is_expired':True,'paid_type':'subscribe'})
        with self.assertRaises(ValueError):validate_metadata(m)
        m=metadata();m['sdk_extra']=json.dumps({'setting':{'effect_adjust_params':[{'effect_key':'effects_adjust_filter','min':0,'max':100}]}})
        with self.assertRaises(ValueError):validate_metadata(m)

class CloneTests(unittest.TestCase):
    def fixture(self,name):
        import uuid
        root=Path(__file__).resolve().parents[1]/'results/filter-fixtures'/uuid.uuid4().hex
        p=root/'Timelines/T/common_attachment'/name;p.parent.mkdir(parents=True);p.write_text('{}')
        return root

    def test_reviewed_timeline_attachment_is_preserved(self):
        from jianying_studio.windows_filter_build import selected
        root=self.fixture('attachment_id_mapping.json')
        self.assertIn('Timelines/T/common_attachment/attachment_id_mapping.json',selected(root)['files'])

    def test_unknown_nonempty_attachment_is_not_silently_dropped(self):
        from jianying_studio.windows_filter_build import selected
        root=self.fixture('unknown_effect_state.bin')
        with self.assertRaises(ValueError):selected(root)

    def test_draft_owned_path_rebases_timeline_component(self):
        from jianying_studio.windows_filter_build import remap
        ids={'OLD':'NEW'}
        self.assertEqual(remap('C:/old/Timelines/OLD/common_attachment/a',ids,'C:/old','C:/new'),
                         'C:/new/Timelines/NEW/common_attachment/a')
        token='##_draftpath_placeholder_0E685133-18CE-45ED-8CB8-2904A212EC80_##/'
        self.assertEqual(remap(token+'Timelines/OLD/a',ids,'C:/old','C:/new'),token+'Timelines/NEW/a')

class IntegrationGuards(unittest.TestCase):
    def test_wrong_platform_cannot_touch_runtime_network_or_registration(self):
        from unittest.mock import patch
        from jianying_studio import windows_filter_build as b, windows_filter_resource as r
        for module, operation in ((r,lambda:r.fetch('new')), (r,lambda:r.verify('missing')),
                                  (b,lambda:b.build('source','resource','output')), (b,lambda:b.verify('missing')),
                                  (b,lambda:b.register('missing','audit'))):
            with patch.object(module,'host',return_value='macos'), patch.object(module,'runtime_context') as runtime:
                with self.assertRaisesRegex(ValueError,'Windows'):operation()
                runtime.assert_not_called()

    def contract(self):
        return {'schema':'lightcut-windows-official-filter/v1','platform':'windows',
          'identity':{k:metadata()[k] for k in ('id','effect_id','title','effect_type')},
          'parameter':{'key':'effects_adjust_filter','min':0,'max':1,'requested':.12},
          'business':{'is_expired':False,'is_vip':True,'paid_type':'subscribe'},
          'purpose':'native-draft-preview','entitlement_basis':'not-asserted-editor-enforces-official-policy',
          'sdk_model':'tt_skin_seg','models':[{'path':'C:/models/tt_skin_seg.model','size':1,'sha256':'a'*64}],
          'files':{'config.json':{'size':1,'sha256':'b'*64}}}

    def test_resource_contract_cannot_drop_model_identity_or_strength_evidence(self):
        from jianying_studio.windows_filter_resource import record_contract
        record_contract(self.contract())
        for key, value in [('models',[]),('sdk_model','other'),('files',{}),
                           ('parameter',{'key':'effects_adjust_filter','min':0,'max':100,'requested':.12})]:
            with self.assertRaises(ValueError):record_contract(dict(self.contract(),**{key:value}))
        r=self.contract();r['identity']['effect_id']='wrong'
        with self.assertRaises(ValueError):record_contract(r)

    def test_windows_resource_verify_checks_current_package_and_models(self):
        import uuid
        from unittest.mock import patch
        from jianying_studio import windows_filter_resource as r
        from jianying_studio.storage import save,manifest,sha
        root=Path(__file__).resolve().parent/'artifacts'/('filter-contract-'+uuid.uuid4().hex)
        package=root/'package';package.mkdir(parents=True);(package/'config.json').write_text('{}')
        model=root/'tt_skin_seg.model';model.write_bytes(b'model')
        contract=self.contract();contract.update(package=str(package),files=manifest(package),runtime={'runtime_profile':'win-reviewed'},
            models=[{'path':str(model),'size':model.stat().st_size,'sha256':sha(model)}])
        save(root/'resource.json',contract)
        with patch.object(r,'host',return_value='windows'), patch.object(r,'runtime_context',return_value=(contract['runtime'],[])):
            self.assertEqual(r.verify(root/'resource.json'),contract)
            model.write_bytes(b'wrong')
            with self.assertRaisesRegex(ValueError,'dependency changed'):r.verify(root/'resource.json')

    def test_new_cli_keeps_preferences_and_filter_entry_points(self):
        import contextlib,io,json
        from unittest.mock import patch
        from jianying_studio import cli,windows_filter_build as b
        out=io.StringIO()
        with contextlib.redirect_stdout(out):self.assertEqual(cli.main(['preferences-catalog']),0)
        self.assertEqual(len(json.loads(out.getvalue())['cover_styles']),5)
        with patch.object(b,'verify',return_value={'status':'verified'}), contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(cli.main(['windows-filter-verify','--build','candidate']),0)

if __name__=='__main__':unittest.main(verbosity=2)
