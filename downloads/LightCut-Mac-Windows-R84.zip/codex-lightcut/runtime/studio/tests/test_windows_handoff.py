"""Regression cases from the 2026-09-23 Windows handoff; no Windows DLL loaded."""
import contextlib
import importlib.util
import io
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import uuid

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from jianying_studio import cli, windows_probe as probe

class EvidenceTests(unittest.TestCase):
    def setUp(self):
        self.root=Path(__file__).parent/'artifacts'/('win-evidence-'+uuid.uuid4().hex)
        self.install=self.root/'custom-install'/'11.5.0.14471';self.install.mkdir(parents=True)
        (self.install/'JianyingPro.exe').write_bytes(b'FAKE EXE - test data')
        (self.install/'videoeditor.dll').write_bytes(b'FAKE DLL - test data')
        self.selection=SimpleNamespace(directory=self.install.resolve(),version='11.5.0',build='14471',library_sha256='test-hash')
        self.platform=SimpleNamespace(discover_app_bundle=lambda:self.install,inspect=lambda p:self.selection,
            review_status=lambda p:{'reviewed':True},draft_root=lambda:self.root/'custom-drafts',
            EDITOR_IMAGE='JianyingPro.exe',ENGINE_LIBRARY='videoeditor.dll')

    def collect(self,**kw):
        with patch.object(probe.sys,'platform','win32'),patch('jianying_studio.windows_backend._imports'), \
             patch.dict(sys.modules,{'windows_platform':self.platform}), \
             patch.object(probe,'file_version',return_value='11.5.0.14471'):
            return probe.collect(**kw)

    def test_nondefault_install_and_draft_root_use_shared_selection(self):
        r=self.collect();self.assertEqual(r['status'],'complete')
        self.assertEqual(r['selected_installation'],str(self.install.resolve()))
        self.assertEqual(r['draft_root_candidate'],str(self.root/'custom-drafts'))
        self.assertFalse(r['native_library_loaded'])

    def test_empty_selection_is_incomplete(self):
        self.platform.discover_app_bundle=lambda:None
        r=self.collect();self.assertEqual(r['applications'],[]);self.assertEqual(r['status'],'incomplete')

    def test_other_executable_cannot_override_doctor_selection(self):
        other=self.root/'elsewhere';other.mkdir();(other/'JianyingPro.exe').write_bytes(b'FAKE')
        self.assertEqual(self.collect(app_path=other/'JianyingPro.exe')['status'],'incomplete')

    def test_unreviewed_dll_does_not_complete_evidence(self):
        self.platform.review_status=lambda p:{'reviewed':False}
        self.assertEqual(self.collect()['status'],'incomplete')

    def test_install_change_during_collection_fails_closed(self):
        from unittest.mock import Mock
        self.platform.inspect=Mock(side_effect=[self.selection,None])
        self.assertEqual(self.collect()['status'],'incomplete')

    def test_empty_evidence_cli_is_failure_even_if_collector_returns(self):
        with patch.object(probe,'collect',return_value={'status':'incomplete','applications':[]}), \
             patch.object(cli,'save'),contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(cli.main(['windows-evidence','--out','unused.json']),2)

class PilotPreflightTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        path=Path(__file__).resolve().parents[2]/'research/windows-20260923/pilot.py'
        spec=importlib.util.spec_from_file_location('pilot_regression',path)
        cls.pilot=importlib.util.module_from_spec(spec);spec.loader.exec_module(cls.pilot)

    def setUp(self):
        self.doctor={'native_check':{'checks':[{'ok':True}],
            'installation':{'directory':'custom-install','version':'11.5.0','build':'14471','engine_library_sha256':'abc'}}}
        self.evidence={'status':'complete','checks':[{'ok':True}],'selected_installation':'custom-install',
            'applications':[{'version':'11.5.0.14471','libraries':[{'name':'videoeditor.dll','sha256':'abc'}]}]}
        self.validation={'asset_hashes_checked':True}

    def check(self):return self.pilot.preflight_reports(self.doctor,self.evidence,self.validation)

    def test_matching_reports_allow_build(self):self.assertTrue(self.check())
    def test_empty_applications_deny_build(self):
        self.evidence['applications']=[];self.assertFalse(self.check())
    def test_different_dll_deny_build(self):
        self.evidence['applications'][0]['libraries'][0]['sha256']='changed';self.assertFalse(self.check())
    def test_different_selected_directory_denies_build(self):
        self.evidence['selected_installation']='other-install';self.assertFalse(self.check())
    def test_failed_doctor_denies_build(self):
        self.doctor['native_check']['checks']=[{'ok':False}];self.assertFalse(self.check())
    def test_incomplete_evidence_denies_build(self):
        self.evidence['status']='incomplete';self.assertFalse(self.check())

if __name__=='__main__':unittest.main()
