from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import itertools,json,sys,unittest,uuid
from unittest.mock import patch,Mock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from jianying_studio import windows_style_graph as g, windows_style_setup as setup, windows_style_backend as backend
from jianying_studio import windows_backend as basic, onboarding, preferences, delivery
from jianying_studio.storage import load,save,sha,manifest,copy_file
from jianying_studio.audio_quality import project_digest
from jianying_studio.windows_effect_build import mirrors
from onboarding_fixtures import fixture
from test_windows_effects import base,bindings


def style(beauty=True,adjustment=True,filter=True):
    s=load(onboarding.DEFAULT_STYLE);s['subtitle_shadow']=False
    for k,v in [('beauty',beauty),('adjustment',adjustment),('filter',filter)]:s[k]['enabled']=v
    return s

class SelectedGraphTests(unittest.TestCase):
    def test_all_eight_combinations_preserve_base_and_exclude_photos(self):
        for beauty,adjustment,filter in itertools.product((False,True),repeat=3):
            with self.subTest(beauty=beauty,adjustment=adjustment,filter=filter):
                before=base();s=style(beauty,adjustment,filter)
                result=g.apply(before,s,bindings(),'C:/filter')
                report=g.verify(before,result,s,bindings(),'C:/filter')
                self.assertEqual(before,base())
                self.assertEqual(report['beauty_nodes'],20 if beauty else 0)
                self.assertEqual(report['adjustment_segments'],2 if adjustment else 0)
                self.assertEqual(report['filter_segments'],2 if filter else 0)
                self.assertEqual(result['tracks'][1:3],before['tracks'][1:3])

    def test_custom_values_stay_editable_and_do_not_alter_confirmed_default_constants(self):
        s=style();s['beauty']['values'].update(磨皮=.04,瘦脸=0,小脸=0,下颌骨=0)
        s['adjustment']['values']['brightness']=.1;s['adjustment']['orange_hsl']['saturation']=4;s['filter']['strength']=.2
        result=g.apply(base(),s,bindings(),'C:/filter')
        nodes=result['materials']['effects']
        self.assertEqual([n['value'] for n in nodes if n.get('name')=='瘦脸'],[0,0])
        self.assertEqual([n['value'] for n in nodes if n.get('name')=='磨皮'],[.04,.04])
        self.assertEqual([n['value'] for n in nodes if n.get('type')=='brightness'],[.1,.1])
        self.assertEqual([n['saturation'] for n in result['materials']['hsl']],[4,4])
        self.assertEqual([n['value'] for n in nodes if n.get('type')=='filter'],[.2,.2])
        self.assertEqual(g.w.BEAUTY[0][3],.08)
        self.assertEqual(g.f.STRENGTH,.12)

    def test_tampering_each_component_or_original_audio_is_rejected(self):
        s=style()
        for kind in ('figure','brightness','filter','audio','unrequested'):
            result=g.apply(base(),s,bindings(),'C:/filter')
            if kind=='audio':result['tracks'][1]['segments'][0]['volume']=.5
            elif kind=='unrequested':result['materials']['effects'].append({'id':'surprise','type':'unexpected'})
            else:next(n for n in result['materials']['effects'] if n.get('type')==kind)['value']=.9
            with self.assertRaises(ValueError):g.verify(base(),result,s,bindings(),'C:/filter')

    def test_shadow_is_rejected_before_resource_or_network_operations(self):
        s=style();s['subtitle_shadow']=True
        with patch.object(setup,'host',return_value='windows'),patch.object(setup,'cached_filter') as fetch,patch.object(setup.effects,'bind') as bind:
            with self.assertRaisesRegex(ValueError,'字幕阴影'):setup.prepare(s,allow_download=True)
        fetch.assert_not_called();bind.assert_not_called()

class SetupTests(unittest.TestCase):
    def test_prepare_resolves_only_selected_resources(self):
        r={'status':'ready-for-build','runtime':{'runtime_profile':'reviewed'},'blockers':[]}
        for beauty,adjustment,filter in itertools.product((False,True),repeat=3):
            with patch.object(setup,'host',return_value='windows'),patch.object(onboarding,'prepare',return_value=(deepcopy(r),None)), \
                 patch.object(setup.effects,'bind',return_value=(bindings(),{'checks':[]})) as bind, \
                 patch.object(setup,'cached_filter',return_value={'package':'C:/filter'}) as fetch:
                report,profile=setup.prepare(style(beauty,adjustment,filter),allow_download=True)
            self.assertEqual(report['status'],'ready-for-build');self.assertFalse(report['production_ready'])
            self.assertEqual(bind.call_count,int(beauty or adjustment));self.assertEqual(fetch.call_count,int(filter))
            self.assertEqual(profile['style_sha256'],preferences.digest(style(beauty,adjustment,filter)))

    def test_missing_selected_resource_stays_blocked_and_wrong_host_stops_early(self):
        r={'status':'ready-for-build','runtime':{},'blockers':[]}
        with patch.object(setup,'host',return_value='windows'),patch.object(onboarding,'prepare',return_value=(r,None)), \
             patch.object(setup.effects,'bind',side_effect=ValueError('missing beauty')),patch.object(setup,'cached_filter') as fetch:
            report,profile=setup.prepare(style(),allow_download=True)
        self.assertEqual(report['status'],'needs-attention');self.assertIsNone(profile);fetch.assert_not_called()
        with patch.object(setup,'host',return_value='macos'),patch.object(onboarding,'prepare') as prepare:
            with self.assertRaisesRegex(ValueError,'Windows'):setup.prepare(style())
            prepare.assert_not_called()

    def test_cached_filter_is_reused_without_download(self):
        root=Path(__file__).parent/'artifacts'/uuid.uuid4().hex
        save(root/'one/resource.json',{'existing':True})
        with patch.object(setup.filt,'verify',return_value={'cached':True}),patch.object(setup.filt,'fetch') as fetch:
            self.assertEqual(setup.cached_filter(root,allow_download=True),{'cached':True})
        fetch.assert_not_called()

class FakeNative:
    """File-backed codec double, explicitly NOT Windows serialization evidence."""
    def __init__(self,root):
        self.count=0;self.runtime={'runtime_profile':'fake-reviewed'}
        self.nd=SimpleNamespace(DRAFT_ROOT=root/'live',validate_runtime=lambda:self.runtime,
          fresh_directory=lambda p:p.mkdir(parents=True,exist_ok=False),helper=lambda:self,
          packed=lambda d:json.dumps(d,sort_keys=True).encode())
        self.nd.DRAFT_ROOT.mkdir()
    def _encrypt_metadata_from_memory(self,data,path):path.write_bytes(data)
    def _decrypt_metadata_in_memory(self,path):return load(path)
    def files_manifest(self,path):return manifest(path)
    def build(self,plan_path,out):
        self.count+=1;plan=load(plan_path);out.mkdir()
        d={'id':'timeline','materials':{'videos':[],'effects':[],'texts':[],'audios':[]},'tracks':[]}
        for ti,t in enumerate(plan['tracks']):
            tr={'id':f'track{ti}','type':t['type'],'segments':[]}
            for si,s in enumerate(t['segments']):
                ident=f'mat{ti}-{si}'
                if t['type']=='video':d['materials']['videos'].append({'id':ident,'type':'photo' if Path(s['source']).suffix.lower()=='.png' else 'video'})
                elif t['type']=='text':d['materials']['texts'].append({'id':ident,'content':s['text']})
                else:d['materials']['audios'].append({'id':ident,'type':'music'})
                tr['segments'].append({'id':f'seg{ti}-{si}','material_id':ident,'extra_material_refs':[],
                   'target_timerange':{'start':s.get('start_us',0),'duration':s['duration_us']},'volume':s.get('volume',1)})
                if 'opacity' in s:
                    tr['segments'][-1]['clip']={'alpha':s['opacity']}
                if s.get('keyframes',{}).get('opacity'):
                    tr['segments'][-1]['common_keyframes']=[{'property_type':'KFTypeAlpha',
                       'keyframe_list':[{'time_offset':k['at_us'],'values':[k['value']]} for k in s['keyframes']['opacity']]}]
            d['tracks'].append(tr)
        draft=out/'draft';(draft/'Resources').mkdir(parents=True)
        for path in mirrors(draft,'timeline'):save(path,d)
        meta={'draft_id':'new-draft','draft_name':plan['name'],'draft_timeline_materials_size_':0}
        save(draft/'draft_meta_info.json',meta);save(out/'plan.json',plan)
        save(out/'build.json',{'name':plan['name'],'target':str(self.nd.DRAFT_ROOT/plan['name']),
              'draft_id':'new-draft','timeline_id':'timeline','runtime_profile':'fake-reviewed','files':manifest(draft)})
    def verify_build(self,out):
        r=load(out/'build.json')
        if r['files']!=manifest(out/'draft'):raise ValueError('Base fake-native files changed')
        return r

class IntegratedPipelineTests(unittest.TestCase):
    def fixture(self):
        root,project=fixture();project['style']=style();project['tracks'][0]['segments'][0]['volume']=5.6234130859375
        save(root/'project.json',project,replace=True)
        work=root.parent/('integrated-'+uuid.uuid4().hex);work.mkdir()
        profile={'schema':setup.SCHEMA,'style_sha256':preferences.digest(project['style']),
                 'scope':'beauty-adjustment','runtime':{},'bindings':bindings(),'effects_record':{},'filter_record':{'package':'C:/filter'}}
        save(work/'profile.json',profile);save(work/'audio.json',{'project_sha256':project_digest(project)})
        return root,project,work,FakeNative(work)

    def test_real_file_build_verify_six_independent_mirrors_and_frozen_choices(self):
        root,project,work,native=self.fixture()
        quality={'errors':[],'project_sha256':project_digest(project)}
        with patch.object(backend,'host',return_value='windows'),patch.object(basic,'engine',return_value=native), \
             patch.object(setup,'verify_profile'),patch.object(backend,'background_priority'), \
             patch('jianying_studio.quality.inspect',return_value=quality), \
             patch.dict(sys.modules,{'native_edit':SimpleNamespace(basic_validation=lambda d:None)}):
            result=backend.build(root,work/'build',work/'profile.json',work/'audio.json')
            checked=basic.verify(work/'build')
            self.assertEqual(result,checked);self.assertEqual(native.count,1)
            self.assertFalse(result['source_draft_required'])
            self.assertEqual(load(root/'project.json'),project)
            timeline=load(work/'build/timeline.json')
            self.assertEqual(timeline['tracks'][0]['segments'][0]['volume'],5.6234130859375)
            self.assertEqual([t['type'] for t in timeline['tracks']],['video','audio','text','adjust','filter'])
            self.assertEqual(len({p.stat().st_ino for p in mirrors(work/'build/draft','timeline')}),6)
            save(work/'build/project.json',dict(project,name='tampered'),replace=True)
            with self.assertRaisesRegex(ValueError,'frozen input'):basic.verify(work/'build')

    def test_build_refuses_stale_audio_before_native_construction(self):
        root,project,work,native=self.fixture()
        save(work/'audio.json',{'project_sha256':'wrong'},replace=True)
        with patch.object(backend,'host',return_value='windows'),patch.object(basic,'engine',return_value=native):
            with self.assertRaisesRegex(ValueError,'Audio report'):backend.build(root,work/'build',work/'profile.json',work/'audio.json')
        self.assertEqual(native.count,0);self.assertFalse((work/'build').exists())

    def test_publish_while_editor_open_never_calls_native_transaction(self):
        native=Mock()
        with patch.object(backend,'verify'),patch.object(backend,'process_pids',return_value=[42]),patch.object(basic,'engine',return_value=native):
            result=backend.publish('build','audit')
        self.assertEqual(result['status'],'waiting-for-editor-to-close');native.publish.assert_not_called()

    def test_stable_basic_adapter_still_rejects_unselected_effects(self):
        _,p=fixture();p['style']=style()
        with self.assertRaisesRegex(ValueError,'not silently removed'):basic.check_supported(p)

    def test_preferences_deliver_routes_into_integrated_build_with_current_values(self):
        self.deliver_case()

    def test_release_preview_delivers_confirmed_choices(self):
        self.deliver_case(release_preview=True)

    def deliver_case(self, release_preview=False):
        from jianying_studio import preference_project as pp
        root,project,work,native=self.fixture()
        s=preferences.start(work/'preferences')
        s=preferences.update(s['session'],s['revision'],{'cover':{'mode':'none'},'effects':{
            'subtitle_shadow':False,'beauty':{'enabled':False},'filter':{'strength':.2}}},recommended=preferences.GROUPS)
        s=preferences.confirm(s['session'],s['revision'],scope='once')
        roles=pp.bindings_template(s['session'],s['revision'],root)
        roles.update(music_tracks=[1],caption_tracks=[2],editing_applied={'pace':'natural','aspect':'source'})
        def preflight(selected,**kwargs):
            profile={'schema':setup.SCHEMA,'style_sha256':preferences.digest(selected),'scope':'adjustment',
                     'runtime':{},'bindings':bindings(),'effects_record':{},'filter_record':{'package':'C:/filter'}}
            return {'status':'ready-for-build'},profile
        def audio(project,source,out):save(out/'report.json',{'project_sha256':project_digest(project)})
        def quality(project,*args,**kwargs):return {'errors':[],'project_sha256':project_digest(project)}
        with patch('jianying_studio.release.host',return_value='windows'), \
             patch.object(setup,'prepare',side_effect=preflight),patch.object(setup,'verify_profile'), \
             patch.object(backend,'host',return_value='windows'),patch.object(basic,'engine',return_value=native), \
             patch.object(backend,'background_priority'),patch('jianying_studio.native_backend.current',return_value=basic), \
             patch('jianying_studio.quality.inspect',side_effect=quality),patch('jianying_studio.audio_quality.audit',side_effect=audio), \
             patch('jianying_studio.jobs.enqueue',return_value={'status':'queued'}) as enqueue, \
             patch.dict(sys.modules,{'native_edit':SimpleNamespace(basic_validation=lambda d:None)}):
            result=delivery.deliver(root,work/'delivery',session=s['session'],revision=s['revision'],bindings=roles,
                                    windows_style_pilot=not release_preview,release_preview=release_preview,register=True)
        timeline=load(work/'delivery/build/timeline.json')
        self.assertFalse(any(n.get('type')=='figure' for n in timeline['materials']['effects']))
        self.assertEqual([n['value'] for n in timeline['materials']['effects'] if n.get('type')=='filter'],[.2])
        self.assertNotIn('audio',[t['type'] for t in timeline['tracks']])
        self.assertEqual(result['status'],'registration-queued')
        self.assertEqual(enqueue.call_args.kwargs['preference_guard']['revision'],s['revision'])
        self.assertEqual(load(root/'project.json'),project)

if __name__=='__main__':unittest.main()
