# LightCut runtime

Internal draft adapter for Jianying Professional 11.5.0. Use the plugin installer.
