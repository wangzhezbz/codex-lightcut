"""Portable plugin entry; no hard-coded user directories or editor UI."""
import json, os, pathlib, runpy, sys, subprocess
PLUGIN=pathlib.Path(__file__).resolve().parents[1]

def activate():
    """Use the private installation when present; never resolve a venv symlink."""
    sys.path.insert(0, str(PLUGIN / 'install'))
    from bootstrap import home, read
    config = home() / 'environment/runtime.json'
    if not config.is_file(): return
    value = read(config)
    python = pathlib.Path(value['python']).absolute()
    if not python.is_file():
        raise ValueError('轻剪独立环境缺失，请重新运行随包安装入口；已有创作设置会保留。')
    os.environ['PATH'] = value['bin'] + os.pathsep + os.environ.get('PATH', '')
    if value.get('asr'):
        os.environ['LIGHTCUT_ASR_MODEL'] = value['asr']['model']
    if os.path.normcase(os.path.abspath(sys.executable)) != os.path.normcase(str(python)):
        if os.environ.get('LIGHTCUT_ENV_REEXEC') == str(config):
            raise ValueError('轻剪解释器切换未生效，请检查独立环境')
        env = dict(os.environ, LIGHTCUT_ENV_REEXEC=str(config), PYTHONUTF8='1')
        result = subprocess.run([str(python), str(pathlib.Path(__file__).absolute()), *sys.argv[1:]],
                                env=env, stdin=subprocess.DEVNULL,
                                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        raise SystemExit(result.returncode)
def locate():
    explicit=os.environ.get('LIGHTCUT_RUNTIME')
    candidates=[pathlib.Path(explicit)] if explicit else [PLUGIN/'runtime', PLUGIN.parents[1]]
    for root in candidates:
        script=root/'studio/run.py'
        if script.is_file():return script
    raise ValueError('插件运行时尚未随包安装完整；请使用完整的 LightCut 测试包，不需要手工制作剪映参考草稿。')
if __name__=='__main__':
    try:
        activate()
        script=locate()
        sys.path.insert(0,str(script.parent))
        sys.argv=[str(script),*(sys.argv[1:] or ['setup','--release-preview'])]
        runpy.run_path(str(script),run_name='__main__')
    except (ValueError,OSError) as exc:
        print(json.dumps({'status':'needs-attention','owner':'plugin-packaging','message':str(exc),'ui_actions':0},ensure_ascii=False))
        raise SystemExit(2)
