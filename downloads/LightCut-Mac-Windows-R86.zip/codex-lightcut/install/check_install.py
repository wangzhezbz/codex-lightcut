"""Create a compact private install handoff, without media or editor writes."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile

from bootstrap import PLUGIN, digest, home, read, runtime_root, write


def main():
    p=argparse.ArgumentParser();p.add_argument('--out',required=True,type=Path)
    args=p.parse_args();out=args.out.absolute();out.mkdir(parents=True,exist_ok=False)
    runtime=runtime_root();config=read(home()/'environment/runtime.json')
    env=dict(os.environ,PATH=config['bin']+os.pathsep+os.environ.get('PATH',''),PYTHONUTF8='1')
    python=config['python'];checks={}
    def call(name,command,timeout=120):
        result=subprocess.run([str(a) for a in command],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE,env=env,timeout=timeout,
                              creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        (out/(name+'.stdout.log')).write_bytes(result.stdout)
        (out/(name+'.stderr.log')).write_bytes(result.stderr)
        checks[name]={'exit_code':result.returncode}
        return result
    package=PLUGIN/'PACKAGE_SHA256.json'
    if package.exists():
        manifest=read(package)['files']
        bad=[]
        for name,item in manifest.items():
            file=PLUGIN/name
            if not file.is_file() or file.stat().st_size!=item['size'] or digest(file)!=item['sha256']:bad.append(name)
        checks['package']={'files':len(manifest),'mismatches':bad}
    else:checks['package']={'status':'source-tree-no-package-manifest'}
    call('install-tests',[python,'-m','unittest','discover','-s',runtime/'studio/tests','-p','test_install.py','-v'])
    call('cover-size-tests',[python,'-m','unittest','discover','-s',runtime/'studio/tests','-p','test_cover_size.py','-v'])
    call('caption-timing-tests',[python,'-m','unittest','discover','-s',runtime/'studio/tests','-p','test_caption_timing.py','-v'])
    call('caption-quality-tests',[python,'-m','unittest','discover','-s',runtime/'studio/tests','-p','test_quality.py','-v'])
    call('capabilities',[python,PLUGIN/'scripts/lightcut.py','capabilities'])
    call('native-setup',[python,PLUGIN/'scripts/lightcut.py','setup','--release-preview'])
    media=out/'synthetic-smoke.mp4'
    call('media-encode',[Path(config['bin'])/('ffmpeg.exe' if os.name=='nt' else 'ffmpeg'),
         '-nostdin','-v','error','-n','-f','lavfi','-i','color=c=black:s=64x64:r=30',
         '-f','lavfi','-i','anullsrc=r=48000:cl=stereo','-t','0.2','-c:v','libx264',
         '-pix_fmt','yuv420p','-c:a','aac','-threads','2',media])
    probe=call('media-probe',[Path(config['bin'])/('ffprobe.exe' if os.name=='nt' else 'ffprobe'),
         '-v','error','-show_streams','-show_format','-of','json',media])
    if probe.returncode==0:
        data=json.loads(probe.stdout)
        checks['media-content']={'ok':{s['codec_name'] for s in data['streams']}=={'h264','aac'}
                               and .15<float(data['format']['duration'])<.3}
    if config.get('asr'):
        call('model-load',[python,'-c','from faster_whisper import WhisperModel; import sys; WhisperModel(sys.argv[1], device="cpu", compute_type="int8", cpu_threads=2, local_files_only=True)',config['asr']['model']])
    state=home()/'environment/install-state.json'
    if state.exists():write(out/'install-state.json',read(state))
    write(out/'check-result.json',{'schema':'lightcut-install-handoff/v1','checks':checks,'ui_actions':0,
        'generated_media':'synthetic 0.2s black/silence; excluded from handoff ZIP',
        'native_render':'not-checked','drafts_created':False,'private_source_media':False})
    # Logs may include local usernames and paths. Redact in the handoff copies;
    # originals stay on this machine for precise diagnosis.
    replacements=sorted({str(Path.home()),str(home()),str(PLUGIN),str(out)},key=len,reverse=True)
    archive=out/'LightCut-R86-Install-Results.zip'
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for file in sorted(out.iterdir()):
            if file.suffix not in ('.json','.log'):continue
            text=file.read_text(encoding='utf-8',errors='replace')
            for path in replacements:
                text=text.replace(path,'<local>').replace(path.replace('\\','\\\\'),'<local>')
            z.writestr(file.name,text)
    print(json.dumps({'archive':str(archive),'sha256':digest(archive),'checks':checks},ensure_ascii=False,indent=2))
    return 0 if all(v.get('exit_code',0)==0 and not v.get('mismatches') and v.get('ok',True) for v in checks.values()) else 2


if __name__=='__main__':raise SystemExit(main())
