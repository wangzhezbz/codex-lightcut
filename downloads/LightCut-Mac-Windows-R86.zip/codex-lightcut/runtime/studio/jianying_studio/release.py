"""Common Mac/Windows development entry; preserves the user's selected style."""
from .platforms import host
from .project import style_check

from . import __version__ as VERSION


def capabilities():
    return {'version':VERSION,'host':host(),'development_preview':True,'ui_actions':0,
            'windows_reviewed_version':'11.5.0.14471',
            'windows_effect_combinations':'natural and custom effects',
            'publication_queue':'background transactional registration',
            'windows_subtitle_shadow':False,'automatic_beauty_resources':'selected native resources prepared automatically',
            'models':'existing installation/cache; missing or unknown mappings block',
            'dependency_installer':'isolated dependencies with disk-space preflight',
            'visual_end_fade':'editable overlay; default 300ms',
            'local_transcription':'optional faster-whisper CPU/int8; separately prepared and reviewed',
            'onboarding':'confirmed creative choices with automatic exact-name font lookup',
            'cover_dimensions':'independent cover.size validated at review, approval and delivery',
            'confirmed_resource_preparation':'automatic selected-resource preparation after confirmation; never disables missing effects',
            'engine_upgrade':'bundled platform engine with verified source manifest',
            'bundled_native_engines':all((__import__('pathlib').Path(__file__).resolve().parents[2] / 'upstream' / n).is_dir() for n in ('jianying-headless', 'jianying-headless-windows')),'bundled_media_tools':False,
            'clean_machine_acceptance':'pending'}


def prepare(style, *, allow_download=False):
    style_check(style)
    if host()=='windows':
        if style.get('subtitle_shadow'):
            return {'status':'needs-attention','style':style['name'],'ui_actions':0,'downloads':0,
                    'blockers':[{'code':'windows-subtitle-shadow-unsupported','owner':'resource-adapter',
                                 'message':'Windows 暂不支持字幕阴影；保留您的选择，请选择关闭阴影或等待适配'}],
                    'capabilities':capabilities()},None
        from .windows_style_setup import prepare as selected_prepare
        report,profile=selected_prepare(style,allow_download=allow_download,managed_resources=True)
    else:
        from .onboarding import prepare as selected_prepare
        report,profile=selected_prepare(style=style)
    report['capabilities']=capabilities()
    return report,profile
