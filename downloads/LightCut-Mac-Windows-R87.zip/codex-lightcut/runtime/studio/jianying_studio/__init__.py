"""Portable editing plans with explicitly gated native backends."""
__version__ = '0.4.7-preview.1'
