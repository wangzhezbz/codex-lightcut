# Codex LightCut R8.8

版本：0.4.8-preview.1。适配剪映专业版11.5.0，Windows构建11.5.0.14471。

## 安装

把安装包交给 Codex，说“帮我安装”。

## 剪辑

把视频交给 Codex，说“帮我剪辑”。跟着提示选择封面、效果、音乐和字幕；做好后打开剪映查看和导出。以后想修改，直接说就行。

## 升级

把新版安装包交给 Codex，说“帮我升级，保留原来的设置”。

安装由 Codex 读取 skills/lightcut/SKILL.md 自动处理。Mac 使用 install-mac.command --with-asr，Windows 使用 install-windows.ps1 -WithAsr；用户不需要手动运行这些命令。首次安装保持联网。程序不会主动打开或关闭剪映。
