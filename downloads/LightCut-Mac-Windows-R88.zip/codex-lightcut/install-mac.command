#!/bin/bash
set -euo pipefail
LIGHTCUT_PLUGIN_DIR="$(cd "$(dirname "$0")" && pwd)"
LIGHTCUT_HOME="${LIGHTCUT_DATA_HOME:-$HOME/Library/Application Support/CodexLightCut}"
case "$(uname -m)" in
  arm64) LIGHTCUT_UV_TARGET=aarch64-apple-darwin; LIGHTCUT_UV_SHA=cf40e0c6a202190ccd9e0406dcfdd5b2d6668a9a5c779b17948963df32aafe5b ;;
  x86_64) LIGHTCUT_UV_TARGET=x86_64-apple-darwin; LIGHTCUT_UV_SHA=2e4108f5395397c8bc5d43bf83d3bdbb2d0e92b90d0efa607756be704905fa33 ;;
  *) echo 'This Mac architecture is not supported.' >&2; exit 2 ;;
esac
LIGHTCUT_BOOT_DIR="$LIGHTCUT_HOME/environment/bootstrap"
mkdir -p "$LIGHTCUT_BOOT_DIR"
LIGHTCUT_RESERVE_KB=2097152
for LIGHTCUT_ARG in "$@"; do
  if [[ "$LIGHTCUT_ARG" == "--with-asr" ]]; then LIGHTCUT_RESERVE_KB=6291456; fi
done
LIGHTCUT_FREE_KB="$(df -Pk "$LIGHTCUT_BOOT_DIR" | awk 'NR==2 {print $4}')"
if (( LIGHTCUT_FREE_KB < LIGHTCUT_RESERVE_KB )); then
  echo 'Insufficient disk space: reserve 6 GiB with ASR or 2 GiB without ASR. Choose another LIGHTCUT_DATA_HOME; existing files are retained.' >&2
  exit 2
fi
LIGHTCUT_ARCHIVE="$LIGHTCUT_BOOT_DIR/uv-0.12.18-$LIGHTCUT_UV_TARGET.tar.gz"
LIGHTCUT_LOG="$LIGHTCUT_BOOT_DIR/mac-bootstrap.log"
trap 'echo "Preparation stopped; completed files are retained. See $LIGHTCUT_LOG" >&2' ERR
if [[ ! -f "$LIGHTCUT_ARCHIVE" ]] || [[ "$(/usr/bin/shasum -a 256 "$LIGHTCUT_ARCHIVE" | /usr/bin/awk '{print $1}')" != "$LIGHTCUT_UV_SHA" ]]; then
  LIGHTCUT_PART="$(/usr/bin/mktemp "$LIGHTCUT_BOOT_DIR/uv-download.XXXXXX")"
  /usr/bin/curl --fail --location --proto '=https' --proto-redir '=https' --connect-timeout 15 --max-time 600 --retry 2 --silent --show-error "https://github.com/astral-sh/uv/releases/download/0.12.18/uv-$LIGHTCUT_UV_TARGET.tar.gz" -o "$LIGHTCUT_PART" 2>>"$LIGHTCUT_LOG"
  [[ "$(/usr/bin/shasum -a 256 "$LIGHTCUT_PART" | /usr/bin/awk '{print $1}')" == "$LIGHTCUT_UV_SHA" ]] || { echo 'UV checksum mismatch; downloaded file retained.' >&2; exit 2; }
  /bin/mv "$LIGHTCUT_PART" "$LIGHTCUT_ARCHIVE"
fi
LIGHTCUT_UNPACK="$(/usr/bin/mktemp -d "$LIGHTCUT_BOOT_DIR/uv-extract.XXXXXX")"
/usr/bin/tar -xzf "$LIGHTCUT_ARCHIVE" -C "$LIGHTCUT_UNPACK"
LIGHTCUT_UV="$LIGHTCUT_UNPACK/uv-$LIGHTCUT_UV_TARGET/uv"
export UV_PYTHON_INSTALL_DIR="$LIGHTCUT_HOME/environment/python"
export UV_CACHE_DIR="$LIGHTCUT_HOME/environment/uv-cache"
export UV_NO_CONFIG=1 UV_NO_PROGRESS=1 PYTHONUTF8=1
"$LIGHTCUT_UV" python install 3.12.12 --no-bin --no-registry >>"$LIGHTCUT_LOG" 2>&1
LIGHTCUT_PYTHON="$("$LIGHTCUT_UV" python find --managed-python 3.12.12 2>>"$LIGHTCUT_LOG")"
exec "$LIGHTCUT_PYTHON" "$LIGHTCUT_PLUGIN_DIR/install/bootstrap.py" --uv "$LIGHTCUT_UV" "$@"
