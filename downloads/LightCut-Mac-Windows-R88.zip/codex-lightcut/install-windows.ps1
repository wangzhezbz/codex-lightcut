﻿param([switch]$WithAsr, [string]$EngineFrom)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$lightcutPreviousModulePath = $env:PSModulePath
$lightcutLog = $null
try {
    . ([IO.Path]::Combine($PSScriptRoot, 'install', 'windows-bootstrap.ps1'))
    Initialize-LightCutPowerShell
    if ($env:PROCESSOR_ARCHITECTURE -ne 'AMD64') { throw 'This preview supports x64 Windows. Other Windows architectures are not adapted.' }
    $lightcutRoot = if ($env:LIGHTCUT_DATA_HOME) { $env:LIGHTCUT_DATA_HOME } else { Join-Path $env:LOCALAPPDATA 'CodexLightCut' }
    $lightcutBoot = Join-Path $lightcutRoot 'environment/bootstrap'
    [void](New-Item -ItemType Directory -Path $lightcutBoot -Force)
    # Check before downloading the bootstrap or managed Python.
    $lightcutReserve = if ($WithAsr) { 6GB } else { 2GB }
    $lightcutDrive = [IO.DriveInfo]::new([IO.Path]::GetPathRoot([IO.Path]::GetFullPath($lightcutBoot)))
    if ($lightcutDrive.AvailableFreeSpace -lt $lightcutReserve) { throw 'Insufficient disk space: reserve 6 GiB with ASR or 2 GiB without ASR. Choose another LIGHTCUT_DATA_HOME; existing files are retained.' }
    $lightcutLog = Join-Path $lightcutBoot 'windows-bootstrap.log'
    $lightcutLock = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'install/dependencies.json') -Raw | ConvertFrom-Json
    $lightcutAsset = $lightcutLock.platforms.'win32-amd64'.uv
    $lightcutArchive = Join-Path $lightcutBoot 'uv-0.12.18-windows-x64.zip'
    if (!(Test-Path -LiteralPath $lightcutArchive) -or ((Get-FileHash -LiteralPath $lightcutArchive -Algorithm SHA256).Hash.ToLower() -ne $lightcutAsset.sha256)) {
        $lightcutPartial = Join-Path $lightcutBoot ('uv-download-' + [guid]::NewGuid().ToString() + '.zip')
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -UseBasicParsing -Uri $lightcutAsset.url -OutFile $lightcutPartial -TimeoutSec 600
        if ((Get-FileHash -LiteralPath $lightcutPartial -Algorithm SHA256).Hash.ToLower() -ne $lightcutAsset.sha256) { throw 'UV checksum mismatch; download retained.' }
        Move-Item -LiteralPath $lightcutPartial -Destination $lightcutArchive -Force
    }
    $lightcutUnpack = Join-Path $lightcutBoot ('uv-extract-' + [guid]::NewGuid().ToString())
    Expand-Archive -LiteralPath $lightcutArchive -DestinationPath $lightcutUnpack
    $lightcutUv = Join-Path $lightcutUnpack 'uv.exe'
    $env:UV_PYTHON_INSTALL_DIR = Join-Path $lightcutRoot 'environment/python'
    $env:UV_CACHE_DIR = Join-Path $lightcutRoot 'environment/uv-cache'
    $env:UV_NO_CONFIG = '1'
    $env:UV_NO_PROGRESS = '1'
    $env:PYTHONUTF8 = '1'
    $lightcutInstallOutput = Invoke-LightCutUv -Executable $lightcutUv -Arguments 'python install 3.12.12 --no-bin --no-registry' -LogPath $lightcutLog
    Write-LightCutBootstrapLog -LogPath $lightcutLog -Text $lightcutInstallOutput
    $lightcutPython = Invoke-LightCutUv -Executable $lightcutUv -Arguments 'python find --managed-python 3.12.12' -LogPath $lightcutLog
    $lightcutArgs = @((Join-Path $PSScriptRoot 'install/bootstrap.py'), '--uv', $lightcutUv)
    if ($WithAsr) { $lightcutArgs += '--with-asr' }
    if ($EngineFrom) { $lightcutArgs += @('--engine-from', $EngineFrom) }
    & $lightcutPython @lightcutArgs
    exit $LASTEXITCODE
} catch {
    $lightcutFailure = $_.ToString()
    if ($lightcutLog) { Write-LightCutBootstrapLog -LogPath $lightcutLog -Text $lightcutFailure }
    [Console]::Error.WriteLine("Preparation stopped. Completed files are retained. Log: $lightcutLog. $lightcutFailure")
    exit 2
} finally {
    $env:PSModulePath = $lightcutPreviousModulePath
}
