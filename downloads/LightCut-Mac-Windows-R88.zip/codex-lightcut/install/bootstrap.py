"""Private, resumable dependency preparation. No admin rights or editor actions."""
import argparse
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
import urllib.error
import urllib.request
import uuid

HERE = Path(__file__).resolve().parent
PLUGIN = HERE.parent


def home():
    if os.environ.get('LIGHTCUT_DATA_HOME'):
        return Path(os.environ['LIGHTCUT_DATA_HOME']).expanduser().absolute()
    if sys.platform == 'win32':
        return Path(os.environ.get('LOCALAPPDATA', str(Path.home() / 'AppData/Local'))) / 'CodexLightCut'
    return Path.home() / 'Library/Application Support/CodexLightCut'


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''): h.update(chunk)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    with temp.open('x', encoding='utf-8') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n'); f.flush(); os.fsync(f.fileno())
    os.replace(temp, path)


def platform_key():
    machine = platform.machine().lower()
    if sys.platform == 'darwin':
        return 'darwin-' + ('arm64' if machine in ('arm64', 'aarch64') else machine)
    if sys.platform == 'win32' and machine in ('amd64', 'x86_64'):
        return 'win32-amd64'
    raise ValueError('当前安装入口支持 Apple Silicon/Intel Mac 与 x64 Windows；其他架构尚未适配')


@contextmanager
def installation_lock(root):
    root.mkdir(parents=True, exist_ok=True)
    with (root / 'install.lock').open('a+b') as f:
        if not f.seek(0, 2): f.write(b'0'); f.flush()
        f.seek(0)
        try:
            if sys.platform == 'win32':
                import msvcrt
                msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            raise ValueError('另一个轻剪环境准备任务正在运行；保留当前进度，稍后重试') from exc
        try: yield
        finally:
            f.seek(0)
            if sys.platform == 'win32': msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
            else: fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def download(item, target, opener=urllib.request.urlopen):
    """Resume a partial download, verify bytes before publishing, preserve failures."""
    target = Path(target)
    if target.is_file() and target.stat().st_size == item['size'] and digest(target) == item['sha256']:
        return 'reused'
    if target.exists():
        target.rename(target.with_name(target.name + '.invalid-' + uuid.uuid4().hex))
    target.parent.mkdir(parents=True, exist_ok=True)
    partial = target.with_name(target.name + '.part')
    error = None
    for attempt in range(3):
        try:
            offset = partial.stat().st_size if partial.exists() else 0
            if offset == item['size']:
                if digest(partial) == item['sha256']:
                    os.replace(partial, target); return 'resumed'
                partial.rename(partial.with_name(partial.name + '.invalid-' + uuid.uuid4().hex))
                offset = 0
            if offset > item['size']:
                raise ValueError('下载残留超出预期大小，文件已保留：' + str(partial))
            headers = {'User-Agent': 'Codex-LightCut/0.3.0', 'Accept-Encoding': 'identity'}
            if offset: headers['Range'] = f'bytes={offset}-'
            request = urllib.request.Request(item['url'], headers=headers)
            with opener(request, timeout=30) as response:
                if not response.geturl().startswith('https://'):
                    raise ValueError('下载重定向到非 HTTPS 地址')
                append = offset > 0 and response.status == 206
                if append and not response.headers.get('Content-Range', '').startswith(f'bytes {offset}-'):
                    raise ValueError('下载续传范围不匹配')
                count = offset if append else 0
                deadline = time.monotonic() + 600
                with partial.open('ab' if append else 'wb') as out:
                    while True:
                        data = response.read(1024*1024)
                        if not data: break
                        count += len(data)
                        if count > item['size'] or time.monotonic() > deadline:
                            raise ValueError('下载超出大小或时间限制')
                        out.write(data)
            if partial.stat().st_size != item['size'] or digest(partial) != item['sha256']:
                raise ValueError('下载大小或 SHA-256 不匹配；未启用此文件')
            os.replace(partial, target)
            return 'downloaded' if not append else 'resumed'
        except (OSError, ValueError) as exc:
            error = exc
    raise ValueError('依赖下载未完成，重新运行可继续：' + target.name + '; ' + str(error))


def run(args, log, *, env=None, timeout=600):
    result = subprocess.run([str(a) for a in args], stdin=subprocess.DEVNULL,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            env=env, timeout=timeout, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    Path(log).write_bytes(result.stdout)
    if result.returncode:
        raise ValueError('步骤执行失败，日志：' + str(log))
    return result.stdout.decode('utf-8', 'replace').strip()


def runtime_root():
    explicit = os.environ.get('LIGHTCUT_RUNTIME')
    candidates = [Path(explicit)] if explicit else [PLUGIN / 'runtime', PLUGIN.parents[1]]
    for root in candidates:
        if (root / 'studio/run.py').is_file(): return root.resolve()
    raise ValueError('缺少插件运行时代码，请使用完整统一包')


def engine_source(explicit, runtime, environment, platform):
    """Resolve only an explicit source, this package, or a saved verified receipt.

    The receipt is a locator, never authorization to skip attach_engine's hashes.
    """
    name = 'jianying-headless-windows' if platform.startswith('win32-') else 'jianying-headless'
    if explicit:
        return Path(explicit).expanduser().absolute(), 'explicit'
    installed = Path(runtime) / 'upstream' / name
    if installed.is_dir(): return installed, 'current-package'
    receipt = Path(environment) / 'engine-source.json'
    if receipt.is_file():
        value = read(receipt)
        if value.get('schema') != 'lightcut-engine-source/v1' or value.get('platform') != platform:
            raise ValueError('引擎来源记录与当前平台不匹配；请提供已验证的本机引擎')
        source = value.get('source')
        if not isinstance(source, str) or not Path(source).is_absolute():
            raise ValueError('引擎来源记录无效；请提供已验证的本机引擎')
        return Path(source), 'previous-verified-install'
    return installed, 'missing'


def check_space(path, with_asr):
    import shutil
    required = (6 if with_asr else 2) * 1024**3
    free = shutil.disk_usage(path).free
    if free < required:
        raise ValueError(f'安装空间不足：{path} 可用 {free / 1024**3:.1f} GiB，需预留 {required / 1024**3:.0f} GiB；请选择空间充足的数据目录，已有文件保留')
    return {'free_bytes': free, 'required_bytes': required, 'policy': 'conservative-install-reserve'}


def prepare(args):
    root = home() / 'environment'
    started = time.monotonic()
    lock = read(HERE / 'dependencies.json')
    key = platform_key()
    if key not in lock['platforms']: raise ValueError('依赖清单未覆盖当前架构')
    selected = lock['platforms'][key]
    with installation_lock(root):
        attempt = root / 'attempts' / (time.strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8])
        attempt.mkdir(parents=True)
        state = {'schema': 'lightcut-install/v1', 'status': 'preparing', 'platform': key,
                 'attempt': str(attempt), 'steps': {}, 'blockers': [], 'ui_actions': 0,
                 'system_path_changed': False, 'drafts_written': False, 'asr_requested': args.with_asr}
        def checkpoint():
            state['seconds'] = time.monotonic()-started
            write(attempt / 'result.json', state)
            write(root / 'install-state.json', state)
        checkpoint()
        try:
            state['steps']['disk_space'] = check_space(root, args.with_asr)
            checkpoint()
            uv = Path(args.uv).absolute()
            run([uv, '--version'], attempt / 'uv.log')
            env = dict(os.environ, PYTHONUTF8='1', UV_NO_PROGRESS='1', UV_NO_CONFIG='1',
                       UV_CACHE_DIR=str(root / 'uv-cache'))
            dependency_key = hashlib.sha256((lock['python'] + digest(HERE / 'base-requirements.txt')).encode()).hexdigest()[:16]
            venv_root = root / 'envs' / dependency_key
            python = venv_root / ('Scripts/python.exe' if sys.platform == 'win32' else 'bin/python')
            if not python.is_file():
                if venv_root.exists():
                    venv_root.rename(venv_root.with_name(venv_root.name + '.incomplete-' + uuid.uuid4().hex))
                run([uv, 'venv', '--no-config', '--python', sys.executable, venv_root], attempt / 'venv.log', env=env)
            # Keep venv path: resolving its Python symlink would drop the environment.
            if not (venv_root / 'base-ready.json').exists():
                run([uv, 'pip', 'install', '--no-config', '--python', python, '--require-hashes',
                     '--only-binary', ':all:', '--default-index', 'https://pypi.org/simple',
                     '-r', HERE / 'base-requirements.txt'], attempt / 'base-install.log', env=env)
                write(venv_root / 'base-ready.json', {'requirements_sha256': digest(HERE / 'base-requirements.txt')})
            run([python, '-c', 'import fontTools; assert fontTools.__version__ == "4.60.1"'], attempt / 'base-check.log', env=env)
            state['steps']['python'] = {'status': 'ready', 'path': str(python)}; checkpoint()
            media = root / 'media' / key / 'b6.1.1'
            for name, item in selected['media'].items():
                target = media / (name + ('.exe' if sys.platform == 'win32' else ''))
                action = download(item, target)
                if sys.platform != 'win32': target.chmod(0o755)
                version = run([target, '-version'], attempt / (name + '.log'), env=env, timeout=30).splitlines()[0]
                state['steps'][name] = {'status': 'ready', 'action': action, 'version': version,
                                        'path': str(target), 'sha256': item['sha256']}; checkpoint()
            for name, item in selected['notices'].items(): download(item, media / name)
            config = {'schema': 'lightcut-environment/v1', 'python': str(python), 'bin': str(media),
                      'platform': key, 'dependency_lock_sha256': digest(HERE / 'dependencies.json'),
                      'asr': None}
            previous = root / 'runtime.json'
            if previous.exists():
                old = read(previous)
                if old.get('python') == str(python): config['asr'] = old.get('asr')
            write(root / 'runtime.json', config)
            state['environment_ready'] = True
            if args.with_asr:
                req_sha = digest(HERE / 'asr-requirements.txt')
                marker = venv_root / 'asr-ready.json'
                if not marker.exists() or read(marker).get('requirements_sha256') != req_sha:
                    run([uv, 'pip', 'install', '--no-config', '--python', python, '--require-hashes',
                         '--only-binary', ':all:', '--default-index', 'https://pypi.org/simple',
                         '-r', HERE / 'asr-requirements.txt'], attempt / 'asr-install.log', env=env)
                    write(marker, {'requirements_sha256': req_sha})
                model = lock['asr_model']; folder = root / 'models' / ('faster-whisper-small-' + model['revision'])
                actions = {name: download(item, folder / name) for name, item in model['files'].items()}
                write(folder / 'LightCut-model-lock.json', {'revision': model['revision'],
                      'files': {name: item['sha256'] for name, item in model['files'].items()}})
                run([python, '-c', 'from faster_whisper import WhisperModel; import sys; WhisperModel(sys.argv[1], device="cpu", compute_type="int8", cpu_threads=2, local_files_only=True)', folder], attempt / 'asr-check.log', env=env)
                config['asr'] = {'backend': 'faster-whisper', 'model': str(folder), 'revision': model['revision'],
                                 'device': 'cpu', 'compute_type': 'int8'}
                state['steps']['asr'] = {'status': 'model-load-verified', 'downloads': actions,
                                        'transcription_acceptance': 'not-checked'}; checkpoint()
            # Base tools remain usable even if the independently checked native engine is missing.
            write(root / 'runtime.json', config)
            runtime = runtime_root()
            source, source_kind = engine_source(args.engine_from, runtime, root, key)
            if source.is_dir():
                run([python, runtime / 'studio/attach_engine.py', '--source', source], attempt / 'engine.log', env=env)
                # Persist only after exact per-file attachment succeeds. Prefer
                # this installed copy so future upgrades need no old source path.
                name = 'jianying-headless-windows' if key.startswith('win32-') else 'jianying-headless'
                write(root / 'engine-source.json', {'schema': 'lightcut-engine-source/v1',
                      'platform': key, 'source': str((runtime / 'upstream' / name).absolute())})
                state['steps']['engine'] = {'status': 'verified-and-attached', 'source_kind': source_kind}
            else:
                state['steps']['engine'] = {'status': 'missing'}
                state['blockers'].append({'code': 'native-engine-missing', 'owner': 'developer',
                    'message': '基础依赖已准备；当前包不分发受限原生引擎，尚不能在这台新机器制作剪映草稿。Agent 可复用已验证的本机引擎；没有时需完成授权分发或独立实现。'})
            env['PATH'] = str(media) + os.pathsep + env.get('PATH', '')
            result = subprocess.run([str(python), str(runtime / 'studio/run.py'), 'setup', '--release-preview'],
                        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env,
                        timeout=120, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            (attempt / 'native-setup.stdout.json').write_bytes(result.stdout)
            (attempt / 'native-setup.stderr.log').write_bytes(result.stderr)
            try: native = json.loads(result.stdout)
            except ValueError: native = {'status': 'needs-attention', 'blockers': [{'code': 'native-check-failed', 'message': '原生检查失败，详见本次日志'}]}
            state['native'] = native
            state['blockers'].extend(native.get('blockers', []))
            ready = result.returncode == 0 and native.get('status') == 'ready-for-build' and not state['blockers']
            state.update(status='ready-for-draft' if ready else 'needs-attention',
                         environment_ready=True, native_ready=ready, runtime_config=str(root / 'runtime.json'))
        except (OSError, ValueError, subprocess.SubprocessError) as exc:
            state.update(status='needs-attention', error=str(exc))
        checkpoint()
        return state


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--uv', required=True)
    parser.add_argument('--with-asr', action='store_true')
    parser.add_argument('--engine-from')
    args = parser.parse_args()
    try:
        state = prepare(args)
    except (OSError, ValueError) as exc:
        state = {'status': 'needs-attention', 'message': str(exc), 'ui_actions': 0}
    print(json.dumps(state, ensure_ascii=False, indent=2))
    return 0 if state['status'] == 'ready-for-draft' else 2


if __name__ == '__main__':
    raise SystemExit(main())
