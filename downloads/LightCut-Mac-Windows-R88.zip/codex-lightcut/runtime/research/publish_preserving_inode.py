#!/usr/bin/env python3
"""Local macOS compatibility adapter, separate from the unmodified upstream.

Keeps the home index inode and security xattrs. Uses the upstream runtime/build
checks and transaction lock, with a durable original-index backup. Unlike an
atomic rename, in-place writing has a power-loss window: retained journal and
original bytes must be checked before recovering after an interrupted process.
Never strips security attributes, modifies an existing draft, or kills the UI.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys


def attributes(path):
    names = subprocess.check_output(['/usr/bin/xattr', str(path)], text=True).splitlines()
    return {key: bytes.fromhex(subprocess.check_output(['/usr/bin/xattr', '-px', key, str(path)], text=True))
            for key in names}


def permission_attrs_equal(before, after):
    # Match upstream's sole exception: macOS owns per-file provenance. Opening
    # the SAME inode writable can refresh it, before any bytes are written.
    return (('com.apple.provenance' in before) == ('com.apple.provenance' in after)
            and {k: v for k, v in before.items() if k != 'com.apple.provenance'}
            == {k: v for k, v in after.items() if k != 'com.apple.provenance'})


def write_all(fd, payload):
    os.lseek(fd, 0, os.SEEK_SET)
    view = memoryview(payload)
    while view:
        count = os.write(fd, view)
        if count <= 0:
            raise OSError('Index write made no progress')
        view = view[count:]
    os.ftruncate(fd, len(payload))
    os.fsync(fd)


def replace_content(path, original, payload, check, writer=write_all):
    """Write to the same verified inode; restore original on caught failures."""
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise ValueError('Index must be a regular file, never a symlink')
    attrs = attributes(path)
    fd = os.open(path, os.O_RDWR | os.O_NOFOLLOW)
    started = False
    try:
        opened = os.fstat(fd)
        identity = (before.st_dev, before.st_ino, before.st_mode, before.st_uid, before.st_gid)
        if (opened.st_dev, opened.st_ino, opened.st_mode, opened.st_uid, opened.st_gid) != identity:
            raise ValueError('Index identity changed before open')
        if path.read_bytes() != original or not permission_attrs_equal(attrs, attributes(path)):
            raise ValueError('Index changed before write')
        started = True
        writer(fd, payload)
        after = path.lstat()
        if (after.st_dev, after.st_ino, after.st_mode, after.st_uid, after.st_gid) != identity:
            raise ValueError('Index identity or permissions changed')
        if path.read_bytes() != payload or not permission_attrs_equal(attrs, attributes(path)):
            raise ValueError('Index bytes or security attributes differ')
        return check()
    except Exception:
        # Do not overwrite a replacement inode belonging to another writer.
        current = path.lstat()
        if started and (current.st_dev, current.st_ino) == (opened.st_dev, opened.st_ino):
            write_all(fd, original)
            if path.read_bytes() != original or not permission_attrs_equal(attrs, attributes(path)):
                raise RuntimeError('Rollback needs manual inspection; durable backup retained')
        raise
    finally:
        os.close(fd)


def publish(build, audit, resume=False, verify_build_fn=None, verify_live_fn=None):
    upstream = Path(__file__).resolve().parents[1] / 'upstream/jianying-headless'
    sys.path.insert(0, str(upstream / 'engine'))
    import jy14_headless as j
    n = j.nd
    verify_build_fn = verify_build_fn or j.verify_build
    verify_live_fn = verify_live_fn or j.verify_live
    record = verify_build_fn(build)
    h = n.helper()
    runtime = h._validate_runtime_environment()
    j.require(record['runtime_profile'] == runtime['runtime_profile'], 'Runtime changed')
    h._ensure_editor_closed(True)
    target = Path(record['target'])
    j.require(target.parent == n.DRAFT_ROOT and target.exists() == resume and not target.is_symlink(),
              'Only a new draft or explicitly resumed exact draft is allowed')
    if resume:
        j.require(target.is_dir() and j.files_manifest(target) == record['files'],
                  'Resumed target differs from the exact unpublished build')
    audit = n.fresh_directory(audit)
    lock, _ = h._acquire_directory_transaction_lock(n.DRAFT_ROOT, 'headless draft root')
    phase = 'locked'
    try:
        root = h._snapshot_file(n.DRAFT_ROOT / 'root_meta_info.json', 'home index')
        original = h._parse_strict_json(root.content, 'home index')
        j.require(original['root_path'] == str(n.DRAFT_ROOT), 'Root mismatch')
        j.require(not any(e.get('draft_id') == record['draft_id'] or e.get('draft_fold_path') == str(target)
                          for e in original['all_draft_store']), 'Registration conflict')
        attrs = attributes(root.path)
        j.write(audit / 'root_meta_info.original.json', root.content)
        j.write(audit / 'original-attributes.json', {k: v.hex() for k, v in attrs.items()})
        metadata = h._decrypt_metadata_in_memory(build / 'draft/draft_meta_info.json')
        updated = dict(original)
        updated['all_draft_store'] = [j.index_entry(metadata, target)] + original['all_draft_store']
        updated['draft_ids'] = j.integer(original['draft_ids'], 'draft_ids') + 1
        payload = n.packed(updated)
        j.write(audit / 'prepared-index.json', payload)
        j.write(audit / 'journal.json', {
            'adapter': 'preserve-inode-v1', 'index': str(root.path), 'target': str(target),
            'original_sha256': root.sha256, 'prepared_sha256': hashlib.sha256(payload).hexdigest(),
            'original_inode': root.inode, 'original_device': root.device,
            'power_loss_recovery': 'Keep editor closed; inspect current index against original and prepared backup before any recovery.'})
        audit_fd = os.open(audit, os.O_RDONLY)
        try:
            os.fsync(audit_fd)
        finally:
            os.close(audit_fd)
        if not resume:
            stage = n.DRAFT_ROOT / ('.jy-inode-adapter-' + record['draft_id'])
            shutil.copytree(build / 'draft', stage, copy_function=shutil.copy2)
            j.require(j.files_manifest(stage) == record['files'], 'Staged draft differs')
            h._ensure_editor_closed(True)
            h._revalidate_snapshot(root, 'before draft placement')
            j.exclusive_rename(stage, target)
        os.fsync(lock)
        phase = 'draft-placed'
        h._ensure_editor_closed(True)
        h._revalidate_snapshot(root, 'before index write')
        j.require(attributes(root.path) == attrs, 'Index attributes changed')

        def verify():
            after = j.read_json(root.path)
            j.require(after == updated and after['all_draft_store'][1:] == original['all_draft_store'],
                      'Unrelated entries changed')
            return verify_live_fn(build)

        result = replace_content(root.path, root.content, payload, verify)
        phase = 'verified'
        final_attrs = attributes(root.path)
        j.write(audit / 'final-attributes.json', {k: v.hex() for k, v in final_attrs.items()})
        result.update(adapter='preserve-inode-v1', index_inode_preserved=True,
                      security_index_xattrs_preserved=True, old_entries_unchanged=True,
                      os_managed_attribute_changes=[k for k in attrs if attrs[k] != final_attrs.get(k)],
                      original_index_sha256=root.sha256, audit=str(audit), status='created')
        j.write(audit / 'result.json', result)
        return result
    except Exception as error:
        j.write(audit / 'failure.json', dict(phase=phase, error=str(error), target=str(target),
                                           files_deleted=False, recovery='Inspect retained journal and index backups'))
        raise
    finally:
        h._release_directory_transaction_lock(lock)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', type=Path, required=True)
    parser.add_argument('--audit', type=Path, required=True)
    parser.add_argument('--resume', action='store_true')
    args = parser.parse_args()
    print(json.dumps(publish(args.build.resolve(strict=True), args.audit, args.resume), ensure_ascii=False, indent=2))
