"""Portable editing plans with explicitly gated native backends."""
__version__ = '0.4.8-preview.1'
