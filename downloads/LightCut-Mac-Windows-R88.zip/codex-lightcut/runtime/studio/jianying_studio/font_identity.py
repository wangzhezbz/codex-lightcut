"""Read SFNT font identity without relying on filenames or platform font APIs."""
from pathlib import Path
import struct
import unicodedata
from .storage import require


def names(path):
    data = Path(path).read_bytes()
    def u16(p): return struct.unpack_from('>H', data, p)[0]
    def u32(p): return struct.unpack_from('>I', data, p)[0]
    result = set()
    try:
        offsets = [u32(12 + 4*i) for i in range(u32(8))] if data[:4] == b'ttcf' else [0]
        require(len(offsets) <= 256, '字体集合过大')
        for base in offsets:
            require(data[base:base+4] in (b'OTTO', b'\x00\x01\x00\x00', b'true'), '不是支持的字体文件')
            for i in range(u16(base+4)):
                rec = base + 12 + i*16
                if data[rec:rec+4] != b'name': continue
                table = u32(rec+8)
                strings = table + u16(table+4)
                for j in range(u16(table+2)):
                    r = table+6+j*12
                    platform, encoding, language, ident, length, offset = struct.unpack_from('>6H', data, r)
                    if ident not in (1, 4, 6, 16): continue
                    raw = data[strings+offset:strings+offset+length]
                    require(len(raw) == length, '字体名称数据不完整')
                    if platform in (0, 3): codec = 'utf-16-be'
                    elif platform == 1 and encoding == 0: codec = 'mac_roman'
                    else: continue
                    result.add(raw.decode(codec).strip())
    except (struct.error, UnicodeError, IndexError) as exc:
        raise ValueError('无法读取真实字体名称，不能按文件名替代验证') from exc
    require(bool(result), '字体缺少可验证的名称')
    return sorted(result)


def verify(captions):
    requested = captions.get('font_name')
    if not captions.get('enabled') or not requested: return
    font = captions.get('font')
    require(font is not None, f'缺少指定字体 {requested}，请定位该字体文件；禁止自动替换为系统字体')
    actual = names(font['path'])
    normalize = lambda s: unicodedata.normalize('NFKC', s).casefold().strip()
    require(normalize(requested) in {normalize(n) for n in actual},
            f'字幕字体不匹配：要求 {requested}，实际 {", ".join(actual)}；禁止自动替换')


def discover(requested, roots=None):
    """Read only bounded font/cache roots; never substitute another family."""
    import os
    import sys
    if roots is None:
        if sys.platform == 'win32':
            local = Path(os.environ.get('LOCALAPPDATA', Path.home() / 'AppData/Local'))
            roots = [local / 'JianyingPro/User Data/Cache', local / 'Microsoft/Windows/Fonts',
                     Path(os.environ.get('WINDIR', 'C:/Windows')) / 'Fonts']
            from .onboarding import discover_windows_installation
            roots.append(discover_windows_installation().directory / 'Resources/Font')
        else:
            roots = [Path.home() / 'Library/Fonts', Path('/Library/Fonts'),
                     Path.home() / 'Movies/JianyingPro/User Data/Cache']
    for root in roots:
        root = Path(root)
        if not root.is_dir(): continue
        for directory, dirs, files in os.walk(root, followlinks=False):
            dirs.sort()
            for name in sorted(files):
                p = Path(directory) / name
                if p.suffix.lower() not in ('.ttf', '.otf', '.ttc'): continue
                try:
                    from .storage import sha
                    candidate = {'path': str(p.resolve()), 'sha256': sha(p)}
                    verify({'enabled': True, 'font_name': requested, 'font': candidate})
                    return candidate
                except (OSError, ValueError): continue
    return None
