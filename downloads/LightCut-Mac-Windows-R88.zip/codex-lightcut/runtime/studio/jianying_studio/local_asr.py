"""Optional offline CPU transcription; leaves editorial decisions to the agent."""
import os
from pathlib import Path
import time

from .platforms import background_priority
from .storage import require, save, sha, load, asset_path


def restart_flags(segments):
    """Suggest nearby restarts, never infer a safe cut from ASR text alone."""
    flags = []
    def clean(text): return ''.join(c for c in text.lower() if c.isalnum())
    for index, segment in enumerate(segments):
        text = clean(segment['text'])
        # Also catch a restart split across adjacent ASR segments.
        windows = [(text, index)]
        if index and 0 <= segment['start'] - segments[index-1]['end'] <= 1.0:
            windows.append((clean(segments[index-1]['text'])[-24:] + text[:24], index-1))
        found = set()
        for value, first in windows:
            for i in range(len(value)-3):
                for j in range(i+2, min(i+11, len(value)-1)):
                    length = 0
                    while length < min(12, j-i, len(value)-j) and value[i+length] == value[j+length]:
                        length += 1
                    if length < 2: continue
                    phrase = value[i:i+length]
                    if len(set(phrase)) < 2 or phrase in found: continue
                    # On joined windows only report matches crossing the boundary.
                    if first != index:
                        boundary = len(clean(segments[index-1]['text'])[-24:])
                        if not (i < boundary <= j): continue
                    found.add(phrase)
                    flags.append({'segment': index, 'previous': first,
                                  'code': 'possible-phrase-restart', 'phrase': phrase,
                                  'review_start': segments[first]['start'], 'review_end': segment['end'],
                                  'automatic_cut': False, 'timing': 'segment-window-not-cut-boundary'})
    return flags


def review_flags(segments):
    flags = []
    previous_end = 0
    seen = {}
    for index, segment in enumerate(segments):
        start, end = segment['start'], segment['end']
        if start < previous_end - .05 or end <= start:
            flags.append({'segment': index, 'code': 'invalid-or-overlapping-time'})
        previous_end = end
        text = ''.join(c for c in segment['text'].lower() if c.isalnum())
        if len(text) >= 8 and text in seen:
            flags.append({'segment': index, 'code': 'repeated-phrase-review', 'previous': seen[text]})
        if text: seen[text] = index
        if segment.get('no_speech_prob', 0) > .6:
            flags.append({'segment': index, 'code': 'low-speech-confidence'})
    return flags + restart_flags(segments)


def transcribe(source, output, model=None):
    source, output = Path(source).resolve(strict=True), Path(output).absolute()
    require(source.is_file(), '原片不是文件')
    require(not output.exists(), '转写输出已存在，请使用新目录；已完成转写可以直接复用')
    model = model or os.environ.get('LIGHTCUT_ASR_MODEL')
    require(model and Path(model).is_dir(), '本地转写模型未准备；由 Agent 运行安装入口的 with-asr 选项，不要求用户找模型路径')
    model_lock = load(Path(model) / 'LightCut-model-lock.json')
    require(set(model_lock['files']) == {'config.json', 'model.bin', 'tokenizer.json', 'vocabulary.txt'}, '转写模型清单不完整')
    for name, expected in model_lock['files'].items():
        require(sha(asset_path(model, name)) == expected, '转写模型文件变化，请重新运行环境准备')
    from faster_whisper import WhisperModel
    background_priority()
    started = time.monotonic()
    source_hash = sha(source)
    recognizer = WhisperModel(str(model), device='cpu', compute_type='int8', cpu_threads=2,
                              num_workers=1, local_files_only=True)
    stream, info = recognizer.transcribe(str(source), language='zh', beam_size=5,
                                         word_timestamps=True, condition_on_previous_text=False,
                                         vad_filter=True)
    segments = []
    for s in stream:
        segments.append({'start': s.start, 'end': s.end, 'text': s.text.strip(),
                         'no_speech_prob': s.no_speech_prob,
                         'words': [{'start': w.start, 'end': w.end, 'text': w.word, 'probability': w.probability}
                                   for w in (s.words or [])]})
    require(sha(source) == source_hash, '转写期间原片发生变化，结果未交付')
    flags = review_flags(segments)
    result = {'schema': 'lightcut-local-asr/v1', 'status': 'review-needed',
              'source': str(source), 'source_sha256': source_hash, 'model': str(model),
              'backend': 'faster-whisper-cpu-int8', 'language': info.language,
              'source_duration_seconds': info.duration, 'segments': segments,
              'review_flags': flags, 'seconds': time.monotonic()-started,
              'human_listening': 'not-checked', 'editorial_plan': 'not-generated',
              'uploads': 0, 'ui_actions': 0}
    output.mkdir(parents=True, exist_ok=False)
    save(output / 'transcript.json', result)
    (output / 'transcript.txt').write_text('\n'.join(s['text'] for s in segments) + '\n', encoding='utf-8')
    return {k: v for k, v in result.items() if k != 'segments'} | {'transcript': str(output / 'transcript.json')}
