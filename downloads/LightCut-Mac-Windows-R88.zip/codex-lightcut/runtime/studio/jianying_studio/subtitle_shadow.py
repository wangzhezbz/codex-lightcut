"""Native text shadow fields; no effect assets, fonts or editor interaction.

Parameters match the existing talking-head preset. Windows rendering requires
native playback validation; structural verification is independent of that.
"""
from copy import deepcopy
import json
from .storage import require

FIELDS = {'has_shadow': True, 'shadow_color': '#000000', 'shadow_alpha': .75,
          'shadow_smoothing': 1.3500000536441803, 'shadow_distance': 4.999999523162842,
          'shadow_point': {'x': .636396042376431, 'y': -.6363960423764309}, 'shadow_angle': -45.0}
STYLE = [{'alpha': .75, 'angle': -45., 'content': {'render_type': 'solid',
          'solid': {'alpha': 1., 'color': [0., 0., 0.]}},
          'diffuse': .07500000298023224, 'distance': 4.999999523162842}]


def apply(doc):
    for text in doc['materials'].get('texts', []):
        content = json.loads(text['content'])
        require(bool(content.get('styles')), '字幕缺少文字样式，不能写入阴影')
        text.update(deepcopy(FIELDS))
        for style in content['styles']: style['shadows'] = deepcopy(STYLE)
        text['content'] = json.dumps(content, ensure_ascii=False, separators=(',', ':'))


def verify_and_restore(base, actual):
    """Check exact expected text changes, then restore for effect graph checks."""
    expected = deepcopy(base)
    apply(expected)
    require(actual['materials'].get('texts', []) == expected['materials'].get('texts', []),
            '字幕阴影或文字、字体、样式发生未请求的变化')
    if 'texts' in base['materials']:
        actual['materials']['texts'] = deepcopy(base['materials']['texts'])
