"""New-project Windows integrated effects pilot. Never reads a donor/live draft.

Builds one native base, applies selected Windows-native effects in a fresh copy,
verifies all six mirrors and delegates registration to the pinned transaction.
"""
from copy import deepcopy
import importlib
from pathlib import Path
import shutil
import time

from . import windows_backend as basic, windows_style_graph as graph, windows_style_setup as setup
from .windows_effect_build import mirrors, replace_new_copy
from .project import validate, compile_plan
from .storage import load, save, require, manifest, sha, copy_file
from .platforms import host, background_priority, process_pids
from .audio_quality import project_digest

SCHEMA = 'lightcut-windows-integrated-build/v1'
FROZEN = ('project.json', 'native-plan.json', 'profile.json', 'quality.json', 'audio-report.json',
          'base-timeline.json', 'timeline.json', 'metadata.json', 'base-native/build.json')


def check_project(project):
    validate(project, verify_assets=False)
    graph.scopes(project['style'])
    plain = deepcopy(project)
    plain['style'] = deepcopy(setup.BASIC_STYLE)
    basic.check_supported(plain)  # Keep unadapted masks/transitions rejected.


def build(project_dir, output, profile_path, audio_report_path):
    require(host() == 'windows', '联合风格试运行必须在 Windows 构建')
    source, output = Path(project_dir).resolve(strict=True), Path(output).resolve()
    require(not output.exists() and not output.is_relative_to(source), 'Use a fresh output outside the source project')
    started = time.perf_counter()
    project = load(source / 'project.json'); check_project(project); validate(project, source)
    require(audio_report_path is not None, 'Integrated build requires current audio measurements')
    audio = load(audio_report_path)
    require(audio.get('project_sha256') == project_digest(project), 'Audio report belongs to other project settings')
    profile = load(profile_path)
    require(profile.get('schema') == setup.SCHEMA, 'Not a Windows selected-effect profile')
    from .quality import inspect
    quality = inspect(project, source, audio_report=audio)
    require(not quality['errors'], 'Quality gate failed: ' + str(quality['errors']))
    j = basic.engine(); background_priority(); runtime = j.nd.validate_runtime()
    require(not output.is_relative_to(j.nd.DRAFT_ROOT.resolve()), 'Offline build cannot write the live draft root')
    j.nd.fresh_directory(output)
    save(output / 'profile.json', profile)
    filter_path = output / 'filter-resource.json' if profile['filter_record'] else None
    if filter_path: save(filter_path, profile['filter_record'])
    setup.verify_profile(profile, project['style'], filter_record_path=filter_path)
    save(output / 'project.json', project)
    plan = compile_plan(project, source)
    save(output / 'native-plan.json', plan); save(output / 'quality.json', quality); save(output / 'audio-report.json', audio)
    # Native media is imported once; no second staged portable-media copy or audio audit.
    native = output / 'base-native'
    j.build(output / 'native-plan.json', native)
    original_record = j.verify_build(native)
    basic.prepare_home_cover(project, source, output, native, original_record, j)
    original_record = j.verify_build(native)
    draft = output / 'draft'
    shutil.copytree(native / 'draft', draft, copy_function=copy_file)
    helper = j.nd.helper()
    baseline = helper._decrypt_metadata_in_memory(native / 'draft/draft_content.json')
    filter_package = Path(profile['filter_record']['package']).as_posix() if profile['filter_record'] else None
    timeline = graph.apply(baseline, project['style'], profile['bindings'], filter_package)
    from .ending import verify_native
    ending = verify_native(project, timeline)
    importlib.import_module('native_edit').basic_validation(timeline)
    if project['style'].get('beauty', {}).get('enabled'):
        from .windows_effects import video_segments
        for seg in video_segments(timeline): (draft / 'video/figure_algorithm' / seg['material_id']).mkdir(parents=True, exist_ok=True)
    helper._encrypt_metadata_from_memory(j.nd.packed(timeline), output / 'timeline.encrypted')
    require(helper._decrypt_metadata_in_memory(output / 'timeline.encrypted') == timeline, 'Integrated native write/read mismatch')
    cipher = (output / 'timeline.encrypted').read_bytes()
    for path in mirrors(draft, timeline['id']): replace_new_copy(path, cipher, draft)
    metadata = helper._decrypt_metadata_in_memory(native / 'draft/draft_meta_info.json')
    metadata['draft_timeline_materials_size_'] = sum(p.stat().st_size for p in (draft / 'Resources').rglob('*') if p.is_file()) + len(cipher)
    helper._encrypt_metadata_from_memory(j.nd.packed(metadata), output / 'metadata.encrypted')
    replace_new_copy(draft / 'draft_meta_info.json', (output / 'metadata.encrypted').read_bytes(), draft)
    for name, data in [('base-timeline.json', baseline), ('timeline.json', timeline), ('metadata.json', metadata)]: save(output / name, data)
    require(load(source / 'project.json') == project, 'Source project changed during build')
    validate(project, source)
    record = {k: original_record[k] for k in ('name', 'target', 'draft_id', 'timeline_id', 'runtime_profile')}
    record.update(schema=SCHEMA, status='built-offline', source_manifest_sha256=basic.PIN,
                  files=manifest(draft), directories=directories(draft), inputs={name:sha(output/name) for name in FROZEN},
                  ui_actions=0, live_written=False, requested_effects_complete=True, full_default_style=False,
                  acceptance={'components':'user-confirmed-on-tested-Windows', 'integrated_pipeline':'pending-real-machine',
                              'save_reopen':'not-checked', 'subtitle_shadow':'native-text-fields; playback-validation-pending'},
                  seconds=time.perf_counter()-started, source_draft_required=False, ending=ending)
    save(output / 'build.json', record)
    verify(output)
    return record


def directories(root):
    return [p.relative_to(root).as_posix() for p in sorted(root.rglob('*')) if p.is_dir()]


def verify(output):
    require(host() == 'windows', '联合风格原生回读必须在 Windows 执行')
    output = Path(output).resolve(strict=True)
    record = load(output / 'build.json')
    require(record['schema'] == SCHEMA and record['source_manifest_sha256'] == basic.PIN, 'Integrated build identity changed')
    require(record['live_written'] is False and record['full_default_style'] is False and record['requested_effects_complete'] is True,
            'Unexpected integrated pilot acceptance flags')
    require(set(record['inputs']) == set(FROZEN), 'Incomplete verification inputs')
    for name, expected in record['inputs'].items(): require(sha(output/name) == expected, 'Integrated frozen input changed: ' + name)
    project = load(output/'project.json'); check_project(project)
    audio = load(output/'audio-report.json'); quality = load(output/'quality.json')
    require(audio.get('project_sha256') == quality.get('project_sha256') == project_digest(project) and not quality['errors'], 'Stale integrated quality/audio report')
    profile = load(output/'profile.json')
    setup.verify_profile(profile, project['style'], filter_record_path=output/'filter-resource.json' if profile['filter_record'] else None)
    j = basic.engine(); j.nd.validate_runtime(); helper = j.nd.helper()
    base_record = j.verify_build(output/'base-native')
    for key in ('name','target','draft_id','timeline_id','runtime_profile'): require(record[key] == base_record[key], 'Integrated native identity changed')
    require(load(output/'native-plan.json') == load(output/'base-native/plan.json'), 'Base plan does not match intended plan')
    draft = output/'draft'
    require(manifest(draft) == record['files'] and directories(draft) == record['directories'], 'Integrated draft bytes/directories changed')
    baseline = helper._decrypt_metadata_in_memory(output/'base-native/draft/draft_content.json')
    require(baseline == load(output/'base-timeline.json'), 'Base native timeline changed')
    timeline = helper._decrypt_metadata_in_memory(draft/'draft_content.json')
    require(timeline == load(output/'timeline.json'), 'Integrated native readback changed')
    from .ending import verify_native
    verify_native(project, timeline)
    filter_package = Path(profile['filter_record']['package']).as_posix() if profile['filter_record'] else None
    graph.verify(baseline, timeline, project['style'], profile['bindings'], filter_package)
    importlib.import_module('native_edit').basic_validation(timeline)
    paths = mirrors(draft, record['timeline_id'])
    require(len({sha(p) for p in paths}) == 1 and len({p.stat().st_ino for p in paths}) == 6, 'Integrated mirrors differ or share physical files')
    for path in paths: require(helper._decrypt_metadata_in_memory(path) == timeline, 'Native mirror readback mismatch')
    original_meta = helper._decrypt_metadata_in_memory(output/'base-native/draft/draft_meta_info.json')
    expected_meta = deepcopy(original_meta)
    expected_meta['draft_timeline_materials_size_'] = sum(p.stat().st_size for p in (draft/'Resources').rglob('*') if p.is_file()) + paths[0].stat().st_size
    require(helper._decrypt_metadata_in_memory(draft/'draft_meta_info.json') == load(output/'metadata.json') == expected_meta, 'Integrated native metadata changed')
    if project['style'].get('beauty', {}).get('enabled'):
        from .windows_effects import video_segments
        for seg in video_segments(timeline): require((draft/'video/figure_algorithm'/seg['material_id']).is_dir(), 'Missing beauty analysis owner')
    return record


def publication_record(output):
    record = verify(output)
    return dict(record, files=basic.engine().files_manifest(Path(output)/'draft'))


def verify_live(output):
    record = publication_record(output); j = basic.engine(); target = Path(record['target'])
    require(target.parent.resolve() == j.nd.DRAFT_ROOT.resolve() and not target.is_symlink(), 'Unexpected integrated draft target')
    require(j.files_manifest(target) == record['files'] and directories(target) == record['directories'], 'Registered integrated draft differs')
    rows = load(j.nd.DRAFT_ROOT/'root_meta_info.json')['all_draft_store']
    hits = [row for row in rows if row.get('draft_id') == record['draft_id']]
    require(len(hits) == 1 and j.plat.same_draft_path(hits[0].get('draft_fold_path'), target), 'Integrated draft registration differs')
    return {'status':'integrated-pilot-registration-verified','name':record['name'],'draft':str(target),'live_written':True,
            'acceptance':record['acceptance'],'ui_actions':0}


def publish(output, audit, wait_seconds=0):
    require(type(wait_seconds) is int and 0 <= wait_seconds <= 86400, 'Invalid wait timeout')
    verify(output); started = time.monotonic()
    while process_pids():
        if time.monotonic() - started >= wait_seconds:
            return {'status':'waiting-for-editor-to-close','live_files_written':False,'ui_actions':0}
        time.sleep(min(2, max(0, wait_seconds - (time.monotonic()-started))))
    return basic.engine().publish(Path(output),Path(audit),verify_build_fn=publication_record,verify_live_fn=verify_live)
