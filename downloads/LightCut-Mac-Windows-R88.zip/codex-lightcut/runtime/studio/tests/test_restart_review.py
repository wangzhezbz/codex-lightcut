import unittest
from copy import deepcopy
from jianying_studio.local_asr import review_flags
from jianying_studio.caption_timing import map_captions

class RestartTests(unittest.TestCase):
    def test_reported_restart_is_flagged_without_mutation(self):
        rows=[{'start':22.39,'end':24.63,'text':'他是觉得他是懂得尊重'}]
        original=deepcopy(rows)
        flags=review_flags(rows)
        self.assertTrue(any(f.get('phrase')=='他是' for f in flags))
        self.assertTrue(all(f.get('automatic_cut') is False for f in flags))
        self.assertEqual(rows,original)

    def test_restart_across_segments(self):
        flags=review_flags([{'start':0,'end':1,'text':'这件事情我觉得'},
                            {'start':1.1,'end':3,'text':'我觉得应该这样做'}])
        self.assertTrue(any(f['code']=='possible-phrase-restart' for f in flags))

    def test_single_character_emphasis_not_flagged(self):
        self.assertFalse(review_flags([{'start':0,'end':2,'text':'好好读书，慢慢来'}]))

    def test_phrase_emphasis_never_auto_deleted(self):
        flags=review_flags([{'start':0,'end':2,'text':'很快，很快，真的很快'}])
        self.assertTrue(flags)
        self.assertTrue(all(f['automatic_cut'] is False for f in flags))

    def test_reviewed_cut_remaps_caption_without_copying_restart(self):
        clips=[dict(source='s.mp4',source_start_us=0,source_duration_us=1000000,start_us=33333,duration_us=1000000),
               dict(source='s.mp4',source_start_us=2000000,source_duration_us=1000000,start_us=1033333,duration_us=1000000)]
        cues=[dict(source='s.mp4',start_us=1000000,duration_us=1000000,text='他是觉得'),
              dict(source='s.mp4',start_us=2000000,duration_us=1000000,text='他是懂得尊重')]
        out,report=map_captions(clips,cues)
        self.assertEqual([(x['text'],x['start_us']) for x in out],[('他是懂得尊重',1033333)])
        self.assertEqual(report['removed_cues'],[0])
